create extension if not exists pgcrypto;

create table if not exists purchase_orders (
  id text primary key,
  po_number text not null unique,
  vendor_name text not null,
  po_date text not null,
  delivery_date text,
  project_reference text not null,
  delivery_address text not null,
  prepared_by text not null,
  telephone text,
  delivery_instructions text,
  item_category text,
  items_count integer not null default 0,
  total_amount numeric(14,2) not null default 0,
  amount_in_words text not null,
  pdf_link text,
  drive_file_id text,
  status text not null,
  archived boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists purchase_order_items (
  id text primary key,
  purchase_order_id text not null references purchase_orders(id) on delete cascade,
  po_number text not null,
  description text not null,
  category text,
  quantity_type text,
  po_type text,
  quantity numeric(14,2) not null default 0,
  unit_price numeric(14,2) not null default 0,
  amount numeric(14,2) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists activity_logs (
  id text primary key,
  time timestamptz not null default now(),
  action text not null,
  po_number text,
  user_name text,
  status text,
  details text
);

create table if not exists app_settings (
  key text primary key,
  value text not null default ''
);

create index if not exists idx_purchase_orders_created_at on purchase_orders(created_at desc);
create index if not exists idx_purchase_orders_archived on purchase_orders(archived);
create index if not exists idx_purchase_order_items_order_id on purchase_order_items(purchase_order_id);
create index if not exists idx_activity_logs_time on activity_logs(time desc);
