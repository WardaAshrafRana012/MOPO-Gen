﻿'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import EditablePOComposer from '@/components/po/EditablePOComposer';
import GlassCard from '@/components/ui/GlassCard';

export default function POEditPage() {
  const params = useParams();
  const poId = params?.id as string;
  const [record, setRecord] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [missing, setMissing] = useState(false);

  useEffect(() => {
    if (!poId) return;
    fetch(`/api/po/${poId}`)
      .then((r) => r.json())
      .then((d) => {
        if (!d?.data) setMissing(true);
        else setRecord(d.data);
        setLoading(false);
      })
      .catch(() => {
        setMissing(true);
        setLoading(false);
      });
  }, [poId]);

  if (loading) {
    return (
      <div className="space-y-6 py-6">
        <GlassCard className="p-8">
          <p className="section-heading">Edit PO</p>
          <div className="mt-4 flex items-center gap-3 text-slate-400">
            <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-champagne border-t-transparent" />
            Loading purchase order...
          </div>
        </GlassCard>
      </div>
    );
  }

  if (missing || !record) {
    return (
      <div className="space-y-6 py-6">
        <GlassCard className="p-8">
          <p className="section-heading">Edit PO</p>
          <p className="mt-4 text-slate-400">Purchase order not found.</p>
        </GlassCard>
      </div>
    );
  }

  return <EditablePOComposer existing={record} poId={poId} />;
}
