import PODetail from '@/components/po/PODetail';

export default function PODetailPage({ params }: { params: { id: string } }) {
  return <PODetail poId={params.id} />;
}
