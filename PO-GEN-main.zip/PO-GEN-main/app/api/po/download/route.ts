import { NextRequest, NextResponse } from 'next/server';
import { getDriveClient } from '@/lib/google/client';

/**
 * GET /api/po/download?fileId=DRIVE_FILE_ID
 * Streams the PDF from Google Drive through the server so the browser gets a
 * proper download — avoids the Google login-wall that direct Drive links hit.
 */
export async function GET(req: NextRequest) {
  const fileId  = req.nextUrl.searchParams.get('fileId');
  const fallUrl = req.nextUrl.searchParams.get('url');   // legacy fallback

  // ── Extract file ID from a full Drive URL if that's what was passed ────────
  let id = fileId;
  if (!id && fallUrl) {
    const m = fallUrl.match(/\/d\/([a-zA-Z0-9_-]+)/);
    id = m ? m[1] : null;
  }

  if (!id) {
    return NextResponse.json({ error: 'Missing fileId parameter.' }, { status: 400 });
  }

  try {
    const drive = await getDriveClient();

    // Get file metadata for the filename
    const meta = await drive.files.get({ fileId: id, fields: 'name' });
    const name = meta.data.name || `${id}.pdf`;

    // Stream the file content
    const res = await drive.files.get(
      { fileId: id, alt: 'media' },
      { responseType: 'stream' },
    );

    // Pipe through to browser
    const chunks: Buffer[] = [];
    await new Promise<void>((resolve, reject) => {
      (res.data as NodeJS.ReadableStream)
        .on('data', (chunk: Buffer) => chunks.push(chunk))
        .on('end', resolve)
        .on('error', reject);
    });

    const buffer = Buffer.concat(chunks);

    return new NextResponse(buffer, {
      status: 200,
      headers: {
        'Content-Type':        'application/pdf',
        'Content-Disposition': `attachment; filename="${name}"`,
        'Content-Length':      String(buffer.length),
        'Cache-Control':       'no-store',
      },
    });
  } catch (err: any) {
    // If drive fetch fails, fall back to redirect to Drive view link
    if (fallUrl) {
      return NextResponse.redirect(fallUrl);
    }
    return NextResponse.json({ error: String(err?.message || err) }, { status: 500 });
  }
}
