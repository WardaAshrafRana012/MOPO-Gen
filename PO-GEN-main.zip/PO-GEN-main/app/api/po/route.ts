import { NextRequest, NextResponse } from 'next/server';
import { createPurchaseOrder, getAllPurchaseOrders } from '@/lib/po';

export async function GET() {
  try {
    const purchaseOrders = await getAllPurchaseOrders(false);
    return NextResponse.json({ data: purchaseOrders });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const payload = await req.json();
    const result = await createPurchaseOrder(payload);
    return NextResponse.json({ data: result });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
