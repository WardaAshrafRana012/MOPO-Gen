import { NextRequest, NextResponse } from 'next/server';
import { getPurchaseOrderById, updatePurchaseOrder } from '@/lib/po';

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const record = await getPurchaseOrderById(params.id);
    if (!record) {
      return NextResponse.json({ error: 'PO not found' }, { status: 404 });
    }
    return NextResponse.json({ data: record });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const payload = await req.json();
    const result = await updatePurchaseOrder(params.id, payload);
    return NextResponse.json({ data: result });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
