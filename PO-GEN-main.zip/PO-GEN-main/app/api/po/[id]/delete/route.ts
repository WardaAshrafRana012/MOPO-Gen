import { NextResponse } from 'next/server';
import { deletePurchaseOrder } from '@/lib/po';

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  try {
    const result = await deletePurchaseOrder(params.id);
    return NextResponse.json({ data: result });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
