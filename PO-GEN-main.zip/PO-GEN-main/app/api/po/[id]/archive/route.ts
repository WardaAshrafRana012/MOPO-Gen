import { NextResponse } from 'next/server';
import { archivePurchaseOrder } from '@/lib/po';

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  try {
    const result = await archivePurchaseOrder(params.id);
    return NextResponse.json({ data: result });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
