import { NextResponse } from 'next/server';
import { appendAppActivityLog, verifyAppStorage } from '@/lib/storage';

export async function POST() {
  try {
    const storage = await verifyAppStorage();

    if (storage.missingTargets.length > 0) {
      return NextResponse.json({
        data: {
          provider: storage.provider,
          requiredTabs: storage.requiredTargets,
          missingTabs: storage.missingTargets,
          poCount: storage.poCount,
          synced: 0,
          message: `Missing storage targets: ${storage.missingTargets.join(', ')}`,
        },
      });
    }

    await appendAppActivityLog({
      Log_ID: crypto.randomUUID(),
      Time: new Date().toISOString(),
      Action: 'Sync',
      PO_Number: '',
      User: 'System',
      Status: 'Synced',
      Details: `${storage.provider} storage verified. ${storage.poCount} PO record(s) available.`,
    });

    return NextResponse.json({
      data: {
        provider: storage.provider,
        requiredTabs: storage.requiredTargets,
        missingTabs: [],
        poCount: storage.poCount,
        synced: storage.poCount,
        message: `Storage verified. ${storage.poCount} PO record(s) available.`,
      },
    });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
