import { NextResponse } from 'next/server';
import { verifyAppStorage } from '@/lib/storage';
import { getDriveClient, GOOGLE_DRIVE_FOLDER_ID } from '@/lib/google/client';

export async function POST() {
  try {
    const storage = await verifyAppStorage();
    const appsScriptUrl = process.env.GOOGLE_APPS_SCRIPT_WEB_APP_URL?.trim() || '';

    if (appsScriptUrl) {
      return NextResponse.json({
        data: {
          provider: storage.provider,
          spreadsheetId:
            storage.provider === 'google-sheets' || storage.provider === 'google-apps-script'
              ? storage.spreadsheetId
              : '',
          sheets: storage.missingTargets.length === 0,
          requiredTabs: storage.requiredTargets,
          missingTabs: storage.missingTargets,
          driveFolder: true,
          driveFolderName: 'Verified via Apps Script',
        },
      });
    }

    const drive = await getDriveClient();
    const response = await drive.files.get({
      fileId: GOOGLE_DRIVE_FOLDER_ID,
      fields: 'id,name,mimeType',
    });

    return NextResponse.json({
      data: {
        provider: storage.provider,
        spreadsheetId: storage.provider === 'google-sheets' ? storage.spreadsheetId : '',
        sheets: storage.missingTargets.length === 0,
        requiredTabs: storage.requiredTargets,
        missingTabs: storage.missingTargets,
        driveFolder: Boolean(response.data.id),
        driveFolderName: response.data.name,
      },
    });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
