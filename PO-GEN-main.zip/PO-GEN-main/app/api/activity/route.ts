import { NextResponse } from 'next/server';
import { getAppActivityLogs } from '@/lib/storage';

export async function GET() {
  try {
    const logs = await getAppActivityLogs();
    return NextResponse.json({ data: logs });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
