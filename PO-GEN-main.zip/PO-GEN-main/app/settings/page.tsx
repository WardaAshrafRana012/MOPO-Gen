﻿'use client';

import { useEffect, useState } from 'react';
import GlassCard from '@/components/ui/GlassCard';
import Button from '@/components/ui/Button';
import { CheckCircle, XCircle, RefreshCw } from 'lucide-react';

const TABS = ['General', 'Google Sheets', 'Google Drive', 'PO Rules', 'Appearance'] as const;
type Tab = typeof TABS[number];

type Msg = { text: string; ok: boolean } | null;

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState<Tab>('General');
  const [settings,  setSettings]  = useState<Record<string, string>>({});
  const [saveMsg,   setSaveMsg]   = useState<Msg>(null);
  const [testMsg,   setTestMsg]   = useState<Msg>(null);
  const [testing,   setTesting]   = useState(false);
  const [saving,    setSaving]    = useState(false);

  useEffect(() => {
    fetch('/api/settings').then((r) => r.json()).then((d) => {
      setSettings(d?.data || {});
    });
  }, []);

  function set(key: string, val: string) {
    setSettings((s) => ({ ...s, [key]: val }));
  }

  async function handleSave() {
    setSaving(true);
    setSaveMsg(null);
    try {
      const res  = await fetch('/api/settings', {
        method:  'PUT',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(settings),
      });
      const data = await res.json();
      setSaveMsg(res.ok ? { ok: true, text: 'Settings saved.' } : { ok: false, text: data?.error || 'Save failed.' });
    } catch (e: any) {
      setSaveMsg({ ok: false, text: String(e?.message || e) });
    } finally {
      setSaving(false);
      setTimeout(() => setSaveMsg(null), 5000);
    }
  }

  async function handleTest() {
    setTesting(true);
    setTestMsg(null);
    try {
      const res  = await fetch('/api/sync/test', { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        const sheetOk = data.data.sheets;
        const driveOk = data.data.driveFolder;
        const missing = data.data.missingTabs?.join(', ');
        setTestMsg({
          ok:   sheetOk && driveOk,
          text: sheetOk && driveOk
            ? `âœ“ Sheets OK Â· Drive folder "${data.data.driveFolderName}" OK`
            : `Sheets: ${sheetOk ? 'OK' : `missing: ${missing}`} Â· Drive: ${driveOk ? 'OK' : 'failed'}`,
        });
      } else {
        setTestMsg({ ok: false, text: data?.error || 'Test failed.' });
      }
    } catch (e: any) {
      setTestMsg({ ok: false, text: String(e?.message || e) });
    } finally {
      setTesting(false);
    }
  }

  async function handleDriveTest() {
    setTestMsg({ ok: true, text: 'Uploading test PDFâ€¦' });
    const res  = await fetch('/api/drive/test-upload', { method: 'POST' });
    const data = await res.json();
    setTestMsg(res.ok
      ? { ok: true,  text: `Drive upload OK Â· ${data.data.pdfLink}` }
      : { ok: false, text: data?.error || 'Drive upload failed.' });
  }

  async function handleSyncSheet() {
    setTestMsg({ ok: true, text: 'Syncingâ€¦' });
    const res  = await fetch('/api/sync', { method: 'POST' });
    const data = await res.json();
    setTestMsg(res.ok
      ? { ok: true,  text: data.data.missingTabs?.length ? `Missing tabs: ${data.data.missingTabs.join(', ')}` : 'âœ“ Sheet verified.' }
      : { ok: false, text: data?.error || 'Sync failed.' });
  }

  const field = (key: string, label: string, type: 'text' | 'password' = 'text') => (
    <label key={key} className="block space-y-1.5 text-sm text-slate-200">
      {label}
      <input
        type={type}
        className="input-field mt-1"
        value={settings[key] ?? ''}
        onChange={(e) => set(key, e.target.value)}
      />
    </label>
  );

  const toggle = (key: string, label: string, locked = false, lockedValue = 'false') => (
    <label key={key} className={`flex items-center gap-3 rounded-2xl border border-white/8 px-4 py-3 text-sm text-slate-200 ${locked ? 'opacity-60' : 'cursor-pointer'}`}>
      <input
        type="checkbox"
        className="h-4 w-4 rounded accent-amber-400"
        checked={(settings[key] ?? lockedValue) === 'true'}
        disabled={locked}
        onChange={(e) => !locked && set(key, e.target.checked ? 'true' : 'false')}
      />
      <span>{label}</span>
      {locked && <span className="ml-auto text-[10px] uppercase tracking-wider text-slate-600">Locked</span>}
    </label>
  );

  return (
    <div className="space-y-6 py-6">
      {/* Header */}
      <GlassCard className="p-8">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="section-heading">Settings</p>
            <h1 className="page-heading mt-1">System Configuration</h1>
            <p className="mt-3 max-w-2xl text-sm text-slate-400">
              Configure company branding, Google Sheets integration, Drive storage, and PO generation rules.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" onClick={handleSyncSheet} className="text-sm gap-2">
              <RefreshCw className="h-3.5 w-3.5" /> Sync Sheet
            </Button>
            <Button variant="secondary" onClick={handleTest} disabled={testing} className="text-sm">
              {testing ? 'Testingâ€¦' : 'Test Connection'}
            </Button>
            <Button variant="primary" onClick={handleSave} disabled={saving} className="text-sm">
              {saving ? 'Savingâ€¦' : 'Save Settings'}
            </Button>
          </div>
        </div>

        {/* Messages */}
        {saveMsg && (
          <div className={`mt-4 flex items-center gap-2 rounded-2xl border px-4 py-3 text-sm ${saveMsg.ok ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200' : 'border-rose-500/30 bg-rose-500/10 text-rose-200'}`}>
            {saveMsg.ok ? <CheckCircle className="h-4 w-4 flex-shrink-0" /> : <XCircle className="h-4 w-4 flex-shrink-0" />}
            {saveMsg.text}
          </div>
        )}
        {testMsg && (
          <div className={`mt-3 flex items-start gap-2 rounded-2xl border px-4 py-3 text-sm ${testMsg.ok ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200' : 'border-rose-500/30 bg-rose-500/10 text-rose-200'}`}>
            {testMsg.ok ? <CheckCircle className="h-4 w-4 flex-shrink-0 mt-0.5" /> : <XCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />}
            <span className="break-all">{testMsg.text}</span>
          </div>
        )}
      </GlassCard>

      <div className="grid gap-6 xl:grid-cols-[220px_1fr]">
        {/* Tab list */}
        <GlassCard className="p-4 h-fit">
          <p className="section-heading mb-3">Sections</p>
          <nav className="space-y-1">
            {TABS.map((tab) => (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveTab(tab)}
                className={`w-full rounded-2xl px-4 py-2.5 text-left text-sm font-medium transition ${
                  activeTab === tab
                    ? 'bg-champagne/15 text-champagne'
                    : 'text-slate-400 hover:bg-white/5 hover:text-slate-100'
                }`}
              >
                {tab}
              </button>
            ))}
          </nav>
        </GlassCard>

        {/* Tab content */}
        <GlassCard className="p-7">
          <p className="section-heading mb-5">{activeTab}</p>

          {activeTab === 'General' && (
            <div className="space-y-4">
              <div className="mb-2 rounded-2xl border border-amber-500/20 bg-amber-500/8 px-4 py-3 text-xs text-amber-200">
                These values appear on every generated PDF. They are fixed branding â€” not collected from the Create PO form.
              </div>
              {field('COMPANY_NAME',    'Company Name')}
              {field('COMPANY_ADDRESS', 'Company Address')}
              {field('COMPANY_NTN',     'NTN Number')}
              {field('COMPANY_STRN',    'STRN Number')}
              {field('FOOTER_TEXT',     'PDF Footer Text')}
            </div>
          )}

          {activeTab === 'Google Sheets' && (
            <div className="space-y-4">
              {field('GOOGLE_SHEET_ID',    'Spreadsheet ID')}
              {field('PO_MAIN_TAB',        'PO_Main tab name')}
              {field('PO_ITEMS_TAB',       'PO_Items tab name')}
              <div className="pt-2">
                <Button variant="secondary" onClick={handleSyncSheet} className="text-sm">
                  Sync &amp; Verify Tabs
                </Button>
              </div>
            </div>
          )}

          {activeTab === 'Google Drive' && (
            <div className="space-y-4">
              {field('GOOGLE_DRIVE_FOLDER_ID', 'Drive Folder ID')}
              {field('LOGO_PATH',              'Logo Path (in /public)')}
              <div className="pt-2">
                <Button variant="secondary" onClick={handleDriveTest} className="text-sm">
                  Test Drive Upload
                </Button>
              </div>
            </div>
          )}

          {activeTab === 'PO Rules' && (
            <div className="space-y-4">
              {field('PO_PREFIX', 'PO Number Prefix (e.g. PO)')}
              <div className="space-y-2 pt-1">
                {toggle('AUTO_GENERATE_PO_NUMBER', 'Auto-generate PO Number',          true, 'true')}
                {toggle('DELIVERY_DATE_REQUIRED',  'Delivery Date Required',           true, 'false')}
                {toggle('ARCHIVE_INSTEAD_OF_DELETE','Archive instead of permanent delete', false, 'true')}
              </div>
              <div className="rounded-2xl border border-white/8 bg-slate-900/50 px-4 py-3 text-xs text-slate-500">
                Tax column is permanently removed from this app and will never appear in PDFs.
              </div>
            </div>
          )}

          {activeTab === 'Appearance' && (
            <div className="space-y-4">
              <label className="block space-y-1.5 text-sm text-slate-200">
                Theme
                <select
                  className="input-field mt-1"
                  value={settings.THEME ?? 'dark'}
                  onChange={(e) => set('THEME', e.target.value)}
                >
                  <option value="dark">Dark</option>
                </select>
              </label>
              <label className="block space-y-1.5 text-sm text-slate-200">
                Accent Colour
                <select
                  className="input-field mt-1"
                  value={settings.ACCENT ?? 'champagne'}
                  onChange={(e) => set('ACCENT', e.target.value)}
                >
                  <option value="champagne">Champagne Gold</option>
                </select>
              </label>
              <label className="block space-y-1.5 text-sm text-slate-200">
                Glass Intensity
                <select
                  className="input-field mt-1"
                  value={settings.GLASS_INTENSITY ?? 'medium'}
                  onChange={(e) => set('GLASS_INTENSITY', e.target.value)}
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </label>

              {/* Logo preview */}
              <div className="rounded-2xl border border-white/8 bg-slate-900/50 p-4">
                <p className="mb-3 text-xs uppercase tracking-wider text-slate-500">Logo Preview</p>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={settings.LOGO_PATH || '/molecule-logo.png'}
                  alt="Company logo"
                  className="h-16 w-16 rounded-xl object-contain bg-slate-800 p-2"
                />
                <p className="mt-2 text-xs text-slate-500">Path: {settings.LOGO_PATH || '/molecule-logo.png'}</p>
              </div>
            </div>
          )}
        </GlassCard>
      </div>
    </div>
  );
}

