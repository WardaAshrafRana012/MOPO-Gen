'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import GlassCard from '@/components/ui/GlassCard';
import Badge from '@/components/ui/Badge';
import { formatDate, formatCurrency } from '@/lib/utils/format';
import { LayoutDashboard, FileText, Plus, RefreshCw } from 'lucide-react';

export default function DashboardPage() {
  const [orders,  setOrders]  = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/po')
      .then((r) => r.json())
      .then((d) => { setOrders(d?.data ?? []); setLoading(false); });
  }, []);

  const stats = useMemo(() => {
    const total     = orders.length;
    const draft     = orders.filter((o) => o.status?.toLowerCase() === 'draft').length;
    const generated = orders.filter((o) => o.status?.toLowerCase().includes('generated')).length;
    const withPdf   = orders.filter((o) => !!o.pdfLink).length;
    const archived  = orders.filter((o) => o.archived).length;
    const totalVal  = orders.reduce((s, o) => s + Number(o.totalAmount || 0), 0);
    return { total, draft, generated, withPdf, archived, totalVal };
  }, [orders]);

  return (
    <div className="space-y-6 py-6">

      {/* ── Hero row ─────────────────────────────────────────────────────── */}
      <div className="grid gap-4 xl:grid-cols-[1.6fr_0.7fr]">
        <GlassCard className="p-8">
          <div className="flex items-start gap-4">
            <span className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-2xl bg-champagne/15">
              <LayoutDashboard className="h-5 w-5 text-champagne" />
            </span>
            <div>
              <p className="section-heading">Dashboard</p>
              <h1 className="page-heading mt-1">Molecule PO Manager</h1>
              <p className="mt-3 max-w-xl text-slate-400 text-sm leading-6">
                Create, manage and track purchase orders. PDFs are auto-generated and stored in Google Drive. All data lives in your Google Sheet.
              </p>
            </div>
          </div>
        </GlassCard>

        <GlassCard className="p-6">
          <p className="section-heading mb-4">Quick Actions</p>
          <div className="flex flex-col gap-2">
            <Link href="/create-po" className="primary-button w-full justify-center gap-2 text-sm">
              <Plus className="h-4 w-4" /> Create New PO
            </Link>
            <Link href="/po-records" className="secondary-button w-full justify-center gap-2 text-sm">
              <FileText className="h-4 w-4" /> View PO Records
            </Link>
          </div>
        </GlassCard>
      </div>

      {/* ── Stats cards ──────────────────────────────────────────────────── */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        {[
          { label: 'Total POs',      value: stats.total,                     accent: false },
          { label: 'Drafts',         value: stats.draft,                     accent: false },
          { label: 'PDFs Generated', value: stats.generated,                 accent: false },
          { label: 'PDFs on Drive',  value: stats.withPdf,                   accent: false },
          { label: 'Archived',       value: stats.archived,                  accent: false },
          { label: 'Total Value',    value: formatCurrency(stats.totalVal),  accent: true  },
        ].map(({ label, value, accent }) => (
          <GlassCard key={label} className="p-5">
            <p className="text-xs uppercase tracking-wider text-slate-500">{label}</p>
            <p className={`mt-2 text-2xl font-semibold ${accent ? 'text-champagne' : 'text-slate-100'}`}>
              {loading ? <span className="inline-block h-7 w-16 animate-pulse rounded-lg bg-slate-800" /> : value}
            </p>
          </GlassCard>
        ))}
      </div>

      {/* ── Recent orders table ───────────────────────────────────────────── */}
      <GlassCard className="overflow-hidden p-0">
        <div className="flex items-center justify-between gap-4 px-6 py-5 border-b border-white/8">
          <div>
            <p className="section-heading">Recent Purchase Orders</p>
            <p className="mt-0.5 text-xs text-slate-500">Latest 8 orders from Google Sheets</p>
          </div>
          <Link href="/po-records" className="secondary-button text-sm">View all →</Link>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full border-separate border-spacing-0 text-left text-sm">
            <thead>
              <tr className="bg-slate-950/80 text-xs uppercase tracking-wider text-slate-500">
                <th className="px-5 py-3.5 font-medium">PO Number</th>
                <th className="px-5 py-3.5 font-medium">Vendor</th>
                <th className="px-5 py-3.5 font-medium">PO Date</th>
                <th className="px-5 py-3.5 font-medium">Delivery Date</th>
                <th className="px-5 py-3.5 font-medium text-right">Total</th>
                <th className="px-5 py-3.5 font-medium">Status</th>
                <th className="px-5 py-3.5 font-medium"></th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array.from({ length: 4 }).map((_, i) => (
                  <tr key={i} className="border-t border-white/5">
                    {Array.from({ length: 7 }).map((_, j) => (
                      <td key={j} className="px-5 py-4">
                        <span className="inline-block h-3.5 w-20 animate-pulse rounded bg-slate-800" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : orders.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-12 text-center text-slate-500">
                    No purchase orders yet.{' '}
                    <Link href="/create-po" className="text-champagne hover:text-white underline">Create your first PO →</Link>
                  </td>
                </tr>
              ) : (
                orders.slice(0, 8).map((order) => (
                  <tr key={order.poId} className="border-t border-white/5 text-slate-200 transition hover:bg-white/[0.04]">
                    <td className="px-5 py-4 font-semibold text-slate-100 whitespace-nowrap">{order.poNumber}</td>
                    <td className="px-5 py-4 whitespace-nowrap">{order.vendorName}</td>
                    <td className="px-5 py-4 text-slate-400 whitespace-nowrap">{formatDate(order.poDate)}</td>
                    <td className="px-5 py-4 text-slate-400 whitespace-nowrap">{order.deliveryDate ? formatDate(order.deliveryDate) : '—'}</td>
                    <td className="px-5 py-4 text-right font-medium text-slate-100 whitespace-nowrap">{formatCurrency(order.totalAmount)}</td>
                    <td className="px-5 py-4">
                      <Badge
                        label={order.status || 'Unknown'}
                        tone={order.status?.toLowerCase().includes('generated') ? 'success' : 'muted'}
                      />
                    </td>
                    <td className="px-5 py-4">
                      <Link href={`/po-records/${order.poId}`} className="text-xs font-medium text-champagne hover:text-white whitespace-nowrap">
                        View →
                      </Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </GlassCard>

      {/* ── Bottom row: template preview + activity link ─────────────────── */}
      <div className="grid gap-4">
        <GlassCard className="p-6">
          <p className="section-heading mb-3">PO Template</p>
          <p className="text-sm text-slate-400 leading-6">
            Every PDF uses the fixed Molecule Purchase Order template — logo, company address, NTN/STRN, items table and delivery details.
          </p>
          <Link href="/templates" className="mt-4 inline-flex text-sm font-medium text-champagne hover:text-white">
            Preview template →
          </Link>
        </GlassCard>
      </div>
    </div>
  );
}
