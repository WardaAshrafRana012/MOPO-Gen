import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { createOAuthClient, getOAuthTokenPath } from '@/lib/google/client';

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const code = url.searchParams.get('code');
    if (!code) return NextResponse.json({ error: 'Missing code' }, { status: 400 });

    const oauth2Client = createOAuthClient();
    const { tokens } = await oauth2Client.getToken(code);

    const tokenFullPath = path.resolve(process.cwd(), getOAuthTokenPath());
    fs.mkdirSync(path.dirname(tokenFullPath), { recursive: true });
    fs.writeFileSync(tokenFullPath, JSON.stringify(tokens, null, 2));

    return NextResponse.redirect(new URL('/create-po', request.url).toString());
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
