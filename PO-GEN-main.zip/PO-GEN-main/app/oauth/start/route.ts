import { NextResponse } from 'next/server';
import { createOAuthClient } from '@/lib/google/client';

export async function GET() {
  try {
    const oauth2Client = createOAuthClient();
    const url = oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: ['https://www.googleapis.com/auth/spreadsheets', 'https://www.googleapis.com/auth/drive.file'],
      prompt: 'consent',
    });

    return NextResponse.redirect(url);
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 400 });
  }
}
