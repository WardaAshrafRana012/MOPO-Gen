'use client';

import { useEffect, useState, useCallback } from 'react';
import GlassCard from '@/components/ui/GlassCard';
import { RefreshCw } from 'lucide-react';

type LogEntry = Record<string, string>;

const STATUS_STYLES: Record<string, string> = {
  generated: 'bg-emerald-500/15 text-emerald-300',
  synced:    'bg-emerald-500/15 text-emerald-300',
  uploaded:  'bg-blue-500/15 text-blue-300',
  draft:     'bg-amber-500/15 text-amber-300',
  updated:   'bg-sky-500/15 text-sky-300',
  archived:  'bg-slate-700/60 text-slate-400',
  failed:    'bg-rose-500/15 text-rose-300',
};

function statusStyle(status: string) {
  const key = status?.toLowerCase() || '';
  return STATUS_STYLES[key] || 'bg-slate-700/60 text-slate-400';
}

function fmtTime(iso: string) {
  if (!iso) return '—';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleString('en-PK', {
    day:    '2-digit',
    month:  'short',
    year:   'numeric',
    hour:   '2-digit',
    minute: '2-digit',
  });
}

export default function ActivityPage() {
  const [logs,      setLogs]      = useState<LogEntry[]>([]);
  const [loading,   setLoading]   = useState(true);
  const [refreshing,setRefreshing]= useState(false);

  const load = useCallback(async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true);
    else setLoading(true);
    try {
      const res  = await fetch('/api/activity');
      const data = await res.json();
      setLogs((data?.data ?? []).reverse()); // newest first
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="space-y-6 py-6">

      {/* Header */}
      <GlassCard className="p-8">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="section-heading">Activity Logs</p>
            <h1 className="page-heading mt-1">System Activity</h1>
            <p className="mt-3 max-w-2xl text-sm text-slate-400">
              Every PO action — create, update, PDF generation, Drive upload, archive — is recorded here automatically.
            </p>
          </div>
          <button
            type="button"
            onClick={() => load(true)}
            disabled={refreshing}
            className="secondary-button inline-flex items-center gap-2 text-sm"
          >
            <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </GlassCard>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: 'Total Logs',    val: logs.length },
          { label: 'PO Generated',  val: logs.filter((l) => l.Action?.toLowerCase().includes('generat')).length },
          { label: 'Drive Uploads', val: logs.filter((l) => l.Action?.toLowerCase().includes('drive')).length },
          { label: 'Archived',      val: logs.filter((l) => l.Action?.toLowerCase().includes('archive')).length },
        ].map(({ label, val }) => (
          <GlassCard key={label} className="p-4">
            <p className="text-xs uppercase tracking-wider text-slate-500">{label}</p>
            <p className="mt-1 text-2xl font-semibold text-slate-100">
              {loading ? <span className="inline-block h-7 w-10 animate-pulse rounded-lg bg-slate-800" /> : val}
            </p>
          </GlassCard>
        ))}
      </div>

      {/* Table */}
      <GlassCard className="overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="min-w-full border-separate border-spacing-0 text-left text-sm">
            <thead>
              <tr className="bg-slate-950/90 text-xs uppercase tracking-wider text-slate-500">
                <th className="px-5 py-3.5 font-medium">Time</th>
                <th className="px-5 py-3.5 font-medium">Action</th>
                <th className="px-5 py-3.5 font-medium">PO Number</th>
                <th className="px-5 py-3.5 font-medium">User</th>
                <th className="px-5 py-3.5 font-medium">Status</th>
                <th className="px-5 py-3.5 font-medium">Details</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i} className="border-t border-white/5">
                    {Array.from({ length: 6 }).map((_, j) => (
                      <td key={j} className="px-5 py-4">
                        <span className="inline-block h-3 w-24 animate-pulse rounded bg-slate-800" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : logs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-12 text-center text-slate-500">
                    No activity logs yet. They will appear here after you create POs.
                  </td>
                </tr>
              ) : (
                logs.map((log, i) => (
                  <tr key={`${log.Log_ID || i}`} className="border-t border-white/5 text-slate-200 transition hover:bg-white/[0.04]">
                    <td className="px-5 py-3.5 whitespace-nowrap text-slate-400 text-xs">{fmtTime(log.Time)}</td>
                    <td className="px-5 py-3.5 whitespace-nowrap font-medium text-slate-100">{log.Action}</td>
                    <td className="px-5 py-3.5 whitespace-nowrap font-mono text-xs text-champagne">{log.PO_Number || '—'}</td>
                    <td className="px-5 py-3.5 whitespace-nowrap text-slate-400">{log.User || '—'}</td>
                    <td className="px-5 py-3.5">
                      <span className={`inline-flex rounded-full px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${statusStyle(log.Status)}`}>
                        {log.Status || '—'}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-slate-400 max-w-xs truncate" title={log.Details}>{log.Details || '—'}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
}
