import type { ReactNode } from 'react';

// Login uses the root layout (AppShell), which hides the sidebar/topbar
// on paths that start with /login via the hideNavigation check.
export default function LoginLayout({ children }: { children: ReactNode }) {
  return <>{children}</>;
}
