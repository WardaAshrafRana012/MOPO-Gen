'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import GlassCard from '@/components/ui/GlassCard';

export default function LoginPage() {
  const router = useRouter();
  const [user, setUser] = useState('');

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    localStorage.setItem('mopo-user', user || 'Molecule User');
    router.push('/dashboard');
  }

  return (
    <div className="grid min-h-screen place-items-center px-4 py-10">
      <GlassCard className="w-full max-w-md p-8">
        <div className="space-y-6 text-center">
          <div className="mx-auto inline-flex h-14 w-14 items-center justify-center rounded-3xl bg-gradient-to-br from-amber-300/20 to-white/10 text-2xl text-amber-200">M</div>
          <div>
            <p className="text-sm uppercase tracking-[0.32em] text-slate-500">Welcome back</p>
            <h1 className="mt-3 text-3xl font-semibold text-slate-100">Sign in to MOPO</h1>
          </div>
          <p className="text-sm leading-6 text-slate-400">Use the Molecule PO manager to create purchase orders, preview PDFs, and store all records in Google Sheets.</p>
        </div>

        <form onSubmit={handleSubmit} className="mt-8 space-y-5">
          <label className="block text-sm font-medium text-slate-200">Your name</label>
          <input
            value={user}
            onChange={(event) => setUser(event.target.value)}
            placeholder="Enter your name"
            className="input-field"
          />

          <button type="submit" className="primary-button w-full">Continue</button>
        </form>
      </GlassCard>
    </div>
  );
}
