import type { ReactNode } from 'react';
import './globals.css';
import AppShell from '@/components/layout/AppShell';

export const metadata = {
  title: 'MOPO â€” Molecule Purchase Order Manager',
  description: 'Luxury purchase order manager for Molecule Work Place Solution',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
