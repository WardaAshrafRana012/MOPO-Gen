import EditablePOComposer from '@/components/po/EditablePOComposer';

export default function CreatePOPage() {
  return <EditablePOComposer />;
}
