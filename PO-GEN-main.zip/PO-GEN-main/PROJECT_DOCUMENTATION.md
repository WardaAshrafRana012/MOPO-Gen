# Project Documentation

## Project Name

Molecule PO Automation App

## Purpose

This project is a local web application that reads purchase request rows from a Google Sheet, generates Purchase Order PDFs from a fixed company template, uploads those PDFs to Google Drive, and writes the results back to the same sheet.

In simple terms, it turns spreadsheet rows into finished PO documents with as little manual work as possible.

## What The Project Does

The app is designed to:

- connect to a Google Sheet
- find rows that should generate a PO
- validate the row data
- generate a PO number
- fill a local PDF template with row data
- upload the generated PDF to Google Drive
- save the PDF link back into the Google Sheet
- show operators the row queue, status, history, and previews in a web UI

## Main User Workflow

1. A user prepares purchase request rows inside a Google Sheet.
2. A checkbox column such as `Generate PO` marks which rows are ready.
3. The app reads the configured sheet and header row.
4. It identifies rows that are checked and contain meaningful purchase data.
5. It validates required fields like vendor, date, description, quantity, unit price, and delivery details.
6. If required data is missing, it writes a `Missing Data` style status back to the sheet.
7. If data is complete, it renders a new PO PDF using the local template.
8. The PDF is uploaded to Google Drive.
9. The app writes back:
   - `PO Number`
   - `Status`
   - `PO PDF` link
10. The operator can review the results in the app dashboard and history pages.

## Core Functionalities

### 1. Google Sheet Integration

The app reads spreadsheet data from a configured Google Sheet.

It supports configurable column names for:

- checkbox column
- PO number column
- date column
- vendor column
- project reference column
- description column
- quantity column
- unit price column
- amount column
- requested by column
- bill / quote type column
- item category column
- delivery date column
- delivery address column
- delivery instructions column
- telephone column
- status column
- PDF link column

The backend reads and maps this configuration in [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:159).

### 2. Row Validation

Each row is checked before generation.

The validation logic ensures the app does not create incomplete POs. If fields are missing, the row is not generated and its status is updated in the sheet.

This behavior is part of the processing flow in [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:1346).

### 3. PO Number Generation

The app generates a PO number based on vendor naming rules.

The PO helper code is in [src/poTemplate.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/src/poTemplate.ts:1).

Example behavior:

- vendor name is normalized
- a short vendor token is built
- a PO number like `PO-4000-XXX` is created

### 4. PDF Template Filling

The app uses a local PDF file as the PO template and writes the row values onto it.

It fills fields such as:

- vendor name
- PO number
- PO date
- delivery date
- reference
- item description
- quantity
- unit price
- amount
- amount in words
- delivery address
- delivery instructions
- telephone
- prepared by
- item category

The main rendering logic is in [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:1008).

### 5. Google Drive Upload

After a PDF is rendered, it is uploaded to Google Drive.

If `GOOGLE_DRIVE_FOLDER_ID` is provided, the file is uploaded into that specific folder. If not, it uploads to the authenticated account’s default Drive location.

The upload logic is in [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:1242).

### 6. Sheet Writeback

After successful generation, the app writes data back into the spreadsheet, including:

- PO number
- PO date
- vendor
- project reference
- description
- quantity
- unit price
- amount
- PDF URL
- generated status

This writeback happens through batch updates in [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:1279) and inside the processing loop in [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:1412).

### 7. Bulk and Single-Row Processing

The app supports:

- processing all pending checked rows
- processing selected rows
- processing a single row
- regenerating existing rows

The processing entry points are:

- `/api/process`
- `/api/process/pending`
- `/api/process/row/:rowNumber`

Defined in [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:1725).

### 8. Row Preview

Before generating a PDF, the operator can preview row data and preview the filled template.

The app exposes:

- row data preview
- inline PDF preview
- static template page previews if preview images exist

Related endpoints:

- `/api/template/row/:rowNumber/data`
- `/api/template/row/:rowNumber/preview`
- `/api/template/preview`

Defined in [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:1609), [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:1651), and [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:1680).

### 9. Runtime History and Sheet History

The app tracks two kinds of history:

- in-memory runtime history for processing activity in the current app session
- sheet history derived from generated rows and saved PDF links

This is built in [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:1503) and displayed in [src/App.jsx](/abs/path/c:/Users/umair/Downloads/mopo gen/src/App.jsx:941).

### 10. Auto Processing

The app can automatically poll the sheet and process checked rows at intervals.

This is controlled by:

- `AUTO_PROCESS_ENABLED`
- `POLL_INTERVAL_MS`

The polling startup logic is in [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:1874).

## Frontend Features

The frontend is a React single-page app defined mainly in [src/App.jsx](/abs/path/c:/Users/umair/Downloads/mopo gen/src/App.jsx:1).

### Welcome Page

Purpose:

- shows app readiness
- helps user connect Google
- explains what the tool does

### Overview Page

Purpose:

- shows summary metrics
- shows health state
- shows last run details
- provides quick actions
- previews a subset of sheet rows

Main data shown:

- total rows
- pending PO count
- generated PO count
- missing data count
- API status
- last run status
- recent logs

See [src/App.jsx](/abs/path/c:/Users/umair/Downloads/mopo gen/src/App.jsx:702).

### Sheet Settings Page

Purpose:

- displays live Google Sheet settings
- displays auth state
- shows current template and connection setup

See [src/App.jsx](/abs/path/c:/Users/umair/Downloads/mopo gen/src/App.jsx:781).

### Template Preview Page

Purpose:

- shows template preview images if available
- shows filled template data preview for a selected row

See [src/App.jsx](/abs/path/c:/Users/umair/Downloads/mopo gen/src/App.jsx:848).

### Generation Queue Page

Purpose:

- shows all loaded rows
- allows selecting rows
- supports bulk generation
- supports bulk regeneration
- supports previewing a row before generation

See [src/App.jsx](/abs/path/c:/Users/umair/Downloads/mopo gen/src/App.jsx:884).

### Run History Page

Purpose:

- shows runtime processing history
- shows generated sheet history
- provides quick visibility into previous actions and results

See [src/App.jsx](/abs/path/c:/Users/umair/Downloads/mopo gen/src/App.jsx:941).

## Backend Responsibilities

The backend is a single Express server in [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:1).

It is responsible for:

- reading environment configuration
- managing authentication
- creating Google Sheets and Google Drive clients
- reading sheet rows
- validating row data
- rendering PDFs
- uploading files
- updating sheet cells
- storing in-memory process status and runtime logs
- serving API endpoints
- serving the frontend static files

## Authentication Modes

The app supports two authentication modes.

### 1. OAuth Client

Used when a real Google user signs in.

Needed variables:

- `GOOGLE_OAUTH_CLIENT_ID`
- `GOOGLE_OAUTH_CLIENT_SECRET`
- `GOOGLE_OAUTH_REDIRECT_URI`

Token file:

- `.local\google-oauth-tokens.json`

OAuth endpoints:

- `/oauth/start`
- `/oauth/callback`
- `/api/oauth/disconnect`

Relevant code:

- [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:1816)
- [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:1835)
- [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:1802)

### 2. Service Account

Used when the app authenticates as a service account instead of a signed-in user.

Needed variables:

- `GOOGLE_SERVICE_ACCOUNT_EMAIL`
- `GOOGLE_PRIVATE_KEY`
- `GOOGLE_PROJECT_ID`
- optional `GOOGLE_IMPERSONATE_USER`

This mode is created in [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:486).

## Google API Connections

### Google Sheets API

Used for:

- reading headers
- reading rows
- updating row cells
- toggling checkbox values
- writing generated status

Scopes requested:

- `https://www.googleapis.com/auth/spreadsheets`

### Google Drive API

Used for:

- uploading generated PDFs
- optionally applying public sharing permissions
- returning Drive file links

Scopes requested:

- `https://www.googleapis.com/auth/drive`

### Note About AI

The package `@google/genai` exists in dependencies, but it is not used in the active PO generation flow that runs this project today.

## API Endpoints

### Health and Config

- `GET /api/health`
  - basic readiness and auth summary
- `GET /api/config`
  - frontend-visible config and settings
- `GET /api/oauth/status`
  - OAuth mode, readiness, token status
- `GET /api/status`
  - current runtime state, logs, and processing summary

### Template and Preview

- `GET /api/template/preview`
  - returns available template preview images
- `GET /api/template/image/:pageNumber`
  - serves template page images
- `POST /api/po/template/text`
  - generates structured PO template text data from input JSON
- `GET /api/template/row/:rowNumber/data`
  - returns parsed row data and row preview
- `GET /api/template/row/:rowNumber/preview`
  - streams a generated preview PDF for a single row

### Rows and History

- `GET /api/rows`
  - returns current sheet rows and dashboard metrics
- `GET /api/history`
  - returns runtime history and generated row history

### Processing

- `POST /api/process`
  - process checked rows or explicitly selected rows
- `POST /api/process/pending`
  - process all pending checked rows
- `POST /api/process/row/:rowNumber`
  - process one row

### Row Checkbox Updates

- `POST /api/rows/bulk-check`
  - update checkbox values for many rows
- `POST /api/rows/:rowNumber/toggle`
  - toggle checkbox for one row

### OAuth Actions

- `POST /api/oauth/disconnect`
  - removes stored OAuth tokens

## Environment Variables

The current config example is in [.env.example](/abs/path/c:/Users/umair/Downloads/mopo gen/.env.example:1).

### Server

- `PORT`
  - local server port

### Google Sheet

- `GOOGLE_SHEET_ID`
  - target spreadsheet ID
- `GOOGLE_SHEET_NAME`
  - target tab name
- `GOOGLE_HEADER_ROW`
  - row number containing headers

### Column Mapping

- `GOOGLE_CHECKBOX_COLUMN`
- `GOOGLE_DATE_COLUMN`
- `GOOGLE_VENDOR_COLUMN`
- `GOOGLE_PROJECT_REFERENCE_COLUMN`
- `GOOGLE_DESCRIPTION_COLUMN`
- `GOOGLE_QUANTITY_COLUMN`
- `GOOGLE_UNIT_PRICE_COLUMN`
- `GOOGLE_AMOUNT_COLUMN`
- `GOOGLE_REQUESTED_BY_COLUMN`
- `GOOGLE_BILL_QUOTE_TYPE_COLUMN`
- `GOOGLE_ITEM_CATEGORY_COLUMN`
- `GOOGLE_DELIVERY_DATE_COLUMN`
- `GOOGLE_PDF_COLUMN`
- `GOOGLE_STATUS_COLUMN`
- `GOOGLE_PO_NUMBER_COLUMN`

### Template

- `PO_TEMPLATE_PATH`
  - full local path of the PO PDF template

### OAuth

- `GOOGLE_OAUTH_CLIENT_ID`
- `GOOGLE_OAUTH_CLIENT_SECRET`
- `GOOGLE_OAUTH_REDIRECT_URI`
- `GOOGLE_OAUTH_TOKEN_PATH`

### Service Account

- `GOOGLE_SERVICE_ACCOUNT_EMAIL`
- `GOOGLE_PRIVATE_KEY`
- `GOOGLE_PROJECT_ID`
- `GOOGLE_IMPERSONATE_USER`

### Google Drive

- `GOOGLE_DRIVE_FOLDER_ID`
  - folder where generated PDFs should be uploaded

### Company Branding / Template Text

- `COMPANY_NAME`
- `COMPANY_DELIVERY_ADDRESS`
- `COMPANY_TELEPHONE`
- `PO_PREFIX`

### Processing Behavior

- `POLL_INTERVAL_MS`
- `AUTO_PROCESS_ENABLED`
- `MAKE_PDF_PUBLIC`

## File and Folder Structure

### Main Files

- [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:1)
  - Express backend, Google API integration, PDF generation, processing logic
- [src/App.jsx](/abs/path/c:/Users/umair/Downloads/mopo gen/src/App.jsx:1)
  - main React application UI
- [src/poTemplate.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/src/poTemplate.ts:1)
  - PO helper formatting and PO number generation
- [src/styles.css](/abs/path/c:/Users/umair/Downloads/mopo gen/src/styles.css:1)
  - frontend styles
- [src/main.jsx](/abs/path/c:/Users/umair/Downloads/mopo gen/src/main.jsx:1)
  - React entry point
- [README.md](/abs/path/c:/Users/umair/Downloads/mopo gen/README.md:1)
  - shorter setup overview

### Important Local Runtime Files

- `.env`
  - actual environment config
- `.local\google-oauth-tokens.json`
  - stored OAuth tokens
- `.local\*.log`
  - local logs and preview files

## Processing Logic Summary

The most important function in the app is `processRows`.

It does the following:

1. prevents multiple processing jobs from running at once
2. reads the sheet snapshot
3. finds candidate rows
4. narrows them to checked or selected rows
5. skips already-generated rows unless regenerate mode is on
6. marks incomplete rows as missing data
7. renders PDFs for valid rows
8. uploads PDFs to Drive
9. writes row updates back to the sheet
10. saves runtime records and logs

Main code:

- [server.ts](/abs/path/c:/Users/umair/Downloads/mopo gen/server.ts:1346)

## Strengths Of This Project

- practical operator-focused UI
- configurable sheet column mapping
- two Google auth modes
- supports both manual and automatic processing
- generates preview PDFs before final generation
- keeps the spreadsheet as the source of truth
- no separate database required

## Current Limitations

- runtime history is in memory, so it is not a full permanent audit log
- template coordinates and layout are hardcoded to the current PO format
- there is no user/role system in the app itself
- there is no queue worker or retry system beyond the current process loop
- there is no dedicated database for long-term records
- the app is built around a specific PO workflow rather than a generic document engine

## Recommended Future Improvements

- save processing history to a database or durable file store
- add template profile support for multiple PO formats
- add better validation messages per field
- add retry and dead-letter handling for failed generations
- add download/export of runtime history
- add role-based access if multiple operators will use it
- add better Drive folder management and per-client organization
- add unit and integration tests around row parsing and PDF generation

## Technical Stack

- React 19
- Vite
- Express 4
- TypeScript runtime via `tsx`
- Google Sheets API
- Google Drive API
- `google-auth-library`
- `pdf-lib`
- `number-to-words`
- plain CSS for UI styling

The dependency list is in [package.json](/abs/path/c:/Users/umair/Downloads/mopo gen/package.json:1).

## Short Business Summary

This system automates purchase order creation from spreadsheet data. Instead of manually copying row data into a PO document, exporting a PDF, uploading it to Drive, and pasting the link back into the sheet, the application performs the full flow automatically. It reduces manual work, improves consistency, and gives the team a simple dashboard to review generation status, previews, and history.
