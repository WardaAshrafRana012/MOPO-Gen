﻿'use client';

import { useEffect, useMemo, useState } from 'react';
import Image from 'next/image';
import GlassCard from '@/components/ui/GlassCard';
import { formatAmountInWords, formatCurrency, generatePoNumber, getNextVendorSerial } from '@/lib/utils/format';
import {
  ATTACHMENT_OPTIONS,
  DELIVERY_ADDRESS_OPTIONS,
  DELIVERY_INSTRUCTION_OPTIONS,
  PO_BASED_ON_OPTIONS,
} from '@/lib/po-template';
import type { PurchaseOrderPayload } from '@/types/po';

type ItemRow = {
  id: string;
  description: string;
  category: string;
  quantity: string;
  quantityType: string;
  unitPrice: string;
};

type ExistingRecord = {
  main?: {
    vendorName?: string;
    poNumber?: string;
    poDate?: string;
    deliveryDate?: string;
    projectReference?: string;
    poBasedOn?: string;
    deliveryAddress?: string;
    preparedBy?: string;
    deliveryInstructions?: string[];
    attachments?: string[];
  };
  items?: Array<{
    itemId?: string;
    description?: string;
    category?: string;
    quantity?: number;
    quantityType?: string;
    unitPrice?: number;
    poType?: string;
  }>;
};

const ITEM_CATEGORIES = [
  'Furniture',
  'Paint Works',
  'Partition Works',
  'Air-Con Works',
  'Ceiling Works',
  'Flooring Works',
  'Electrical Works',
  'Civil & Interior Works',
  'Cartage & Divy',
  'Plumb & Sanitary Works',
  'Design Services',
  'Equip & Appliances',
  'Metal Works',
  'Proj Mng Services',
  'Samples',
];

const QTY_TYPES = ['Unit', 'PCS', 'Set', 'Job', 'RFT', 'SFT'];
const MOLECULE_OFFICE = 'Molecule Office';
const LEGACY_REF_IMAGE = 'Reference Image';

const createEmptyItem = (): ItemRow => ({
  id: Math.random().toString(36).slice(2, 11),
  description: '',
  category: '',
  quantity: '',
  quantityType: '',
  unitPrice: '',
});

function normalizeExistingItems(existing?: ExistingRecord['items']): ItemRow[] {
  if (!existing?.length) return [createEmptyItem()];
  return existing.map((item) => ({
    id: item.itemId || Math.random().toString(36).slice(2, 11),
    description: item.description || '',
    category: item.category || '',
    quantity: item.quantity ? String(item.quantity) : '',
    quantityType: item.quantityType || '',
    unitPrice: item.unitPrice ? String(item.unitPrice) : '',
  }));
}

function inferDeliveryOption(value?: string) {
  if (!value) return MOLECULE_OFFICE;
  return DELIVERY_ADDRESS_OPTIONS.includes(value as (typeof DELIVERY_ADDRESS_OPTIONS)[number]) ? value : 'Other';
}

function parseAttachment(values: string[] = []) {
  const normalized = values.filter(Boolean);
  const first = normalized[0] || '';
  if (!first) {
    return { selected: '', custom: '' };
  }

  if (first === LEGACY_REF_IMAGE) {
    return { selected: 'Ref Image', custom: '' };
  }

  if (ATTACHMENT_OPTIONS.includes(first as (typeof ATTACHMENT_OPTIONS)[number])) {
    return { selected: first, custom: '' };
  }

  return { selected: 'Other', custom: first };
}

function formatDisplayDate(value?: string) {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
}

export default function EditablePOComposer({ existing, poId }: { existing?: ExistingRecord; poId?: string }) {
  const existingMain = existing?.main;
  const existingAttachment = parseAttachment(existingMain?.attachments || []);
  const existingBasedOn = existingMain?.poBasedOn || existing?.items?.[0]?.poType || '';
  const existingDeliveryAddress = existingMain?.deliveryAddress || '';

  const [vendorName, setVendorName] = useState(existingMain?.vendorName || '');
  const [poNumber, setPoNumber] = useState(existingMain?.poNumber || '');
  const [poDate, setPoDate] = useState(existingMain?.poDate || '');
  const [deliveryDate, setDeliveryDate] = useState(existingMain?.deliveryDate || '');
  const [projectReference, setProjectReference] = useState(existingMain?.projectReference || '');
  const [poBasedOn, setPoBasedOn] = useState(existingBasedOn);
  const [deliveryAddressOption, setDeliveryAddressOption] = useState(inferDeliveryOption(existingDeliveryAddress));
  const [deliveryAddressOther, setDeliveryAddressOther] = useState(inferDeliveryOption(existingDeliveryAddress) === 'Other' ? existingDeliveryAddress : '');
  const [orderedBy, setOrderedBy] = useState(existingMain?.preparedBy || '');
  const [deliveryInstructions, setDeliveryInstructions] = useState<string[]>(existingMain?.deliveryInstructions || []);
  const [attachmentSelection, setAttachmentSelection] = useState(existingAttachment.selected);
  const [attachmentImageUrl, setAttachmentImageUrl] = useState('');
  const [attachmentImageName, setAttachmentImageName] = useState('');
  const [items, setItems] = useState<ItemRow[]>(normalizeExistingItems(existing?.items));
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [pdfLink, setPdfLink] = useState('');
  const [existingNos, setExistingNos] = useState<string[]>([]);
  const [poPrefix, setPoPrefix] = useState('PO');
  const [settings, setSettings] = useState<Record<string, string>>({});

  useEffect(() => {
    void fetch('/api/settings').then((r) => r.json()).then((d) => {
      setSettings(d?.data || {});
      setPoPrefix(d?.data?.PO_PREFIX || 'PO');
    }).catch(() => undefined);

    void fetch('/api/po').then((r) => r.json()).then((d) => setExistingNos((d?.data || []).map((po: { poNumber: string }) => po.poNumber))).catch(() => undefined);
  }, []);

  useEffect(() => {
    if (poId || !vendorName.trim()) return;
    setPoNumber(generatePoNumber(vendorName, getNextVendorSerial(existingNos, vendorName, poPrefix), poPrefix));
  }, [vendorName, existingNos, poPrefix, poId]);

  const computedItems = useMemo(() => items.map((item) => {
    const quantity = Number(item.quantity || 0);
    const unitPrice = Number(item.unitPrice || 0);
    return { ...item, quantity, unitPrice, amount: quantity * unitPrice };
  }), [items]);

  const totalAmount = useMemo(() => computedItems.reduce((sum, item) => sum + item.amount, 0), [computedItems]);
  const amountInWords = useMemo(() => formatAmountInWords(totalAmount).toUpperCase() + ' ONLY', [totalAmount]);

  const companyAddress = settings.COMPANY_ADDRESS || '47-B, Main Kh-e-Shamsheer, DHA-5, Karachi';
  const resolvedDeliveryAddress = deliveryAddressOption === 'Other' ? deliveryAddressOther.trim() : deliveryAddressOption;
  const resolvedAttachments = attachmentSelection ? [attachmentSelection] : [];
  const attachmentHeading = attachmentSelection || 'Image Attachment';

  function updateItem(id: string, patch: Partial<ItemRow>) {
    setItems((current) => current.map((item) => (item.id === id ? { ...item, ...patch } : item)));
  }

  function addItem() {
    setItems((current) => [...current, createEmptyItem()]);
  }

  function removeLastItem() {
    setItems((current) => (current.length === 1 ? current : current.slice(0, -1)));
  }

  function toggleInstruction(value: string) {
    setDeliveryInstructions((current) => current.includes(value) ? current.filter((item) => item !== value) : [...current, value]);
  }

  function handleAttachmentImageChange(file?: File | null) {
    if (!file) {
      setAttachmentImageUrl('');
      setAttachmentImageName('');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setAttachmentImageUrl(typeof reader.result === 'string' ? reader.result : '');
      setAttachmentImageName(file.name);
    };
    reader.readAsDataURL(file);
  }

  function validate() {
    if (!vendorName.trim()) return 'Vendor name is required.';
    if (!poDate.trim()) return 'PO date is required.';
    if (!projectReference.trim()) return 'Project reference is required.';
    if (!poBasedOn.trim()) return 'PO Based On is required.';
    if (!resolvedDeliveryAddress) return 'Delivery address is required.';
    if (!orderedBy.trim()) return 'Ordered By is required.';
    for (const item of computedItems) {
      if (!item.description.trim()) return 'Each item needs a description.';
      if (!item.category.trim()) return 'Each item needs a category.';
      if (item.quantity <= 0) return 'Each item quantity must be greater than 0.';
      if (item.unitPrice <= 0) return 'Each item unit price must be greater than 0.';
    }
    return '';
  }

  async function savePO() {
    const error = validate();
    if (error) {
      setMessage({ ok: false, text: error });
      return;
    }

    setSaving(true);
    setMessage(null);

    try {
      const payload: PurchaseOrderPayload = {
        vendorName,
        poDate,
        deliveryDate,
        projectReference,
        poBasedOn,
        deliveryAddress: resolvedDeliveryAddress,
        preparedBy: orderedBy,
        deliveryInstructions,
        attachments: resolvedAttachments,
        itemCategory: computedItems[0]?.category || '',
        items: computedItems.map((item) => ({
          description: item.description,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          category: item.category,
          quantityType: item.quantityType,
          poType: poBasedOn,
        })),
        saveDraft: false,
      };

      const res = await fetch(poId ? `/api/po/${poId}` : '/api/po', {
        method: poId ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Unable to save PO.');
      setPdfLink(data?.data?.pdfLink || '');
      setMessage({ ok: true, text: `PO ${data?.data?.poNumber || poNumber} ${poId ? 'updated' : 'generated'} successfully.` });
    } catch (error) {
      setMessage({ ok: false, text: error instanceof Error ? error.message : String(error) });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6 py-6">
      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_340px]">
        <GlassCard className="overflow-hidden p-0">
          <div className="border-b border-white/8 px-8 py-6">
            <p className="section-heading">{poId ? 'Edit PO' : 'Create PO'}</p>
            <h1 className="page-heading mt-1">Vendor Purchase Order</h1>
            <p className="mt-3 max-w-2xl text-sm text-slate-400">Edit directly on the PO layout and keep the preview and generated PDF aligned.</p>
          </div>

          <div className="overflow-x-auto bg-[#eef1f6] p-6">
            <div className="mx-auto w-full max-w-[980px] rounded-[28px] border border-slate-200 bg-white p-10 text-slate-900 shadow-[0_30px_80px_rgba(15,23,42,0.18)]">
              <div className="flex items-start justify-between gap-8">
                <div className="flex items-start gap-4">
                  <Image src="/molecule-logo.png" alt="Molecule" width={84} height={84} className="h-[84px] w-[84px] object-contain" priority />
                  <div>
                    <div className="text-[24px] font-semibold leading-none">Molecule</div>
                    <div className="mt-3 text-[13px] text-slate-600">{companyAddress}</div>
                  </div>
                </div>

                <div className="w-full max-w-[360px] space-y-3 text-right text-[14px]">
                  <EditableMetaRow label="Vendor Name:" value={vendorName} onChange={setVendorName} placeholder="Vendor" />
                  <EditableMetaRow label="PO Number:" value={poNumber} readOnly placeholder="Auto generated" />
                  <EditableDateRow label="PO Date:" value={poDate} onChange={setPoDate} placeholder="Select date" />
                  <EditableMetaRow label="Project Reference:" value={projectReference} onChange={setProjectReference} placeholder="Reference" />
                  <EditableSelectRow label="PO Based On:" value={poBasedOn} onChange={setPoBasedOn} options={PO_BASED_ON_OPTIONS as unknown as string[]} placeholder="Select" />
                  <EditableDateRow label="Delivery Date:" value={deliveryDate} onChange={setDeliveryDate} placeholder="Select date" />
                </div>
              </div>

              <h2 className="mt-12 text-[46px] font-normal leading-none tracking-tight">VENDOR PURCHASE ORDER</h2>

              <div className="mt-10 overflow-hidden border border-slate-300">
                <div className="grid grid-cols-[minmax(0,1fr)_80px_98px_144px_128px] bg-slate-100 text-[13px] font-semibold">
                  <div className="border-r border-slate-300 px-3 py-3">Brief Detail of Major Type Of Item / Service</div>
                  <div className="border-r border-slate-300 px-3 py-3 text-center">Qty</div>
                  <div className="border-r border-slate-300 px-3 py-3 text-center">Qty Type</div>
                  <div className="border-r border-slate-300 px-3 py-3 text-center">Unit Price</div>
                  <div className="px-3 py-3 text-center">Amount PKR</div>
                </div>

                {computedItems.map((item) => (
                  <div key={item.id} className="grid grid-cols-[minmax(0,1fr)_80px_98px_144px_128px] border-t border-slate-300 text-[13px]">
                    <div className="border-r border-slate-300 px-3 py-3">
                      <input value={item.description} onChange={(e) => updateItem(item.id, { description: e.target.value })} className="w-full border-0 bg-transparent px-0 py-0 text-[15px] outline-none" placeholder="Item description" />
                      <select value={item.category} onChange={(e) => updateItem(item.id, { category: e.target.value })} className="mt-2 w-full border-0 bg-transparent px-0 py-0 text-[12px] text-slate-500 outline-none">
                        <option value="">Category</option>
                        {ITEM_CATEGORIES.map((category) => <option key={category} value={category}>{category}</option>)}
                      </select>
                    </div>
                    <div className="border-r border-slate-300 px-3 py-3"><input value={item.quantity} onChange={(e) => updateItem(item.id, { quantity: e.target.value.replace(/[^\d]/g, '') })} className="w-full border-0 bg-transparent px-0 py-0 text-center outline-none" placeholder="Qty" inputMode="numeric" /></div>
                    <div className="border-r border-slate-300 px-3 py-3">
                      <select value={item.quantityType} onChange={(e) => updateItem(item.id, { quantityType: e.target.value })} className="w-full border-0 bg-transparent px-0 py-0 text-center outline-none">
                        <option value="">Select</option>
                        {QTY_TYPES.map((type) => <option key={type} value={type}>{type}</option>)}
                      </select>
                    </div>
                    <div className="border-r border-slate-300 px-3 py-3"><input value={item.unitPrice} onChange={(e) => updateItem(item.id, { unitPrice: e.target.value.replace(/[^\d.]/g, '') })} className="w-full border-0 bg-transparent px-0 py-0 text-right outline-none" placeholder="Unit price" inputMode="decimal" /></div>
                    <div className="px-3 py-3 text-right font-medium">{new Intl.NumberFormat('en-PK').format(item.amount)}</div>
                  </div>
                ))}

                <div className="grid grid-cols-[minmax(0,1fr)_80px_98px_144px_128px] border-t border-slate-300 bg-slate-100 text-[13px]">
                  <div className="col-span-3 px-3 py-3 font-semibold">{amountInWords}</div>
                  <div className="border-l border-r border-slate-300 px-3 py-3 text-center font-semibold">TOTAL</div>
                  <div className="px-3 py-3 text-right font-bold">{new Intl.NumberFormat('en-PK').format(totalAmount)}</div>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-3">
                <button type="button" onClick={addItem} className="rounded-full border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 transition hover:border-slate-900 hover:text-slate-900">+ Add Item Row</button>
                {items.length > 1 ? <button type="button" onClick={removeLastItem} className="rounded-full border border-rose-200 px-4 py-2 text-sm font-medium text-rose-600 transition hover:border-rose-500 hover:text-rose-700">Remove Last Item</button> : null}
              </div>

              <div className="mt-8">
                <div className="text-[18px] font-semibold uppercase tracking-[0.14em] text-slate-900">Image Attachment</div>
                <div className="mt-3 grid gap-3 sm:grid-cols-[minmax(0,1fr)_1.1fr]">
                  <div className="rounded-3xl border border-slate-300 px-4 py-4">
                    <label className="text-[11px] font-semibold uppercase tracking-[0.26em] text-slate-500">Select Image Type</label>
                    <select
                      value={attachmentSelection}
                      onChange={(e) => {
                        setAttachmentSelection(e.target.value);
                        setAttachmentImageUrl('');
                        setAttachmentImageName('');
                      }}
                      className="mt-3 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm outline-none transition focus:border-slate-400"
                    >
                      <option value="">Choose option</option>
                      {ATTACHMENT_OPTIONS.map((option) => <option key={option} value={option}>{option}</option>)}
                    </select>

                    {attachmentSelection ? (
                      <div className="mt-4">
                        <label className="text-[11px] font-semibold uppercase tracking-[0.26em] text-slate-500">Upload {attachmentHeading}</label>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleAttachmentImageChange(e.target.files?.[0] || null)}
                          className="mt-3 block w-full rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-4 py-3 text-sm text-slate-700 file:mr-4 file:rounded-full file:border-0 file:bg-slate-900 file:px-4 file:py-2 file:text-sm file:font-medium file:text-white hover:file:bg-slate-700"
                        />
                      </div>
                    ) : null}
                  </div>
                  <div className="rounded-3xl border border-slate-300 px-4 py-4 text-sm text-slate-500">
                    <p className="text-[11px] font-semibold uppercase tracking-[0.26em] text-slate-500">Preview</p>
                    {attachmentSelection ? (
                      <div className="mt-3 space-y-3 text-slate-800">
                        <div className="text-[18px] font-semibold uppercase tracking-[0.14em] text-slate-900">{attachmentHeading}</div>
                        {attachmentImageUrl ? (
                          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-slate-50 p-3">
                            <img src={attachmentImageUrl} alt={attachmentHeading} className="h-52 w-full rounded-xl object-contain" />
                            <p className="mt-3 truncate text-xs text-slate-500">{attachmentImageName}</p>
                          </div>
                        ) : (
                          <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-4 py-10 text-center text-slate-500">
                            Upload an image for {attachmentHeading}.
                          </div>
                        )}
                      </div>
                    ) : (
                      <p className="mt-3 text-slate-700">Choose Sample, Drawing, Ref Image, or Other, then add the image under the same heading.</p>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-10">
                <h3 className="text-[32px] font-normal tracking-tight">DELIVERY DETAILS</h3>
                <div className="mt-4 grid grid-cols-[54%_46%] border border-slate-300">
                  <div className="border-r border-slate-300 px-5 py-5">
                    <div className="text-[13px] font-semibold uppercase">Delivery Address :</div>
                    <select value={deliveryAddressOption} onChange={(e) => setDeliveryAddressOption(e.target.value)} className="mt-2 w-full border-0 bg-transparent px-0 py-0 text-[15px] outline-none">
                      {DELIVERY_ADDRESS_OPTIONS.map((option) => <option key={option} value={option}>{option}</option>)}
                    </select>
                    {deliveryAddressOption === 'Other' ? <input value={deliveryAddressOther} onChange={(e) => setDeliveryAddressOther(e.target.value)} className="mt-3 w-full border-0 border-b border-slate-300 bg-transparent px-0 py-1 text-[15px] outline-none" placeholder="Custom delivery address" /> : null}
                    <div className="mt-4 text-[13px] font-semibold uppercase">Ordered By :</div>
                    <input value={orderedBy} onChange={(e) => setOrderedBy(e.target.value)} className="mt-2 w-full border-0 bg-transparent px-0 py-0 text-[15px] outline-none" placeholder="Ordered by" />
                  </div>
                  <div className="px-5 py-5">
                    <div className="text-[13px] font-semibold uppercase">Delivery Instructions</div>
                    <div className="mt-3 space-y-3">
                      {DELIVERY_INSTRUCTION_OPTIONS.map((option) => (
                        <label key={option} className="flex items-center gap-3 text-[15px]">
                          <input type="checkbox" checked={deliveryInstructions.includes(option)} onChange={() => toggleInstruction(option)} className="h-4 w-4 rounded border-slate-300" />
                          <span>{option}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </GlassCard>

        <div className="space-y-6">
          <GlassCard className="p-6">
            <p className="section-heading">Actions</p>
            <h2 className="mt-1 text-xl font-semibold text-slate-100">{poId ? 'Update From Template' : 'Generate From Template'}</h2>
            <p className="mt-3 text-sm text-slate-400">Fill the live PO document on the left. We keep numbering, calculations, Google save, and PDF generation connected.</p>
            <div className="mt-6 space-y-3">
              <div className="rounded-2xl border border-white/8 bg-slate-950/60 px-4 py-3"><div className="text-xs uppercase tracking-widest text-slate-500">Items</div><div className="mt-1 text-2xl font-semibold text-slate-100">{items.length}</div></div>
              <div className="rounded-2xl border border-white/8 bg-slate-950/60 px-4 py-3"><div className="text-xs uppercase tracking-widest text-slate-500">Total</div><div className="mt-1 text-2xl font-semibold text-champagne">{formatCurrency(totalAmount)}</div></div>
            </div>
            {message ? <div className={`mt-5 rounded-2xl border px-4 py-3 text-sm ${message.ok ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200' : 'border-rose-500/30 bg-rose-500/10 text-rose-200'}`}>{message.text}</div> : null}
            <div className="mt-6 flex flex-col gap-3">
              <button type="button" onClick={savePO} disabled={saving} className="primary-button justify-center text-sm">{saving ? 'Saving...' : poId ? 'Update PDF' : 'Generate PDF'}</button>
              {pdfLink ? <a href={pdfLink} target="_blank" rel="noreferrer" className="secondary-button justify-center text-sm">Open PDF</a> : null}
              {pdfLink ? <a href={`/api/po/download?url=${encodeURIComponent(pdfLink)}`} className="secondary-button justify-center text-sm">Download PDF</a> : null}
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  );
}

type EditableMetaRowProps = {
  label: string;
  value: string;
  onChange?: (value: string) => void;
  placeholder?: string;
  readOnly?: boolean;
};

function EditableMetaRow({ label, value, onChange, placeholder, readOnly = false }: EditableMetaRowProps) {
  return (
    <div className="grid grid-cols-[160px_1fr] items-center gap-3">
      <span className="font-semibold uppercase">{label}</span>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        readOnly={readOnly}
        placeholder={placeholder}
        className="w-full border-0 border-b border-slate-300 bg-transparent px-1 py-1 text-right outline-none"
      />
    </div>
  );
}

function EditableDateRow({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (value: string) => void; placeholder: string }) {
  return (
    <div className="grid grid-cols-[160px_1fr] items-center gap-3">
      <span className="font-semibold uppercase">{label}</span>
      <label className="relative block cursor-pointer border-b border-slate-300 px-1 py-1 text-right">
        <span className={`block pr-6 ${value ? 'text-slate-900' : 'text-slate-400'}`}>{value ? formatDisplayDate(value) : placeholder}</span>
        <input
          type="date"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="absolute inset-0 cursor-pointer opacity-0"
        />
      </label>
    </div>
  );
}

function EditableSelectRow({ label, value, onChange, options, placeholder }: { label: string; value: string; onChange: (value: string) => void; options: string[]; placeholder: string }) {
  return (
    <div className="grid grid-cols-[160px_1fr] items-center gap-3">
      <span className="font-semibold uppercase">{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)} className="w-full border-0 border-b border-slate-300 bg-transparent px-1 py-1 text-right outline-none">
        <option value="">{placeholder}</option>
        {options.map((option) => <option key={option} value={option}>{option}</option>)}
      </select>
    </div>
  );
}



