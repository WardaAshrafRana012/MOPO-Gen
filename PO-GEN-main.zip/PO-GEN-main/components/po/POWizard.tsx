﻿'use client';

import EditablePOComposer from '@/components/po/EditablePOComposer';

export default function POWizard({ existing, poId }: { existing?: any; poId?: string }) {
  return <EditablePOComposer existing={existing} poId={poId} />;
}
