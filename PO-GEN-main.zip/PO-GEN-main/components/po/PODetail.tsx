﻿'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import GlassCard from '@/components/ui/GlassCard';
import POPreview from '@/components/po/POPreview';
import { formatCurrency, formatDate } from '@/lib/utils/format';

export default function PODetail({ poId }: { poId: string }) {
  const [record, setRecord] = useState<any>(null);
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch(`/api/po/${poId}`).then((r) => r.json()),
      fetch('/api/settings').then((r) => r.json()),
    ]).then(([poData, sData]) => {
      setRecord(poData?.data ?? null);
      setSettings(sData?.data ?? {});
      setLoading(false);
    });
  }, [poId]);

  async function copyLink() {
    const link = record?.main?.pdfLink;
    if (!link) {
      setMessage('No PDF link available.');
      return;
    }
    await navigator.clipboard.writeText(link).catch(() => {});
    setMessage('PDF link copied.');
    setTimeout(() => setMessage(''), 3000);
  }

  if (loading) {
    return <div className="space-y-6 py-6"><GlassCard className="flex items-center gap-3 p-8 text-slate-400"><span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-champagne border-t-transparent" />Loading purchase order...</GlassCard></div>;
  }
  if (!record) {
    return <div className="space-y-6 py-6"><GlassCard className="p-12 text-center text-slate-400">Purchase order not found.</GlassCard></div>;
  }

  const { main, items } = record;

  return (
    <div className="space-y-6 py-6">
      <div className="grid gap-5 xl:grid-cols-[1.7fr_0.6fr]">
        <GlassCard className="p-8">
          <p className="section-heading">Purchase Order</p>
          <h1 className="page-heading mt-1">{main.poNumber}</h1>
          <p className="mt-2 text-slate-400">{main.vendorName}</p>
          {message ? <p className="mt-4 rounded-2xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-2 text-sm text-emerald-200">{message}</p> : null}
        </GlassCard>

        <GlassCard className="p-6">
          <p className="section-heading mb-4">Actions</p>
          <div className="flex flex-col gap-2">
            <Link href={`/po-records/${poId}/edit`} className="secondary-button w-full justify-center text-center text-sm">Edit PO</Link>
            {main.pdfLink ? <><a href={`/api/po/download?${main.pdfLink ? `url=${encodeURIComponent(main.pdfLink)}` : `fileId=${encodeURIComponent(main.driveFileId)}`}`} className="primary-button w-full justify-center text-center text-sm">Download PDF</a><a href={main.pdfLink} target="_blank" rel="noreferrer" className="secondary-button w-full justify-center text-center text-sm">Open in Drive</a><button type="button" onClick={copyLink} className="secondary-button w-full text-sm">Copy PDF Link</button></> : <div className="rounded-2xl border border-white/8 bg-slate-900/50 px-4 py-3 text-center text-sm text-slate-500">PDF not generated yet</div>}
            <Link href="/po-records" className="secondary-button w-full justify-center text-center text-sm text-slate-400">Back to Records</Link>
          </div>
        </GlassCard>
      </div>

      <GlassCard className="p-8">
        <p className="section-heading mb-5">PO Information</p>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {[
            ['Vendor Name', main.vendorName],
            ['PO Number', main.poNumber],
            ['PO Date', formatDate(main.poDate)],
            ['Delivery Date', main.deliveryDate ? formatDate(main.deliveryDate) : '-'],
            ['Project Reference', main.projectReference || '-'],
            ['PO Based On', main.poBasedOn || items?.[0]?.poType || '-'],
          ].map(([label, value]) => <div key={String(label)} className="rounded-2xl border border-white/8 bg-slate-950/60 p-4"><p className="text-xs uppercase tracking-wider text-slate-500">{label}</p><p className="mt-2 text-sm font-medium text-slate-100">{value}</p></div>)}
        </div>
      </GlassCard>

      <GlassCard className="p-8">
        <p className="section-heading mb-5">Items</p>
        <div className="overflow-x-auto rounded-2xl border border-white/8">
          <table className="min-w-full border-separate border-spacing-0 text-sm">
            <thead><tr className="bg-slate-950/80 text-xs uppercase tracking-wider text-slate-500"><th className="px-4 py-3 text-left font-medium">Description</th><th className="px-4 py-3 text-left font-medium">Category</th><th className="px-4 py-3 text-center font-medium">Qty</th><th className="px-4 py-3 text-center font-medium">Qty Type</th><th className="px-4 py-3 text-right font-medium">Unit Price</th><th className="px-4 py-3 text-right font-medium">Amount PKR</th></tr></thead>
            <tbody>{(items as any[]).map((item: any) => <tr key={item.itemId} className="border-t border-white/5 text-slate-200 hover:bg-white/[0.03]"><td className="px-4 py-3">{item.description}</td><td className="px-4 py-3 text-slate-400">{item.category || '-'}</td><td className="px-4 py-3 text-center">{item.quantity}</td><td className="px-4 py-3 text-center text-slate-400">{item.quantityType || '-'}</td><td className="px-4 py-3 text-right">{formatCurrency(item.unitPrice)}</td><td className="px-4 py-3 text-right font-semibold text-slate-100">{formatCurrency(item.amount)}</td></tr>)}</tbody>
            <tfoot><tr className="border-t border-white/10 bg-slate-900/50"><td colSpan={5} className="px-4 py-3 text-right font-semibold text-slate-400">Total</td><td className="px-4 py-3 text-right font-bold text-champagne">{formatCurrency(main.totalAmount)}</td></tr></tfoot>
          </table>
        </div>
      </GlassCard>

      <GlassCard className="p-8">
        <p className="section-heading mb-5">Delivery Details</p>
        <div className="grid gap-3 sm:grid-cols-2">
          {[
            ['Delivery Address', main.deliveryAddress || '-'],
            ['Ordered By', main.preparedBy || '-'],
            ['Delivery Instructions', Array.isArray(main.deliveryInstructions) && main.deliveryInstructions.length ? main.deliveryInstructions.join(', ') : '-'],
            ['Attachments', Array.isArray(main.attachments) && main.attachments.length ? main.attachments.join(', ') : '-'],
          ].map(([label, value]) => <div key={String(label)} className="rounded-2xl border border-white/8 bg-slate-950/60 p-4"><p className="text-xs uppercase tracking-wider text-slate-500">{label}</p><p className="mt-2 text-sm text-slate-100">{value}</p></div>)}
        </div>
      </GlassCard>

      <GlassCard className="p-8">
        <div className="mb-5 flex items-center justify-between gap-4"><p className="section-heading">PDF Preview</p>{main.pdfLink ? <a href={`/api/po/download?${main.pdfLink ? `url=${encodeURIComponent(main.pdfLink)}` : `fileId=${encodeURIComponent(main.driveFileId)}`}`} className="primary-button text-sm">Download PDF</a> : null}</div>
        <div className="overflow-hidden rounded-2xl border border-white/10 bg-white">
          <POPreview
            vendorName={main.vendorName}
            poNumber={main.poNumber}
            poDate={main.poDate}
            deliveryDate={main.deliveryDate}
            projectReference={main.projectReference}
            poBasedOn={main.poBasedOn || items?.[0]?.poType}
            items={(items as any[]).map((item: any) => ({ description: item.description, category: item.category, quantity: item.quantity, quantityType: item.quantityType, poType: item.poType, unitPrice: item.unitPrice, amount: item.amount }))}
            totalAmount={main.totalAmount}
            deliveryAddress={main.deliveryAddress}
            preparedBy={main.preparedBy}
            deliveryInstructions={main.deliveryInstructions}
            attachments={main.attachments}
            companyName={settings.COMPANY_NAME}
            companyAddress={settings.COMPANY_ADDRESS}
          />
        </div>
      </GlassCard>
    </div>
  );
}
