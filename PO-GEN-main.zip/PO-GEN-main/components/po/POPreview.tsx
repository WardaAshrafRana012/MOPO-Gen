﻿'use client';

import { useEffect, useRef, useState } from 'react';
import Image from 'next/image';

interface PreviewItem {
  description: string;
  category?: string;
  quantity: number;
  quantityType?: string;
  poType?: string;
  unitPrice: number;
  amount: number;
}

export interface POPreviewProps {
  vendorName?: string;
  poNumber?: string;
  poDate?: string;
  deliveryDate?: string;
  projectReference?: string;
  poBasedOn?: string;
  items?: PreviewItem[];
  totalAmount?: number;
  deliveryAddress?: string;
  preparedBy?: string;
  deliveryInstructions?: string[];
  attachments?: string[];
  companyName?: string;
  companyAddress?: string;
}

function fmtDate(v?: string): string {
  if (!v) return '-';
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return v;
  return d.toLocaleDateString('en-GB', { month: 'long', day: 'numeric', year: 'numeric' });
}

function fmtNum(n: number): string {
  return new Intl.NumberFormat('en-PK', { minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(n);
}

function toWords(amount: number): string {
  const ones = ['', 'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX', 'SEVEN', 'EIGHT', 'NINE', 'TEN', 'ELEVEN', 'TWELVE', 'THIRTEEN', 'FOURTEEN', 'FIFTEEN', 'SIXTEEN', 'SEVENTEEN', 'EIGHTEEN', 'NINETEEN'];
  const tens = ['', '', 'TWENTY', 'THIRTY', 'FORTY', 'FIFTY', 'SIXTY', 'SEVENTY', 'EIGHTY', 'NINETY'];

  function belowOneThousand(n: number): string {
    if (!n) return '';
    if (n < 20) return ones[n];
    if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 ? '-' + ones[n % 10] : '');
    return ones[Math.floor(n / 100)] + ' HUNDRED' + (n % 100 ? ' ' + belowOneThousand(n % 100) : '');
  }

  const n = Math.round(Number(amount) || 0);
  if (!n) return 'ZERO RUPEES ONLY';

  const parts: string[] = [];
  if (Math.floor(n / 10000000)) parts.push(belowOneThousand(Math.floor(n / 10000000)) + ' CRORE');
  if (Math.floor((n % 10000000) / 100000)) parts.push(belowOneThousand(Math.floor((n % 10000000) / 100000)) + ' LAKH');
  if (Math.floor((n % 100000) / 1000)) parts.push(belowOneThousand(Math.floor((n % 100000) / 1000)) + ' THOUSAND');
  if (n % 1000) parts.push(belowOneThousand(n % 1000));
  return parts.join(' ') + ' RUPEES ONLY';
}

const A4_W = 595;
const A4_H = 842;
const BORDER = '0.5px solid #bbb';

function thStyle(align: 'left' | 'center' | 'right', width: string): React.CSSProperties {
  return { border: BORDER, padding: '6px 6px', textAlign: align, fontWeight: 700, width, fontSize: 8 };
}

const tdStyle: React.CSSProperties = { border: BORDER, padding: '5px 6px', fontSize: 8.5, verticalAlign: 'top' };
const ddCell: React.CSSProperties = { border: BORDER, padding: '9px 11px', verticalAlign: 'top' };

export default function POPreview({
  vendorName = '',
  poNumber = 'PO-0001',
  poDate = '',
  deliveryDate,
  projectReference = '',
  poBasedOn = '',
  items = [],
  totalAmount = 0,
  deliveryAddress = '',
  preparedBy = '',
  deliveryInstructions = [],
  attachments = [],
  companyAddress = '47-B, Main Kh-e-Shamsheer, DHA-5, Karachi',
}: POPreviewProps) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    if (!wrapRef.current) return;
    const obs = new ResizeObserver((entries) => {
      const w = entries[0]?.contentRect.width;
      if (w) setScale(w / A4_W);
    });
    obs.observe(wrapRef.current);
    setScale(wrapRef.current.clientWidth / A4_W);
    return () => obs.disconnect();
  }, []);

  const words = toWords(totalAmount);
  const infoRows = [
    ['PO DATE', fmtDate(poDate)],
    ['PROJECT REFERENCE', projectReference || '-'],
    ...(poBasedOn ? [['PO BASED ON', poBasedOn]] : []),
    ...(deliveryDate ? [['DELIVERY DATE', fmtDate(deliveryDate)]] : []),
  ];

  return (
    <div ref={wrapRef} className="relative w-full overflow-hidden bg-white" style={{ height: A4_H * scale }}>
      <div
        style={{
          width: A4_W,
          height: A4_H,
          transform: `scale(${scale})`,
          transformOrigin: 'top left',
          position: 'absolute',
          top: 0,
          left: 0,
          backgroundColor: '#fff',
          fontFamily: 'Helvetica, Arial, sans-serif',
          color: '#1a1a1a',
          boxSizing: 'border-box',
          padding: '38px 42px',
          fontSize: 9,
          lineHeight: 1.4,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 24 }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
            <Image src="/molecule-logo.png" alt="MOPO" width={62} height={62} style={{ width: 62, height: 62, flexShrink: 0, objectFit: 'contain' }} priority />
            <div style={{ lineHeight: 1.25, marginTop: 2 }}>
              <div style={{ fontSize: 15.5, fontWeight: 700 }}>Molecule</div>
              <div style={{ fontSize: 8, color: '#555', marginTop: 3 }}>{companyAddress}</div>
            </div>
          </div>

          <div style={{ textAlign: 'right', fontSize: 8.5, lineHeight: 1.7 }}>
            <div style={{ fontWeight: 700 }}>VENDOR NAME: {vendorName ? vendorName.toUpperCase() : '-'}</div>
            <div style={{ fontWeight: 700 }}>PO NUMBER: {poNumber}</div>
            {infoRows.map(([label, value]) => (
              <div key={label}>{label}: {value}</div>
            ))}
          </div>
        </div>

        <div style={{ fontSize: 24, fontWeight: 400, marginTop: 18, marginBottom: 16 }}>VENDOR PURCHASE ORDER</div>

        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: '#f0f0f0' }}>
              <th style={thStyle('left', '42%')}>Brief Detail of Major Type Of Item / Service</th>
              <th style={thStyle('center', '9%')}>Qty</th>
              <th style={thStyle('center', '11%')}>Qty Type</th>
              <th style={thStyle('center', '16%')}>Unit Price</th>
              <th style={{ ...thStyle('center', '14%'), paddingBottom: 3 }}>Amount<br />PKR</th>
            </tr>
          </thead>
          <tbody>
            {items.length === 0 ? (
              <tr>
                <td colSpan={5} style={{ ...tdStyle, color: '#aaa', fontStyle: 'italic' }}>No items added yet.</td>
              </tr>
            ) : (
              items.map((item, i) => (
                <tr key={i}>
                  <td style={tdStyle}>
                    <div>{item.description || '-'}</div>
                    {item.category ? <div style={{ color: '#666', fontSize: 7.5, marginTop: 2 }}>Category: {item.category}</div> : null}
                  </td>
                  <td style={{ ...tdStyle, textAlign: 'center', verticalAlign: 'middle' }}>{fmtNum(item.quantity)}</td>
                  <td style={{ ...tdStyle, textAlign: 'center', verticalAlign: 'middle' }}>{item.quantityType || ''}</td>
                  <td style={{ ...tdStyle, textAlign: 'right', verticalAlign: 'middle' }}>{fmtNum(item.unitPrice)}</td>
                  <td style={{ ...tdStyle, textAlign: 'right', verticalAlign: 'middle' }}>{fmtNum(item.amount)}</td>
                </tr>
              ))
            )}
            <tr style={{ background: '#f0f0f0' }}>
              <td colSpan={3} style={{ ...tdStyle, fontWeight: 700 }}>{words}</td>
              <td style={{ ...tdStyle, textAlign: 'center', fontWeight: 700 }}>TOTAL</td>
              <td style={{ ...tdStyle, textAlign: 'right', fontWeight: 700 }}>{fmtNum(totalAmount)}</td>
            </tr>
          </tbody>
        </table>

        {attachments.length > 0 ? (
          <div style={{ marginTop: 18 }}>
            <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 8 }}>IMAGE ATTACHMENT</div>
            <div style={{ border: BORDER, padding: '9px 11px', fontSize: 8.5 }}>{attachments.join(', ')}</div>
          </div>
        ) : null}

        <div style={{ marginTop: 20 }}>
          <div style={{ fontSize: 11, fontWeight: 400, marginBottom: 8, letterSpacing: 0.2 }}>DELIVERY DETAILS</div>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <tbody>
              <tr>
                <td style={{ ...ddCell, width: '54%' }}>
                  <div style={{ fontWeight: 700 }}>DELIVERY ADDRESS : {deliveryAddress || '-'}</div>
                  <div style={{ marginTop: 7, fontWeight: 700 }}>ORDERED BY : {preparedBy || '-'}</div>
                </td>
                <td style={ddCell}>
                  {deliveryInstructions.length > 0 ? (
                    <div>
                      <div style={{ fontWeight: 700 }}>DELIVERY INSTRUCTIONS</div>
                      <div style={{ marginTop: 4, lineHeight: 1.5 }}>{deliveryInstructions.join(', ')}</div>
                    </div>
                  ) : (
                    <div style={{ minHeight: 18 }} />
                  )}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
