'use client';

import { usePathname } from 'next/navigation';
import Link from 'next/link';
import Topbar from './Topbar';
import Sidebar from './Sidebar';
import { FileText, Sparkle, LayoutTemplate } from 'lucide-react';

const mobileMenu = [
  { href: '/create-po',  label: 'Create',   icon: Sparkle        },
  { href: '/po-records', label: 'Records',  icon: FileText       },
  { href: '/templates',  label: 'Templates',icon: LayoutTemplate },
];

export default function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const hideNav  = pathname?.startsWith('/login') || pathname?.startsWith('/oauth');

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      {!hideNav && <Topbar />}

      <div className="mx-auto flex max-w-[1600px] gap-6 px-4 pb-24 pt-6 lg:px-8 xl:pb-6">
        {!hideNav && <Sidebar />}
        <main className="min-w-0 flex-1">{children}</main>
      </div>

      {/* Mobile bottom nav */}
      {!hideNav && (
        <nav className="fixed bottom-0 inset-x-0 z-40 border-t border-white/8 bg-slate-950/95 backdrop-blur-xl xl:hidden">
          <div className="flex items-stretch">
            {mobileMenu.map(({ href, label, icon: Icon }) => {
              const active = pathname === href || (href !== '/' && pathname.startsWith(href));
              return (
                <Link
                  key={href}
                  href={href}
                  className={`flex flex-1 flex-col items-center justify-center gap-1 py-3 text-[10px] font-medium transition ${
                    active ? 'text-champagne' : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  <Icon className={`h-5 w-5 ${active ? 'text-champagne' : ''}`} />
                  {label}
                </Link>
              );
            })}
          </div>
        </nav>
      )}
    </div>
  );
}
