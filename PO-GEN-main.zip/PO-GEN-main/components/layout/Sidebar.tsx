'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { FileText, Sparkle, LayoutTemplate } from 'lucide-react';

const menu = [
  { href: '/create-po',  label: 'Create PO',    icon: Sparkle        },
  { href: '/po-records', label: 'PO Records',   icon: FileText       },
  { href: '/templates',  label: 'Templates',    icon: LayoutTemplate },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden w-60 flex-shrink-0 xl:flex flex-col">
      <div className="card-glass flex h-full flex-col gap-5 p-5">

        {/* Brand */}
        <div className="flex items-center gap-3 rounded-2xl bg-white/5 px-4 py-3">
          <span className="inline-flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-300/25 to-white/5 text-base font-bold text-amber-100">
            M
          </span>
          <div className="min-w-0">
            <p className="text-[10px] uppercase tracking-[0.3em] text-slate-500">Molecule</p>
            <p className="truncate text-sm font-semibold text-slate-100">Purchase Orders</p>
          </div>
        </div>

        {/* Nav */}
        <nav className="space-y-0.5">
          {menu.map(({ href, label, icon: Icon }) => {
            const active = pathname === href || (href !== '/' && pathname.startsWith(href));
            return (
              <Link
                key={href}
                href={href}
                className={`flex items-center gap-3 rounded-2xl px-4 py-2.5 text-sm font-medium transition-all ${
                  active
                    ? 'bg-champagne/15 text-champagne'
                    : 'text-slate-300 hover:bg-white/5 hover:text-slate-100'
                }`}
              >
                <Icon className={`h-4 w-4 flex-shrink-0 ${active ? 'text-champagne' : 'text-slate-400'}`} />
                {label}
                {active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-champagne" />}
              </Link>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="mt-auto rounded-2xl border border-white/8 bg-white/4 p-4 text-xs text-slate-500 leading-5">
          <p className="font-semibold text-slate-400">Google Sheets + Drive</p>
          <p className="mt-1">All PO data and PDFs are saved automatically.</p>
        </div>
      </div>
    </aside>
  );
}
