'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Search, RefreshCw, ChevronDown, UserCircle2, CheckCircle, XCircle } from 'lucide-react';
import Link from 'next/link';

export default function Topbar() {
  const router = useRouter();
  const [syncing,   setSyncing]   = useState(false);
  const [syncMsg,   setSyncMsg]   = useState<{ ok: boolean; text: string } | null>(null);
  const [searchVal, setSearchVal] = useState('');

  async function syncSheet() {
    setSyncing(true);
    setSyncMsg(null);
    try {
      const res  = await fetch('/api/sync', { method: 'POST' });
      const data = await res.json();
      if (res.ok && data?.data?.missingTabs?.length === 0) {
        setSyncMsg({ ok: true, text: `Synced â€” ${data.data.poCount ?? 0} PO(s) in sheet` });
      } else if (data?.data?.missingTabs?.length) {
        setSyncMsg({ ok: false, text: `Missing tabs: ${data.data.missingTabs.join(', ')}` });
      } else {
        setSyncMsg({ ok: false, text: data?.error || 'Sync failed' });
      }
    } catch {
      setSyncMsg({ ok: false, text: 'Network error' });
    } finally {
      setSyncing(false);
      setTimeout(() => setSyncMsg(null), 5000);
    }
  }

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    const q = searchVal.trim();
    router.push(q ? `/po-records?search=${encodeURIComponent(q)}` : '/po-records');
  }

  return (
    <header className="sticky top-0 z-30 border-b border-white/8 bg-slate-950/95 backdrop-blur-xl">
      <div className="mx-auto flex max-w-[1600px] items-center gap-3 px-4 py-3 lg:px-8">

        {/* Search */}
        <form onSubmit={handleSearch} className="flex flex-1 max-w-sm items-center gap-2 rounded-full border border-white/10 bg-slate-900/70 px-4 py-2">
          <Search className="h-4 w-4 flex-shrink-0 text-slate-500" />
          <input
            type="search"
            value={searchVal}
            onChange={(e) => setSearchVal(e.target.value)}
            placeholder="Search PO or vendorâ€¦"
            className="w-full bg-transparent text-sm text-slate-100 outline-none placeholder:text-slate-500"
          />
        </form>

        {/* Sync feedback */}
        {syncMsg && (
          <span className={`hidden sm:inline-flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium ${syncMsg.ok ? 'bg-emerald-500/15 text-emerald-300' : 'bg-rose-500/15 text-rose-300'}`}>
            {syncMsg.ok ? <CheckCircle className="h-3.5 w-3.5" /> : <XCircle className="h-3.5 w-3.5" />}
            {syncMsg.text}
          </span>
        )}

        <div className="flex items-center gap-2 ml-auto">
          <button
            type="button"
            onClick={syncSheet}
            disabled={syncing}
            className="secondary-button inline-flex items-center gap-2 text-sm"
            title="Sync Google Sheet â€” verify all PO data is saved"
          >
            <RefreshCw className={`h-4 w-4 ${syncing ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">{syncing ? 'Syncingâ€¦' : 'Sync Sheet'}</span>
          </button>
        </div>
      </div>
    </header>
  );
}
