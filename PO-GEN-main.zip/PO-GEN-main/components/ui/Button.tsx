'use client';

type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'primary' | 'secondary' | 'ghost';
};

export default function Button({ className = '', variant = 'primary', ...props }: ButtonProps) {
  const base =
    variant === 'primary'
      ? 'primary-button '
      : variant === 'secondary'
      ? 'secondary-button '
      : 'inline-flex items-center justify-center rounded-full px-4 py-2 text-sm font-medium text-slate-100 transition hover:bg-white/10 ';

  return <button className={`${base}${className}`} {...props} />;
}
