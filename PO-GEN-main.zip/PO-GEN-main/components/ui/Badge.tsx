type BadgeProps = { label: string; tone?: 'gold' | 'success' | 'muted'; };

export default function Badge({ label, tone = 'gold' }: BadgeProps) {
  const classes = tone === 'gold' ? 'badge-gold' : tone === 'success' ? 'badge-success' : 'badge-muted';
  return <span className={classes}>{label}</span>;
}
