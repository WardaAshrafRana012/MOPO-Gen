﻿export interface PurchaseOrderItem {
  itemId:        string;
  poId:          string;
  poNumber:      string;
  description:   string;
  category?:     string;
  quantityType?: string;
  poType?:       string;
  quantity:      number;
  unitPrice:     number;
  amount:        number;
  createdAt:     string;
  updatedAt:     string;
}

export interface PurchaseOrderMain {
  poId:                  string;
  poNumber:              string;
  vendorName:            string;
  poDate:                string;
  deliveryDate?:         string;
  projectReference:      string;
  poBasedOn?:            string;
  deliveryAddress:       string;
  preparedBy:            string;
  deliveryInstructions?: string[];
  attachments?:          string[];
  itemCategory?:         string;
  itemsCount:            number;
  totalAmount:           number;
  amountInWords:         string;
  pdfLink?:              string;
  driveFileId?:          string;
  status:                string;
  createdAt:             string;
  updatedAt:             string;
  archived:              boolean;
}

export interface PurchaseOrderPayload {
  vendorName:             string;
  poDate:                 string;
  deliveryDate?:          string;
  projectReference:       string;
  poBasedOn?:             string;
  deliveryAddress:        string;
  preparedBy:             string;
  deliveryInstructions?:  string[];
  attachments?:           string[];
  itemCategory?:          string;
  items: Array<{
    description:   string;
    quantity:      number;
    unitPrice:     number;
    category?:     string;
    quantityType?: string;
    poType?:       string;
  }>;
  saveDraft?: boolean;
}
