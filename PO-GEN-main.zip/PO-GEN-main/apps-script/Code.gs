const DRIVE_FOLDER_ID = PropertiesService.getScriptProperties().getProperty('GOOGLE_DRIVE_FOLDER_ID');

function doPost(e) {
  try {
    const payload = JSON.parse(e.postData.contents || '{}');
    const action = String(payload.action || 'uploadPdf');

    if (action === 'createPurchaseOrder') return createPurchaseOrder(payload);
    if (action === 'updatePurchaseOrder') return updatePurchaseOrder(payload);
    if (action === 'regeneratePurchaseOrderPdf') return regeneratePurchaseOrderPdf(payload);
    return uploadPdf(payload);
  } catch (error) {
    return jsonResponse({
      ok: false,
      error: error && error.message ? error.message : String(error),
    });
  }
}

function uploadPdf(payload) {
  const fileName = String(payload.fileName || `po-${Date.now()}.pdf`);
  const pdfBase64 = String(payload.pdfBase64 || '');

  if (!DRIVE_FOLDER_ID) {
    throw new Error('GOOGLE_DRIVE_FOLDER_ID script property is missing.');
  }

  if (!pdfBase64) {
    throw new Error('pdfBase64 is required.');
  }

  const folder = DriveApp.getFolderById(DRIVE_FOLDER_ID);
  const blob = Utilities.newBlob(
    Utilities.base64Decode(pdfBase64),
    'application/pdf',
    fileName
  );

  let file;
  if (payload.action === 'update' && payload.fileId) {
    file = DriveApp.getFileById(String(payload.fileId));
    file.setTrashed(true);
    file = folder.createFile(blob);
  } else {
    file = folder.createFile(blob);
  }

  return {
    id: file.getId(),
    webViewLink: file.getUrl(),
    name: file.getName(),
  };
}

function createPurchaseOrder(payload) {
  const spreadsheet = openSpreadsheet(payload.spreadsheetId);
  const uploaded = uploadPdf({
    action: 'upload',
    fileName: payload.fileName,
    pdfBase64: payload.pdfBase64,
  });

  const mainRow = payload.mainRow || {};
  mainRow.PDF_Link = driveViewLink(uploaded.id);
  mainRow.Drive_File_ID = uploaded.id;
  mainRow.Status = mainRow.Status || 'Generated';
  mainRow.Updated_At = new Date().toISOString();

  appendRowByHeaders(spreadsheet, payload.mainSheetName, mainRow);
  appendRowsByHeaders(spreadsheet, payload.itemsSheetName, payload.itemRows || []);
  appendActivityRow(spreadsheet, payload.activitySheetName, payload.logData || null);

  return jsonResponse({
    ok: true,
    id: uploaded.id,
    webViewLink: uploaded.webViewLink,
    pdfLink: driveViewLink(uploaded.id),
  });
}

function updatePurchaseOrder(payload) {
  const spreadsheet = openSpreadsheet(payload.spreadsheetId);
  const mainSheet = spreadsheet.getSheetByName(payload.mainSheetName);
  const itemsSheet = spreadsheet.getSheetByName(payload.itemsSheetName);
  if (!mainSheet || !itemsSheet) {
    throw new Error('Required PO sheets were not found.');
  }

  const poId = String(payload.poId || '');
  const existingFileId = String(payload.existingDriveFileId || '');
  const uploaded = uploadPdf({
    action: existingFileId ? 'update' : 'upload',
    fileId: existingFileId,
    fileName: payload.fileName,
    pdfBase64: payload.pdfBase64,
  });

  const mainRow = payload.mainRow || {};
  mainRow.PDF_Link = driveViewLink(uploaded.id);
  mainRow.Drive_File_ID = uploaded.id;
  mainRow.Status = mainRow.Status || 'Updated';
  mainRow.Updated_At = new Date().toISOString();
  updateRowByLookup(mainSheet, 'PO_ID', poId, mainRow);

  const oldItems = findRowIndexes(itemsSheet, 'PO_ID', poId);
  for (var i = 0; i < oldItems.length; i += 1) {
    updateRowByLookup(itemsSheet, 'Item_ID', getCellValue(itemsSheet, oldItems[i], 'Item_ID'), { Archived: 'TRUE' });
  }

  appendRowsByHeaders(spreadsheet, payload.itemsSheetName, payload.itemRows || []);
  appendActivityRow(spreadsheet, payload.activitySheetName, payload.logData || null);

  return jsonResponse({
    ok: true,
    id: uploaded.id,
    webViewLink: uploaded.webViewLink,
    pdfLink: driveViewLink(uploaded.id),
  });
}

function regeneratePurchaseOrderPdf(payload) {
  const spreadsheet = openSpreadsheet(payload.spreadsheetId);
  const mainSheet = spreadsheet.getSheetByName(payload.mainSheetName);
  if (!mainSheet) {
    throw new Error('Main PO sheet was not found.');
  }

  const poId = String(payload.poId || '');
  const existingFileId = String(payload.existingDriveFileId || '');
  const uploaded = uploadPdf({
    action: existingFileId ? 'update' : 'upload',
    fileId: existingFileId,
    fileName: payload.fileName,
    pdfBase64: payload.pdfBase64,
  });

  updateRowByLookup(mainSheet, 'PO_ID', poId, {
    PDF_Link: driveViewLink(uploaded.id),
    Drive_File_ID: uploaded.id,
    Status: 'PDF Regenerated',
    Updated_At: new Date().toISOString(),
  });

  appendActivityRow(spreadsheet, payload.activitySheetName, payload.logData || null);

  return jsonResponse({
    ok: true,
    id: uploaded.id,
    webViewLink: uploaded.webViewLink,
    pdfLink: driveViewLink(uploaded.id),
  });
}

function openSpreadsheet(spreadsheetId) {
  if (!spreadsheetId) {
    throw new Error('spreadsheetId is required.');
  }
  return SpreadsheetApp.openById(String(spreadsheetId));
}

function appendActivityRow(spreadsheet, activitySheetName, rowData) {
  if (!rowData || !activitySheetName) return;
  const sheet = spreadsheet.getSheetByName(activitySheetName);
  if (!sheet) return;
  appendRowToSheet(sheet, rowData);
}

function appendRowsByHeaders(spreadsheet, sheetName, rows) {
  if (!rows || !rows.length) return;
  const sheet = spreadsheet.getSheetByName(sheetName);
  if (!sheet) {
    throw new Error(`Sheet not found: ${sheetName}`);
  }
  for (var i = 0; i < rows.length; i += 1) {
    appendRowToSheet(sheet, rows[i]);
  }
}

function appendRowByHeaders(spreadsheet, sheetName, row) {
  const sheet = spreadsheet.getSheetByName(sheetName);
  if (!sheet) {
    throw new Error(`Sheet not found: ${sheetName}`);
  }
  appendRowToSheet(sheet, row);
}

function appendRowToSheet(sheet, rowData) {
  const headers = getHeaders(sheet);
  const values = headers.map(function(header) {
    return normalizeValue(rowData[header]);
  });
  sheet.appendRow(values);
}

function updateRowByLookup(sheet, lookupColumn, lookupValue, rowData) {
  const headers = getHeaders(sheet);
  const rowIndex = findRowIndex(sheet, lookupColumn, lookupValue);
  if (rowIndex < 2) {
    throw new Error(`Row with ${lookupColumn}=${lookupValue} not found in ${sheet.getName()}`);
  }

  const existingValues = sheet.getRange(rowIndex, 1, 1, headers.length).getValues()[0];
  const nextValues = headers.map(function(header, index) {
    if (Object.prototype.hasOwnProperty.call(rowData, header)) {
      return normalizeValue(rowData[header]);
    }
    return existingValues[index];
  });
  sheet.getRange(rowIndex, 1, 1, headers.length).setValues([nextValues]);
}

function findRowIndexes(sheet, lookupColumn, lookupValue) {
  const headers = getHeaders(sheet);
  const columnIndex = headers.indexOf(lookupColumn);
  if (columnIndex < 0) {
    throw new Error(`Column not found: ${lookupColumn}`);
  }

  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];
  const values = sheet.getRange(2, columnIndex + 1, lastRow - 1, 1).getValues();
  const rowIndexes = [];
  for (var i = 0; i < values.length; i += 1) {
    if (String(values[i][0]) === String(lookupValue)) {
      rowIndexes.push(i + 2);
    }
  }
  return rowIndexes;
}

function findRowIndex(sheet, lookupColumn, lookupValue) {
  const matches = findRowIndexes(sheet, lookupColumn, lookupValue);
  return matches.length ? matches[0] : -1;
}

function getCellValue(sheet, rowIndex, columnName) {
  const headers = getHeaders(sheet);
  const columnIndex = headers.indexOf(columnName);
  if (columnIndex < 0) return '';
  return String(sheet.getRange(rowIndex, columnIndex + 1).getValue() || '');
}

function getHeaders(sheet) {
  const lastColumn = Math.max(sheet.getLastColumn(), 1);
  return sheet.getRange(1, 1, 1, lastColumn).getValues()[0].map(function(value) {
    return String(value || '').trim();
  });
}

function normalizeValue(value) {
  return value == null ? '' : value;
}

function driveViewLink(fileId) {
  return `https://drive.google.com/file/d/${fileId}/view`;
}

function jsonResponse(body) {
  return ContentService
    .createTextOutput(JSON.stringify(body))
    .setMimeType(ContentService.MimeType.JSON);
}
