import fs from 'fs';
import path from 'path';

const root = 'D:/mopo gen';

function replaceInFile(relativePath, edits) {
  const fullPath = path.join(root, relativePath);
  let source = fs.readFileSync(fullPath, 'utf8').replace(/\r\n/g, '\n');

  for (const [before, after] of edits) {
    if (!source.includes(before)) {
      throw new Error(`Pattern not found in ${relativePath}:\n${before}`);
    }
    source = source.replace(before, after);
  }

  fs.writeFileSync(fullPath, source, 'utf8');
}

replaceInFile('components/po/POWizard.tsx', [
  [
    "import POPreview from '@/components/po/POPreview';",
    "import POPreview from '@/components/po/POPreview';\nimport { apiFetchJson } from '@/lib/client/api';",
  ],
  [
    [
      "  useEffect(() => {",
      "    fetch('/api/settings').then((r) => r.json()).then((d) => {",
      "      setPoPrefix(d?.data?.PO_PREFIX || 'PO');",
      "      setSettings(d?.data || {});",
      "    });",
      "    fetch('/api/po').then((r) => r.json()).then((d) => {",
      "      setExistingNos((d?.data ?? []).map((p: any) => p.poNumber));",
      "    });",
      "  }, []);",
    ].join('\n'),
    [
      "  useEffect(() => {",
      "    void (async () => {",
      "      const settingsResponse = await apiFetchJson<{ data?: Record<string, string> }>('/api/settings');",
      "      setPoPrefix(settingsResponse?.data?.PO_PREFIX || 'PO');",
      "      setSettings(settingsResponse?.data || {});",
      "",
      "      const ordersResponse = await apiFetchJson<{ data?: Array<{ poNumber?: string }> }>('/api/po');",
      "      setExistingNos((ordersResponse?.data ?? []).map((p) => p.poNumber || ''));",
      "    })().catch((error) => {",
      "      setMsg({ text: String(error instanceof Error ? error.message : error), ok: false });",
      "    });",
      "  }, []);",
    ].join('\n'),
  ],
  [
    [
      "      const res    = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });",
      "      const data   = await res.json();",
      "      if (!res.ok) throw new Error(data?.error || 'Unable to save PO');",
    ].join('\n'),
    [
      "      const data   = await apiFetchJson<{ data?: { poNumber?: string; pdfLink?: string; driveFileId?: string } }>(url, {",
      "        method,",
      "        headers: { 'Content-Type': 'application/json' },",
      "        body: JSON.stringify(payload),",
      "      });",
    ].join('\n'),
  ],
]);

replaceInFile('components/layout/Topbar.tsx', [
  [
    "import Link from 'next/link';",
    "import Link from 'next/link';\nimport { apiFetchJson } from '@/lib/client/api';",
  ],
  [
    [
      "      const res  = await fetch('/api/sync', { method: 'POST' });",
      "      const data = await res.json();",
      "      if (res.ok && data?.data?.missingTabs?.length === 0) {",
    ].join('\n'),
    [
      "      const data = await apiFetchJson<{ data?: { missingTabs?: string[]; poCount?: number } }>('/api/sync', { method: 'POST' });",
      "      if (data?.data?.missingTabs?.length === 0) {",
    ].join('\n'),
  ],
  [
    [
      "      } else {",
      "        setSyncMsg({ ok: false, text: data?.error || 'Sync failed' });",
      "      }",
      "    } catch {",
      "      setSyncMsg({ ok: false, text: 'Network error' });",
    ].join('\n'),
    [
      "      } else {",
      "        setSyncMsg({ ok: false, text: 'Sync failed' });",
      "      }",
      "    } catch (error) {",
      "      setSyncMsg({ ok: false, text: String(error instanceof Error ? error.message : error) });",
    ].join('\n'),
  ],
]);

replaceInFile('app/settings/page.tsx', [
  [
    "import { CheckCircle, XCircle, RefreshCw } from 'lucide-react';",
    "import { CheckCircle, XCircle, RefreshCw } from 'lucide-react';\nimport { apiFetchJson } from '@/lib/client/api';",
  ],
  [
    [
      "  useEffect(() => {",
      "    fetch('/api/settings').then((r) => r.json()).then((d) => {",
      "      setSettings(d?.data || {});",
      "    });",
      "  }, []);",
    ].join('\n'),
    [
      "  useEffect(() => {",
      "    void apiFetchJson<{ data?: Record<string, string> }>('/api/settings')",
      "      .then((d) => {",
      "        setSettings(d?.data || {});",
      "      })",
      "      .catch((error) => {",
      "        setSaveMsg({ ok: false, text: String(error instanceof Error ? error.message : error) });",
      "      });",
      "  }, []);",
    ].join('\n'),
  ],
  [
    [
      "      const res  = await fetch('/api/settings', {",
      "        method:  'PUT',",
      "        headers: { 'Content-Type': 'application/json' },",
      "        body:    JSON.stringify(settings),",
      "      });",
      "      const data = await res.json();",
      "      setSaveMsg(res.ok ? { ok: true, text: 'Settings saved.' } : { ok: false, text: data?.error || 'Save failed.' });",
    ].join('\n'),
    [
      "      await apiFetchJson<{ data?: Record<string, string> }>('/api/settings', {",
      "        method:  'PUT',",
      "        headers: { 'Content-Type': 'application/json' },",
      "        body:    JSON.stringify(settings),",
      "      });",
      "      setSaveMsg({ ok: true, text: 'Settings saved.' });",
    ].join('\n'),
  ],
  [
    [
      "      const res  = await fetch('/api/sync/test', { method: 'POST' });",
      "      const data = await res.json();",
      "      if (res.ok) {",
    ].join('\n'),
    [
      "      const data = await apiFetchJson<{ data: { sheets: boolean; driveFolder: boolean; driveFolderName?: string; missingTabs?: string[] } }>('/api/sync/test', { method: 'POST' });",
      "      if (data?.data) {",
    ].join('\n'),
  ],
  [
    [
      "      } else {",
      "        setTestMsg({ ok: false, text: data?.error || 'Test failed.' });",
      "      }",
      "    } catch (e: any) {",
    ].join('\n'),
    [
      "      } else {",
      "        setTestMsg({ ok: false, text: 'Test failed.' });",
      "      }",
      "    } catch (e: any) {",
    ].join('\n'),
  ],
  [
    [
      "    const res  = await fetch('/api/drive/test-upload', { method: 'POST' });",
      "    const data = await res.json();",
      "    setTestMsg(res.ok",
      "      ? { ok: true,  text: `Drive upload OK · ${data.data.pdfLink}` }",
      "      : { ok: false, text: data?.error || 'Drive upload failed.' });",
    ].join('\n'),
    [
      "    try {",
      "      const data = await apiFetchJson<{ data: { pdfLink: string } }>('/api/drive/test-upload', { method: 'POST' });",
      "      setTestMsg({ ok: true, text: `Drive upload OK · ${data.data.pdfLink}` });",
      "    } catch (error) {",
      "      setTestMsg({ ok: false, text: String(error instanceof Error ? error.message : error) });",
      "    }",
    ].join('\n'),
  ],
  [
    [
      "    const res  = await fetch('/api/sync', { method: 'POST' });",
      "    const data = await res.json();",
      "    setTestMsg(res.ok",
      "      ? { ok: true,  text: data.data.missingTabs?.length ? `Missing tabs: ${data.data.missingTabs.join(', ')}` : '✓ Sheet verified.' }",
      "      : { ok: false, text: data?.error || 'Sync failed.' });",
    ].join('\n'),
    [
      "    try {",
      "      const data = await apiFetchJson<{ data: { missingTabs?: string[] } }>('/api/sync', { method: 'POST' });",
      "      setTestMsg({ ok: true, text: data.data.missingTabs?.length ? `Missing tabs: ${data.data.missingTabs.join(', ')}` : '✓ Sheet verified.' });",
      "    } catch (error) {",
      "      setTestMsg({ ok: false, text: String(error instanceof Error ? error.message : error) });",
      "    }",
    ].join('\n'),
  ],
]);
