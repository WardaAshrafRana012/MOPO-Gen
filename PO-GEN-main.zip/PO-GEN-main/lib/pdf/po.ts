﻿import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import type { RGB } from 'pdf-lib';
import type { PurchaseOrderItem, PurchaseOrderMain } from '@/types/po';

const C_BLACK = rgb(0.04, 0.04, 0.04);
const C_DARK = rgb(0.1, 0.1, 0.1);
const C_MID = rgb(0.28, 0.28, 0.28);
const C_LGREY = rgb(0.75, 0.75, 0.75);
const C_BGCELL = rgb(0.95, 0.95, 0.95);
const C_WHITE = rgb(1, 1, 1);

type Page = ReturnType<PDFDocument['addPage']>;
type Font = Awaited<ReturnType<PDFDocument['embedFont']>>;

function drawRight(page: Page, text: string, rx: number, y: number, size: number, font: Font, color: RGB) {
  page.drawText(text, { x: rx - font.widthOfTextAtSize(text, size), y, size, font, color });
}

function box(page: Page, x: number, y: number, w: number, h: number, fill?: RGB, border?: RGB, bw = 0.5) {
  page.drawRectangle({ x, y, width: w, height: h, color: fill, borderColor: border, borderWidth: border ? bw : undefined });
}

function vline(page: Page, x: number, y1: number, y2: number, color: RGB = C_LGREY, t = 0.5) {
  page.drawLine({ start: { x, y: y1 }, end: { x, y: y2 }, thickness: t, color });
}

function numFmt(n: number): string {
  return new Intl.NumberFormat('en-PK', { minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(n);
}

function dateFmt(v?: string): string {
  if (!v) return '-';
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return v;
  return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }).toUpperCase();
}

function wrap(text: string, maxW: number, font: Font, size: number): string[] {
  if (!text.trim()) return [''];
  const words = text.split(' ');
  const lines: string[] = [];
  let cur = '';
  for (const word of words) {
    const candidate = cur ? `${cur} ${word}` : word;
    if (font.widthOfTextAtSize(candidate, size) <= maxW) cur = candidate;
    else {
      if (cur) lines.push(cur);
      cur = word;
    }
  }
  if (cur) lines.push(cur);
  return lines.length ? lines : [''];
}

function drawWrapped(page: Page, text: string, x: number, y: number, maxW: number, font: Font, size: number, color: RGB, lh?: number): number {
  const step = lh ?? size * 1.45;
  for (const line of wrap(text, maxW, font, size)) {
    page.drawText(line, { x, y, size, font, color });
    y -= step;
  }
  return y;
}

function toWords(amount: number): string {
  const ones = ['', 'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX', 'SEVEN', 'EIGHT', 'NINE', 'TEN', 'ELEVEN', 'TWELVE', 'THIRTEEN', 'FOURTEEN', 'FIFTEEN', 'SIXTEEN', 'SEVENTEEN', 'EIGHTEEN', 'NINETEEN'];
  const tens = ['', '', 'TWENTY', 'THIRTY', 'FORTY', 'FIFTY', 'SIXTY', 'SEVENTY', 'EIGHTY', 'NINETY'];
  function belowOneThousand(n: number): string {
    if (!n) return '';
    if (n < 20) return ones[n];
    if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 ? '-' + ones[n % 10] : '');
    return ones[Math.floor(n / 100)] + ' HUNDRED' + (n % 100 ? ' ' + belowOneThousand(n % 100) : '');
  }
  const n = Math.round(Number(amount) || 0);
  if (!n) return 'ZERO RUPEES ONLY';
  const parts: string[] = [];
  if (Math.floor(n / 10000000)) parts.push(belowOneThousand(Math.floor(n / 10000000)) + ' CRORE');
  if (Math.floor((n % 10000000) / 100000)) parts.push(belowOneThousand(Math.floor((n % 10000000) / 100000)) + ' LAKH');
  if (Math.floor((n % 100000) / 1000)) parts.push(belowOneThousand(Math.floor((n % 100000) / 1000)) + ' THOUSAND');
  if (n % 1000) parts.push(belowOneThousand(n % 1000));
  return parts.join(' ') + ' RUPEES ONLY';
}

function drawMoleculeLogo(page: Page, x: number, y: number, width: number, height: number) {
  const sx = width / 120;
  const sy = height / 120;
  const stroke = 6 * Math.min(sx, sy);
  const line = (x1: number, y1: number, x2: number, y2: number) => {
    page.drawLine({ start: { x: x + x1 * sx, y: y + y1 * sy }, end: { x: x + x2 * sx, y: y + y2 * sy }, thickness: stroke, color: C_DARK });
  };
  [[60,110,78,96],[78,96,78,64],[78,64,60,50],[60,50,42,64],[42,64,42,96],[42,96,60,110],[42,96,24,92],[24,92,24,64],[24,64,36,54],[78,96,96,92],[96,92,96,64],[96,64,84,54],[42,64,24,52],[24,52,24,28],[24,28,46,24],[46,24,60,10],[60,10,74,24],[74,24,96,28],[96,28,96,52],[78,64,96,52],[42,64,60,80],[60,80,78,64],[42,64,60,48],[60,48,78,64],[42,32,60,48],[60,48,78,32],[42,32,42,96],[78,32,78,96],[42,32,60,16],[60,16,78,32]].forEach(([x1,y1,x2,y2])=>line(x1,y1,x2,y2));
}

export async function generatePOPDF(po: PurchaseOrderMain, items: PurchaseOrderItem[], settings: Record<string, string>): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([595.28, 841.89]);
  const regular = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const bold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

  const PW = page.getWidth();
  const PH = page.getHeight();
  const ML = 42;
  const MR = 42;
  const MT = 38;
  const UW = PW - ML - MR;

  box(page, 0, 0, PW, PH, C_WHITE);

  drawMoleculeLogo(page, ML, PH - MT - 56, 62, 62);
  page.drawText('Molecule Work Place Solution', { x: ML + 76, y: PH - MT - 10, size: 15, font: bold, color: C_BLACK });
  page.drawText(settings.COMPANY_ADDRESS || '47-B, Main Kh-e-Shamsheer, DHA-5, Karachi', { x: ML + 76, y: PH - MT - 24, size: 8, font: regular, color: C_MID });

  const infoTopY = PH - MT - 8;
  const infoRows: Array<[string, boolean]> = [
    [`VENDOR NAME: ${(po.vendorName || '').toUpperCase()}`, true],
    [`PO NUMBER: ${po.poNumber || ''}`, true],
    [`PO DATE: ${dateFmt(po.poDate)}`, false],
    [`PROJECT REFERENCE: ${po.projectReference || '-'}`, false],
    ...(po.poBasedOn ? [[`PO BASED ON: ${po.poBasedOn}`, false] as [string, boolean]] : []),
    ...(po.deliveryDate ? [[`DELIVERY DATE: ${dateFmt(po.deliveryDate)}`, false] as [string, boolean]] : []),
  ];
  infoRows.forEach(([text, isBold], index) => drawRight(page, text, PW - MR, infoTopY - index * 14, 8.5, isBold ? bold : regular, C_DARK));

  const headingY = PH - MT - 72;
  page.drawText('VENDOR PURCHASE ORDER', { x: ML, y: headingY, size: 28, font: bold, color: C_BLACK });

  const tableTop = headingY - 32;
  const tableLeft = ML;
  const tableRight = PW - MR;
  const tableWidth = UW;
  const headerHeight = 30;
  const col1X = tableLeft + tableWidth * 0.5;
  const col2X = tableLeft + tableWidth * 0.615;
  const col3X = tableLeft + tableWidth * 0.76;
  const col4X = tableLeft + tableWidth * 0.878;
  const col1W = col2X - col1X;
  const col2W = col3X - col2X;
  const col3W = col4X - col3X;
  const col4W = tableRight - col4X;

  box(page, tableLeft, tableTop - headerHeight, tableWidth, headerHeight, C_BGCELL, C_LGREY, 0.6);
  vline(page, col1X, tableTop, tableTop - headerHeight);
  vline(page, col2X, tableTop, tableTop - headerHeight);
  vline(page, col3X, tableTop, tableTop - headerHeight);
  vline(page, col4X, tableTop, tableTop - headerHeight);
  page.drawText('Brief Detail of Major Type Of Item / Service', { x: tableLeft + 8, y: tableTop - headerHeight / 2 - 3, size: 8, font: bold, color: C_DARK, maxWidth: col1X - tableLeft - 12 });

  const centerHeader = (text: string, colX: number, colW: number) => page.drawText(text, { x: colX + (colW - bold.widthOfTextAtSize(text, 8)) / 2, y: tableTop - headerHeight / 2 - 3, size: 8, font: bold, color: C_DARK });
  centerHeader('Qty', col1X, col1W);
  centerHeader('Qty Type', col2X, col2W);
  centerHeader('Unit Price', col3X, col3W);
  page.drawText('Amount', { x: col4X + (col4W - bold.widthOfTextAtSize('Amount', 8)) / 2, y: tableTop - 11, size: 8, font: bold, color: C_DARK });
  page.drawText('PKR', { x: col4X + (col4W - bold.widthOfTextAtSize('PKR', 8)) / 2, y: tableTop - 21, size: 8, font: bold, color: C_DARK });

  let curY = tableTop - headerHeight;
  for (const item of items) {
    const descLines = wrap(item.description || '', col1X - tableLeft - 14, regular, 9);
    const categoryLines = item.category?.trim() ? [`Category: ${item.category}`] : [];
    const allDescLines = [...descLines, ...categoryLines];
    const rowHeight = Math.max(24, allDescLines.length * 13 + 10);
    box(page, tableLeft, curY - rowHeight, tableWidth, rowHeight, undefined, C_LGREY, 0.5);
    vline(page, col1X, curY, curY - rowHeight);
    vline(page, col2X, curY, curY - rowHeight);
    vline(page, col3X, curY, curY - rowHeight);
    vline(page, col4X, curY, curY - rowHeight);
    let descY = curY - 11;
    for (const line of descLines) { page.drawText(line, { x: tableLeft + 8, y: descY, size: 9, font: regular, color: C_DARK }); descY -= 13; }
    for (const line of categoryLines) { page.drawText(line, { x: tableLeft + 8, y: descY, size: 7.5, font: regular, color: C_MID }); descY -= 11; }
    const midY = curY - rowHeight / 2 - 3.5;
    const qtyText = numFmt(item.quantity);
    page.drawText(qtyText, { x: col1X + (col1W - regular.widthOfTextAtSize(qtyText, 9)) / 2, y: midY, size: 9, font: regular, color: C_DARK });
    if (item.quantityType) page.drawText(item.quantityType, { x: col2X + (col2W - regular.widthOfTextAtSize(item.quantityType, 9)) / 2, y: midY, size: 9, font: regular, color: C_DARK });
    drawRight(page, numFmt(item.unitPrice), col4X - 6, midY, 9, regular, C_DARK);
    drawRight(page, numFmt(item.amount), tableRight - 6, midY, 9, regular, C_DARK);
    curY -= rowHeight;
  }

  const totalHeight = 28;
  box(page, tableLeft, curY - totalHeight, tableWidth, totalHeight, C_BGCELL, C_LGREY, 0.6);
  vline(page, col3X, curY, curY - totalHeight);
  vline(page, col4X, curY, curY - totalHeight);
  page.drawText(toWords(po.totalAmount), { x: tableLeft + 8, y: curY - totalHeight / 2 - 3.5, size: 8.5, font: bold, color: C_DARK, maxWidth: col3X - tableLeft - 14 });
  page.drawText('TOTAL', { x: col3X + (col4X - col3X - bold.widthOfTextAtSize('TOTAL', 9.5)) / 2, y: curY - totalHeight / 2 - 3.5, size: 9.5, font: bold, color: C_DARK });
  drawRight(page, numFmt(po.totalAmount), tableRight - 6, curY - totalHeight / 2 - 3.5, 9.5, bold, C_DARK);

  let nextY = curY - totalHeight - 28;
  if (po.attachments?.length) {
    page.drawText('ATTACHMENTS', { x: ML, y: nextY, size: 14, font: bold, color: C_BLACK });
    box(page, ML, nextY - 28, UW, 28, undefined, C_LGREY, 0.6);
    page.drawText(po.attachments.join(', '), { x: ML + 10, y: nextY - 17, size: 8.5, font: regular, color: C_DARK, maxWidth: UW - 20 });
    nextY -= 50;
  }

  page.drawText('DELIVERY DETAILS', { x: ML, y: nextY, size: 14, font: bold, color: C_BLACK });
  const deliveryTop = nextY - 16;
  const deliveryMid = ML + UW * 0.54;
  const leftPad = ML + 10;
  const rightPad = deliveryMid + 10;
  const leftWidth = deliveryMid - ML - 16;
  const rightWidth = ML + UW - deliveryMid - 16;
  const leftRows = [...wrap(`DELIVERY ADDRESS : ${po.deliveryAddress || ''}`, leftWidth, bold, 8), `ORDERED BY : ${po.preparedBy || ''}`];
  const rightRows = po.deliveryInstructions?.length ? po.deliveryInstructions : [];
  const deliveryHeight = Math.max(52, leftRows.length * 12 + 16, rightRows.length * 11 + 30);
  box(page, ML, deliveryTop - deliveryHeight, UW, deliveryHeight, undefined, C_LGREY, 0.6);
  vline(page, deliveryMid, deliveryTop, deliveryTop - deliveryHeight);
  let leftY = deliveryTop - 14;
  leftRows.forEach((line) => { page.drawText(line, { x: leftPad, y: leftY, size: 8, font: bold, color: C_DARK }); leftY -= 12; });
  if (rightRows.length) {
    page.drawText('DELIVERY INSTRUCTIONS', { x: rightPad, y: deliveryTop - 14, size: 8, font: bold, color: C_DARK });
    let rightY = deliveryTop - 27;
    rightRows.forEach((line) => { page.drawText(line, { x: rightPad, y: rightY, size: 8, font: regular, color: C_MID, maxWidth: rightWidth }); rightY -= 11; });
  }

  return pdfDoc.save();
}


