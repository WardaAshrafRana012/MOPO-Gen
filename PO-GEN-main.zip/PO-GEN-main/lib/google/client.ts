import { google } from 'googleapis';
import fs from 'fs';
import path from 'path';

function resolvePrivateKey() {
  const base64Key = process.env.GOOGLE_PRIVATE_KEY_BASE64?.trim();
  if (base64Key) {
    return Buffer.from(base64Key, 'base64').toString('utf8');
  }

  return process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, '\n');
}

export const GOOGLE_SPREADSHEET_ID = process.env.GOOGLE_SHEET_ID || '';
export const GOOGLE_DRIVE_FOLDER_ID = process.env.GOOGLE_DRIVE_FOLDER_ID || '';

const privateKey = resolvePrivateKey();
const clientEmail = process.env.GOOGLE_CLIENT_EMAIL || process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
const projectId = process.env.GOOGLE_PROJECT_ID;
const OAUTH_CLIENT_ID = process.env.GOOGLE_OAUTH_CLIENT_ID;
const OAUTH_CLIENT_SECRET = process.env.GOOGLE_OAUTH_CLIENT_SECRET;
const OAUTH_REDIRECT_URI = process.env.GOOGLE_OAUTH_REDIRECT_URI;
const OAUTH_TOKEN_PATH = process.env.GOOGLE_OAUTH_TOKEN_PATH || '.local/google-oauth-tokens.json';
const GOOGLE_AUTH_MODE = (process.env.GOOGLE_AUTH_MODE || 'auto').toLowerCase();

export function getOAuthTokenPath() {
  return OAUTH_TOKEN_PATH;
}

export function createOAuthClient() {
  if (!OAUTH_CLIENT_ID || !OAUTH_CLIENT_SECRET || !OAUTH_REDIRECT_URI) {
    throw new Error('Missing OAuth config in env');
  }

  return new google.auth.OAuth2(OAUTH_CLIENT_ID, OAUTH_CLIENT_SECRET, OAUTH_REDIRECT_URI);
}

function loadOAuthTokens() {
  const tokenJson = process.env.GOOGLE_OAUTH_TOKEN_JSON?.trim();
  if (tokenJson) return JSON.parse(tokenJson);

  const tokenFullPath = path.resolve(process.cwd(), OAUTH_TOKEN_PATH);
  if (!fs.existsSync(tokenFullPath)) {
    throw new Error(`OAuth token file not found at ${tokenFullPath}. Visit /oauth/start to authorize.`);
  }

  return JSON.parse(fs.readFileSync(tokenFullPath, 'utf8'));
}

async function getAuth() {
  const hasServiceAccount = Boolean(clientEmail && privateKey && GOOGLE_SPREADSHEET_ID && GOOGLE_DRIVE_FOLDER_ID);
  const hasOAuth = Boolean(OAUTH_CLIENT_ID && OAUTH_CLIENT_SECRET && OAUTH_REDIRECT_URI);

  if (GOOGLE_AUTH_MODE === 'service_account') {
    if (!hasServiceAccount) {
      throw new Error('GOOGLE_AUTH_MODE=service_account but service-account env vars are incomplete.');
    }

    return new google.auth.JWT({
      email: clientEmail,
      key: privateKey,
      scopes: ['https://www.googleapis.com/auth/spreadsheets', 'https://www.googleapis.com/auth/drive.file'],
      projectId,
    });
  }

  if (GOOGLE_AUTH_MODE === 'oauth') {
    if (!hasOAuth) {
      throw new Error('GOOGLE_AUTH_MODE=oauth but OAuth env vars are incomplete.');
    }

    const oauth2Client = createOAuthClient();
    oauth2Client.setCredentials(loadOAuthTokens());
    return oauth2Client;
  }

  if (hasServiceAccount) {
    return new google.auth.JWT({
      email: clientEmail,
      key: privateKey,
      scopes: ['https://www.googleapis.com/auth/spreadsheets', 'https://www.googleapis.com/auth/drive.file'],
      projectId,
    });
  }

  if (hasOAuth) {
    const oauth2Client = createOAuthClient();
    oauth2Client.setCredentials(loadOAuthTokens());
    return oauth2Client;
  }

  throw new Error('Missing required Google API environment variables. Please set either service-account vars (GOOGLE_CLIENT_EMAIL plus GOOGLE_PRIVATE_KEY_BASE64 or GOOGLE_PRIVATE_KEY, GOOGLE_SHEET_ID, GOOGLE_DRIVE_FOLDER_ID) or OAuth vars (GOOGLE_OAUTH_CLIENT_ID/GOOGLE_OAUTH_CLIENT_SECRET/GOOGLE_OAUTH_REDIRECT_URI).');
}

export async function getSheetsClient() {
  const auth = await getAuth();
  if (typeof (auth as any).authorize === 'function') {
    await (auth as any).authorize();
  }
  return google.sheets({ version: 'v4', auth });
}

export async function getDriveClient() {
  const auth = await getAuth();
  if (typeof (auth as any).authorize === 'function') {
    await (auth as any).authorize();
  }
  return google.drive({ version: 'v3', auth });
}
