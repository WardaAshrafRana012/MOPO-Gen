import { Readable } from 'stream';
import { getDriveClient, GOOGLE_DRIVE_FOLDER_ID } from './client';

/** Convert any buffer-like value to a Node.js Readable stream (required by googleapis v100+) */
function toReadable(buffer: Uint8Array | ArrayBuffer | Buffer): Readable {
  const buf = buffer instanceof Buffer ? buffer : Buffer.from(buffer as ArrayBuffer);
  return Readable.from(buf);
}

const APPS_SCRIPT_WEB_APP_URL = process.env.GOOGLE_APPS_SCRIPT_WEB_APP_URL?.trim() || '';

type DriveUploadResult = {
  id: string;
  webViewLink: string;
};

async function uploadViaAppsScript(
  action: 'upload' | 'update',
  buffer: Uint8Array | ArrayBuffer,
  fileName: string,
  fileId?: string
): Promise<DriveUploadResult> {
  if (!APPS_SCRIPT_WEB_APP_URL) {
    throw new Error('GOOGLE_APPS_SCRIPT_WEB_APP_URL is not configured.');
  }

  const pdfBase64 = Buffer.from(buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer)).toString('base64');
  const response = await fetch(APPS_SCRIPT_WEB_APP_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      action,
      fileName,
      fileId,
      pdfBase64,
    }),
    cache: 'no-store',
  });

  const text = await response.text();
  let data: { ok?: boolean; id?: string; webViewLink?: string; error?: string } = {};

  try {
    data = JSON.parse(text);
  } catch {
    throw new Error(`Apps Script upload returned non-JSON response (${response.status}): ${text.slice(0, 300)}`);
  }

  if (!response.ok || !data.ok || !data.id) {
    throw new Error(data.error || `Apps Script upload failed with status ${response.status}.`);
  }

  return {
    id: data.id,
    webViewLink: data.webViewLink || '',
  };
}

export async function uploadPDFToDrive(buffer: Uint8Array | ArrayBuffer, fileName: string) {
  if (APPS_SCRIPT_WEB_APP_URL) {
    return uploadViaAppsScript('upload', buffer, fileName);
  }

  const drive = await getDriveClient();
  const response = await drive.files.create({
    requestBody: {
      name: fileName,
      parents: [GOOGLE_DRIVE_FOLDER_ID],
      mimeType: 'application/pdf',
    },
    media: {
      mimeType: 'application/pdf',
      body: toReadable(buffer),
    },
    fields: 'id, webViewLink',
  });

  return {
    id: response.data.id || '',
    webViewLink: response.data.webViewLink || '',
  };
}

export async function updateDriveFile(fileId: string, buffer: Uint8Array | ArrayBuffer) {
  if (APPS_SCRIPT_WEB_APP_URL) {
    return uploadViaAppsScript('update', buffer, `${fileId}.pdf`, fileId);
  }

  const drive = await getDriveClient();
  const response = await drive.files.update({
    fileId,
    media: {
      mimeType: 'application/pdf',
      body: toReadable(buffer),
    },
    fields: 'id, webViewLink',
  });

  return {
    id: response.data.id || fileId,
    webViewLink: response.data.webViewLink || '',
  };
}

export function getDriveFileLink(fileId: string) {
  return `https://drive.google.com/file/d/${fileId}/view`;
}
