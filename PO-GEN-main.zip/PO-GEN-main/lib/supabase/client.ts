import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.SUPABASE_URL || '';
const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

export function isSupabaseConfigured() {
  return Boolean(supabaseUrl && supabaseServiceRoleKey);
}

export function getSupabaseAdmin() {
  if (!isSupabaseConfigured()) {
    throw new Error('Supabase is not configured. Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY.');
  }

  return createClient(supabaseUrl, supabaseServiceRoleKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  });
}

export const SUPABASE_TABLES = {
  orders: process.env.SUPABASE_PO_TABLE || 'purchase_orders',
  items: process.env.SUPABASE_PO_ITEMS_TABLE || 'purchase_order_items',
  activity: process.env.SUPABASE_ACTIVITY_TABLE || 'activity_logs',
  settings: process.env.SUPABASE_SETTINGS_TABLE || 'app_settings',
};
