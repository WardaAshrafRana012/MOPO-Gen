﻿import * as sheetsPo from '@/lib/po-sheets';
import { uploadPDFToDrive, updateDriveFile, getDriveFileLink } from '@/lib/google/drive';
import { generatePOPDF } from '@/lib/pdf/po';
import { getAppSettings, appendAppActivityLog } from '@/lib/storage';
import { getSupabaseAdmin, isSupabaseConfigured, SUPABASE_TABLES } from '@/lib/supabase/client';
import { formatAmountInWords, generatePoNumber, getNextVendorSerial } from '@/lib/utils/format';
import { parseTemplateMeta, serializeTemplateMeta } from '@/lib/po-template';
import type { PurchaseOrderItem, PurchaseOrderMain, PurchaseOrderPayload } from '@/types/po';

type DbOrderRow = {
  id: string;
  po_number: string;
  vendor_name: string;
  po_date: string;
  delivery_date: string | null;
  project_reference: string;
  delivery_address: string;
  prepared_by: string;
  telephone: string | null;
  delivery_instructions: string | null;
  item_category: string | null;
  items_count: number;
  total_amount: number;
  amount_in_words: string;
  pdf_link: string | null;
  drive_file_id: string | null;
  status: string;
  created_at: string;
  updated_at: string;
  archived: boolean;
};

type DbItemRow = {
  id: string;
  purchase_order_id: string;
  po_number: string;
  description: string;
  category: string | null;
  quantity_type: string | null;
  po_type: string | null;
  quantity: number;
  unit_price: number;
  amount: number;
  created_at: string;
  updated_at: string;
};

function mapOrder(row: DbOrderRow): PurchaseOrderMain {
  const templateMeta = parseTemplateMeta(row.delivery_instructions);

  return {
    poId: row.id,
    poNumber: row.po_number,
    vendorName: row.vendor_name,
    poDate: row.po_date,
    deliveryDate: row.delivery_date || '',
    projectReference: row.project_reference,
    deliveryAddress: row.delivery_address,
    preparedBy: row.prepared_by,
    poBasedOn: row.telephone || '',
    deliveryInstructions: templateMeta.deliveryInstructions,
    attachments: templateMeta.attachments,
    itemCategory: row.item_category || '',
    itemsCount: Number(row.items_count || 0),
    totalAmount: Number(row.total_amount || 0),
    amountInWords: row.amount_in_words || '',
    pdfLink: row.pdf_link || '',
    driveFileId: row.drive_file_id || '',
    status: row.status,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    archived: Boolean(row.archived),
  };
}

function mapItem(row: DbItemRow): PurchaseOrderItem {
  return {
    itemId: row.id,
    poId: row.purchase_order_id,
    poNumber: row.po_number,
    description: row.description,
    category: row.category || '',
    quantityType: row.quantity_type || '',
    poType: row.po_type || '',
    quantity: Number(row.quantity || 0),
    unitPrice: Number(row.unit_price || 0),
    amount: Number(row.amount || 0),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function validatePurchaseOrderPayload(payload: PurchaseOrderPayload) {
  if (!payload.vendorName?.trim()) throw new Error('Vendor Name is required.');
  if (!payload.projectReference?.trim()) throw new Error('Project Reference is required.');
  if (!payload.poDate?.trim()) throw new Error('PO Date is required.');
  if (!payload.deliveryAddress?.trim()) throw new Error('Delivery Address is required.');
  if (!payload.preparedBy?.trim()) throw new Error('Ordered By is required.');
  if (!payload.poBasedOn?.trim()) throw new Error('PO Based On is required.');
  if (!Array.isArray(payload.items) || payload.items.length === 0) throw new Error('At least one item is required.');
  for (const item of payload.items) {
    if (!item.description?.trim()) throw new Error('Brief Detail of Item / Service is required.');
    if (!item.category?.trim()) throw new Error('Item Category is required.');
    if (Number(item.quantity) <= 0) throw new Error('Item quantity must be greater than zero.');
    if (Number(item.unitPrice) < 0) throw new Error('Item unit price cannot be negative.');
  }
}

async function buildSettings() {
  const s = await getAppSettings();
  return {
    PO_PREFIX: s.PO_PREFIX || process.env.PO_PREFIX || 'PO',
    COMPANY_NAME: s.COMPANY_NAME || process.env.COMPANY_NAME || 'Molecule Work Place Solution',
    COMPANY_ADDRESS: s.COMPANY_ADDRESS || process.env.COMPANY_ADDRESS || '',
    COMPANY_NTN: s.COMPANY_NTN || process.env.COMPANY_NTN || '',
    COMPANY_STRN: s.COMPANY_STRN || process.env.COMPANY_STRN || '',
    FOOTER_TEXT: s.FOOTER_TEXT || 'Thank you for choosing Molecule.',
  };
}

function buildOrderInsert(payload: PurchaseOrderPayload, poId: string, poNumber: string, status: string, createdAt?: string) {
  const totalAmount = payload.items.reduce((sum, item) => sum + Number(item.quantity) * Number(item.unitPrice), 0);
  const now = new Date().toISOString();
  return {
    id: poId,
    po_number: poNumber,
    vendor_name: payload.vendorName,
    po_date: payload.poDate,
    delivery_date: payload.deliveryDate || null,
    project_reference: payload.projectReference,
    delivery_address: payload.deliveryAddress,
    prepared_by: payload.preparedBy,
    telephone: payload.poBasedOn || null,
    delivery_instructions: serializeTemplateMeta({
      deliveryInstructions: payload.deliveryInstructions,
      attachments: payload.attachments,
    }),
    item_category: payload.itemCategory || payload.items[0]?.category || null,
    items_count: payload.items.length,
    total_amount: totalAmount,
    amount_in_words: formatAmountInWords(totalAmount),
    pdf_link: null,
    drive_file_id: null,
    status,
    created_at: createdAt || now,
    updated_at: now,
    archived: false,
  };
}

function buildItemInserts(payload: PurchaseOrderPayload, poId: string, poNumber: string) {
  const now = new Date().toISOString();
  return payload.items.map((item) => ({
    id: crypto.randomUUID(),
    purchase_order_id: poId,
    po_number: poNumber,
    description: item.description,
    category: item.category || null,
    quantity_type: item.quantityType || null,
    po_type: payload.poBasedOn || item.poType || null,
    quantity: Number(item.quantity),
    unit_price: Number(item.unitPrice),
    amount: Number(item.quantity) * Number(item.unitPrice),
    created_at: now,
    updated_at: now,
  }));
}

async function getSupabasePurchaseOrderById(poId: string) {
  const supabase = getSupabaseAdmin();
  const { data: order, error: orderError } = await supabase
    .from(SUPABASE_TABLES.orders)
    .select('*')
    .eq('id', poId)
    .maybeSingle();

  if (orderError) throw new Error(`Supabase order lookup failed: ${orderError.message}`);
  if (!order) return null;

  const { data: items, error: itemError } = await supabase
    .from(SUPABASE_TABLES.items)
    .select('*')
    .eq('purchase_order_id', poId)
    .order('created_at', { ascending: true });

  if (itemError) throw new Error(`Supabase item lookup failed: ${itemError.message}`);

  return {
    main: mapOrder(order as DbOrderRow),
    items: (items || []).map((item) => mapItem(item as DbItemRow)),
  };
}

export async function getAllPurchaseOrders(includeArchived = false) {
  if (!isSupabaseConfigured()) {
    return sheetsPo.getAllPurchaseOrders(includeArchived);
  }

  const supabase = getSupabaseAdmin();
  let query = supabase.from(SUPABASE_TABLES.orders).select('*').order('created_at', { ascending: false });
  if (!includeArchived) query = query.eq('archived', false);
  const { data, error } = await query;
  if (error) throw new Error(`Supabase orders load failed: ${error.message}`);
  return (data || []).map((row) => mapOrder(row as DbOrderRow));
}

export async function getPurchaseOrderById(poId: string) {
  if (!isSupabaseConfigured()) {
    return sheetsPo.getPurchaseOrderById(poId);
  }

  return getSupabasePurchaseOrderById(poId);
}

export async function createPurchaseOrder(payload: PurchaseOrderPayload) {
  if (!isSupabaseConfigured()) {
    return sheetsPo.createPurchaseOrder(payload);
  }

  validatePurchaseOrderPayload(payload);
  const supabase = getSupabaseAdmin();
  const settings = await buildSettings();
  const { data: existingRows, error: existingError } = await supabase
    .from(SUPABASE_TABLES.orders)
    .select('po_number');
  if (existingError) throw new Error(`Supabase PO number lookup failed: ${existingError.message}`);

  const existingNumbers = (existingRows || []).map((row: { po_number: string }) => String(row.po_number || ''));
  const serial = getNextVendorSerial(existingNumbers, payload.vendorName, settings.PO_PREFIX);
  const poNumber = generatePoNumber(payload.vendorName, serial, settings.PO_PREFIX);
  const poId = crypto.randomUUID();

  const orderInsert = buildOrderInsert(payload, poId, poNumber, 'Generated');
  const itemInserts = buildItemInserts(payload, poId, poNumber);

  const { error: insertOrderError } = await supabase.from(SUPABASE_TABLES.orders).insert(orderInsert);
  if (insertOrderError) throw new Error(`Supabase order insert failed: ${insertOrderError.message}`);

  const { error: insertItemsError } = await supabase.from(SUPABASE_TABLES.items).insert(itemInserts);
  if (insertItemsError) throw new Error(`Supabase item insert failed: ${insertItemsError.message}`);

  const purchaseOrder = mapOrder(orderInsert as DbOrderRow);
  const pdfBuffer = await generatePOPDF(purchaseOrder, itemInserts.map((item) => mapItem(item as DbItemRow)), settings);
  const fileName = `${poNumber}.pdf`;
  const uploaded = await uploadPDFToDrive(pdfBuffer, fileName);
  const pdfLink = getDriveFileLink(uploaded.id);

  const { error: updateError } = await supabase
    .from(SUPABASE_TABLES.orders)
    .update({
      pdf_link: pdfLink,
      drive_file_id: uploaded.id,
      status: 'Generated',
      updated_at: new Date().toISOString(),
    })
    .eq('id', poId);
  if (updateError) throw new Error(`Supabase PDF update failed: ${updateError.message}`);

  await appendAppActivityLog({
    Log_ID: crypto.randomUUID(),
    Time: new Date().toISOString(),
    Action: 'PO generated',
    PO_Number: poNumber,
    User: 'System',
    Status: 'Generated',
    Details: `PO created, PDF uploaded. Vendor: ${payload.vendorName}`,
  });

  return { poId, poNumber, status: 'Generated', pdfLink, driveFileId: uploaded.id };
}

export async function updatePurchaseOrder(poId: string, payload: PurchaseOrderPayload) {
  if (!isSupabaseConfigured()) {
    return sheetsPo.updatePurchaseOrder(poId, payload);
  }

  validatePurchaseOrderPayload(payload);
  const supabase = getSupabaseAdmin();
  const existing = await getSupabasePurchaseOrderById(poId);
  if (!existing) throw new Error(`Purchase order ${poId} not found.`);

  const settings = await buildSettings();
  const poNumber = existing.main.poNumber;
  const orderUpdate = buildOrderInsert(payload, poId, poNumber, 'Updated', existing.main.createdAt);
  orderUpdate.pdf_link = existing.main.pdfLink || null;
  orderUpdate.drive_file_id = existing.main.driveFileId || null;
  orderUpdate.archived = existing.main.archived;

  const { error: updateOrderError } = await supabase.from(SUPABASE_TABLES.orders).update(orderUpdate).eq('id', poId);
  if (updateOrderError) throw new Error(`Supabase order update failed: ${updateOrderError.message}`);

  const { error: deleteItemsError } = await supabase.from(SUPABASE_TABLES.items).delete().eq('purchase_order_id', poId);
  if (deleteItemsError) throw new Error(`Supabase old item cleanup failed: ${deleteItemsError.message}`);

  const itemInserts = buildItemInserts(payload, poId, poNumber);
  const { error: insertItemsError } = await supabase.from(SUPABASE_TABLES.items).insert(itemInserts);
  if (insertItemsError) throw new Error(`Supabase item update failed: ${insertItemsError.message}`);

  const purchaseOrder = mapOrder(orderUpdate as DbOrderRow);
  const pdfBuffer = await generatePOPDF(purchaseOrder, itemInserts.map((item) => mapItem(item as DbItemRow)), settings);
  const uploaded = existing.main.driveFileId
    ? await updateDriveFile(existing.main.driveFileId, pdfBuffer)
    : await uploadPDFToDrive(pdfBuffer, `${poNumber}.pdf`);
  const pdfLink = getDriveFileLink(uploaded.id);

  const { error: pdfUpdateError } = await supabase.from(SUPABASE_TABLES.orders).update({
    pdf_link: pdfLink,
    drive_file_id: uploaded.id,
    status: 'Updated',
    updated_at: new Date().toISOString(),
  }).eq('id', poId);
  if (pdfUpdateError) throw new Error(`Supabase PDF update failed: ${pdfUpdateError.message}`);

  await appendAppActivityLog({
    Log_ID: crypto.randomUUID(),
    Time: new Date().toISOString(),
    Action: 'PO updated',
    PO_Number: poNumber,
    User: 'System',
    Status: 'Updated',
    Details: 'PO edited and PDF regenerated.',
  });

  return { poId, poNumber, status: 'Updated', pdfLink, driveFileId: uploaded.id };
}

export async function regeneratePurchaseOrderPDF(poId: string) {
  if (!isSupabaseConfigured()) {
    return sheetsPo.regeneratePurchaseOrderPDF(poId);
  }

  const supabase = getSupabaseAdmin();
  const existing = await getSupabasePurchaseOrderById(poId);
  if (!existing) throw new Error(`Purchase order ${poId} not found.`);

  const settings = await buildSettings();
  const pdfBuffer = await generatePOPDF(existing.main, existing.items, settings);
  const uploaded = existing.main.driveFileId
    ? await updateDriveFile(existing.main.driveFileId, pdfBuffer)
    : await uploadPDFToDrive(pdfBuffer, `${existing.main.poNumber}.pdf`);
  const pdfLink = getDriveFileLink(uploaded.id);

  const { error } = await supabase.from(SUPABASE_TABLES.orders).update({
    pdf_link: pdfLink,
    drive_file_id: uploaded.id,
    status: 'PDF Regenerated',
    updated_at: new Date().toISOString(),
  }).eq('id', poId);
  if (error) throw new Error(`Supabase PDF regenerate update failed: ${error.message}`);

  await appendAppActivityLog({
    Log_ID: crypto.randomUUID(),
    Time: new Date().toISOString(),
    Action: 'PDF regenerated',
    PO_Number: existing.main.poNumber,
    User: 'System',
    Status: 'Generated',
    Details: 'PDF regenerated on Drive.',
  });

  return { poId, poNumber: existing.main.poNumber, pdfLink, driveFileId: uploaded.id };
}

export async function archivePurchaseOrder(poId: string) {
  if (!isSupabaseConfigured()) {
    return sheetsPo.archivePurchaseOrder(poId);
  }

  const supabase = getSupabaseAdmin();
  const existing = await getSupabasePurchaseOrderById(poId);
  if (!existing) throw new Error(`Purchase order ${poId} not found.`);

  const { error } = await supabase.from(SUPABASE_TABLES.orders).update({
    archived: true,
    status: 'Archived',
    updated_at: new Date().toISOString(),
  }).eq('id', poId);
  if (error) throw new Error(`Supabase archive failed: ${error.message}`);

  await appendAppActivityLog({
    Log_ID: crypto.randomUUID(),
    Time: new Date().toISOString(),
    Action: 'PO archived',
    PO_Number: existing.main.poNumber,
    User: 'System',
    Status: 'Archived',
    Details: 'Purchase order archived.',
  });

  return { poId, poNumber: existing.main.poNumber };
}

export async function deletePurchaseOrder(poId: string) {
  if (!isSupabaseConfigured()) {
    return sheetsPo.deletePurchaseOrder(poId);
  }

  const supabase = getSupabaseAdmin();
  const existing = await getSupabasePurchaseOrderById(poId);
  if (!existing) throw new Error(`Purchase order ${poId} not found.`);

  const { error: deleteItemsError } = await supabase.from(SUPABASE_TABLES.items).delete().eq('purchase_order_id', poId);
  if (deleteItemsError) throw new Error(`Supabase item delete failed: ${deleteItemsError.message}`);
  const { error: deleteOrderError } = await supabase.from(SUPABASE_TABLES.orders).delete().eq('id', poId);
  if (deleteOrderError) throw new Error(`Supabase order delete failed: ${deleteOrderError.message}`);

  await appendAppActivityLog({
    Log_ID: crypto.randomUUID(),
    Time: new Date().toISOString(),
    Action: 'PO deleted',
    PO_Number: existing.main.poNumber,
    User: 'System',
    Status: 'Deleted',
    Details: `PO ${existing.main.poNumber} permanently deleted.`,
  });

  return { poId, poNumber: existing.main.poNumber };
}
