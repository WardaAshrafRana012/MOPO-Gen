﻿import {
  appendActivityLog as appendSheetActivityLog,
  getActivityLogs as getSheetActivityLogs,
  getSettings as getSheetSettings,
  updateSettings as updateSheetSettings,
  verifyRequiredTabs,
  getSheetRows,
  SHEET_NAMES,
} from '@/lib/google/sheets';
import { getSupabaseAdmin, isSupabaseConfigured, SUPABASE_TABLES } from '@/lib/supabase/client';

const APPS_SCRIPT_WEB_APP_URL = process.env.GOOGLE_APPS_SCRIPT_WEB_APP_URL?.trim() || '';

function defaults() {
  return {
    GOOGLE_DRIVE_FOLDER_ID: process.env.GOOGLE_DRIVE_FOLDER_ID || '',
    PO_PREFIX: process.env.PO_PREFIX || 'PO',
    COMPANY_NAME: process.env.COMPANY_NAME || 'Molecule Work Place Solution',
    COMPANY_ADDRESS: process.env.COMPANY_ADDRESS || '',
    COMPANY_NTN: process.env.COMPANY_NTN || '',
    COMPANY_STRN: process.env.COMPANY_STRN || '',
    FOOTER_TEXT: process.env.FOOTER_TEXT || 'Thank you for choosing Molecule.',
    DELIVERY_DATE_REQUIRED: 'false',
    ARCHIVE_INSTEAD_OF_DELETE: 'true',
    THEME: 'dark',
    ACCENT: 'champagne',
    GLASS_INTENSITY: 'medium',
    LOGO_PATH: process.env.DEFAULT_LOGO_PATH || '/molecule-logo.png',
    STORAGE_PROVIDER: isSupabaseConfigured() ? 'supabase' : 'google-sheets',
    GOOGLE_SHEET_ID: process.env.GOOGLE_SHEET_ID || '',
    SUPABASE_URL: process.env.SUPABASE_URL || '',
    GOOGLE_APPS_SCRIPT_WEB_APP_URL: APPS_SCRIPT_WEB_APP_URL,
  };
}

export async function getAppSettings() {
  if (!isSupabaseConfigured()) {
    return getSheetSettings();
  }

  const supabase = getSupabaseAdmin();
  const { data, error } = await supabase.from(SUPABASE_TABLES.settings).select('key, value');
  if (error) throw new Error(`Supabase settings load failed: ${error.message}`);

  const stored = (data || []).reduce<Record<string, string>>((acc, row) => {
    acc[String(row.key)] = String(row.value ?? '');
    return acc;
  }, {});

  return { ...defaults(), ...stored };
}

export async function updateAppSettings(updates: Record<string, string>) {
  if (!isSupabaseConfigured()) {
    return updateSheetSettings(updates);
  }

  const supabase = getSupabaseAdmin();
  const merged = {
    ...updates,
    DELIVERY_DATE_REQUIRED: 'false',
    ARCHIVE_INSTEAD_OF_DELETE: updates.ARCHIVE_INSTEAD_OF_DELETE ?? 'true',
  };

  const rows = Object.entries(merged).map(([key, value]) => ({ key, value }));
  const { error } = await supabase.from(SUPABASE_TABLES.settings).upsert(rows, { onConflict: 'key' });
  if (error) throw new Error(`Supabase settings update failed: ${error.message}`);
}

export async function appendAppActivityLog(logData: Record<string, string | number>) {
  if (!isSupabaseConfigured()) {
    return appendSheetActivityLog(logData);
  }

  const supabase = getSupabaseAdmin();
  const payload = {
    id: String(logData.Log_ID || crypto.randomUUID()),
    time: String(logData.Time || new Date().toISOString()),
    action: String(logData.Action || ''),
    po_number: String(logData.PO_Number || ''),
    user_name: String(logData.User || 'System'),
    status: String(logData.Status || ''),
    details: String(logData.Details || ''),
  };

  const { error } = await supabase.from(SUPABASE_TABLES.activity).insert(payload);
  if (error) throw new Error(`Supabase activity log failed: ${error.message}`);
}

export async function getAppActivityLogs() {
  if (!isSupabaseConfigured()) {
    return getSheetActivityLogs();
  }

  const supabase = getSupabaseAdmin();
  const { data, error } = await supabase.from(SUPABASE_TABLES.activity).select('*').order('time', { ascending: true });
  if (error) throw new Error(`Supabase activity load failed: ${error.message}`);

  return (data || []).map((row) => ({
    Log_ID: row.id,
    Time: row.time,
    Action: row.action,
    PO_Number: row.po_number,
    User: row.user_name,
    Status: row.status,
    Details: row.details,
  }));
}

export async function verifyAppStorage() {
  if (!isSupabaseConfigured()) {
    if (APPS_SCRIPT_WEB_APP_URL) {
      return {
        provider: 'google-apps-script',
        requiredTargets: [SHEET_NAMES.main, SHEET_NAMES.items, process.env.GOOGLE_DRIVE_FOLDER_ID || 'drive-folder'],
        missingTargets: [],
        spreadsheetId: process.env.GOOGLE_SHEET_ID || '',
        poCount: 0,
      };
    }

    const sheetStatus = await verifyRequiredTabs();
    const { rows } = await getSheetRows(SHEET_NAMES.main);
    const poCount = rows.filter((r) => r.values.PO_ID).length;

    return {
      provider: 'google-sheets',
      requiredTargets: sheetStatus.requiredTabs,
      missingTargets: sheetStatus.missingTabs,
      spreadsheetId: sheetStatus.spreadsheetId,
      poCount,
    };
  }

  const supabase = getSupabaseAdmin();
  const tables = [SUPABASE_TABLES.orders, SUPABASE_TABLES.items, SUPABASE_TABLES.activity, SUPABASE_TABLES.settings];
  const missingTargets: string[] = [];

  for (const table of tables) {
    const { error } = await supabase.from(table).select('*', { count: 'exact', head: true });
    if (error) missingTargets.push(table);
  }

  const { count, error } = await supabase.from(SUPABASE_TABLES.orders).select('*', { count: 'exact', head: true });
  if (error && !missingTargets.includes(SUPABASE_TABLES.orders)) {
    throw new Error(`Supabase verification failed: ${error.message}`);
  }

  return {
    provider: 'supabase',
    requiredTargets: tables,
    missingTargets,
    projectUrl: process.env.SUPABASE_URL || '',
    poCount: count || 0,
  };
}

