﻿export const PO_BASED_ON_OPTIONS = ['Vendor Quote', 'Cash Purchase', 'Molecule Order'] as const;

export const DELIVERY_INSTRUCTION_OPTIONS = [
  'Packed for Transport',
  'Final Finished at Project Site',
] as const;

export const ATTACHMENT_OPTIONS = ['Sample', 'Drawing', 'Ref Image', 'Other'] as const;

export const DELIVERY_ADDRESS_OPTIONS = [
  'Molecule Office',
  'Vendor Site',
  'Pick Up From Vendor Site',
  'Other',
] as const;

export type TemplateMeta = {
  deliveryInstructions: string[];
  attachments: string[];
};

export function serializeTemplateMeta(value: Partial<TemplateMeta> | undefined) {
  return JSON.stringify({
    deliveryInstructions: value?.deliveryInstructions ?? [],
    attachments: value?.attachments ?? [],
  });
}

export function parseTemplateMeta(value?: string | null): TemplateMeta {
  if (!value?.trim()) {
    return { deliveryInstructions: [], attachments: [] };
  }

  try {
    const parsed = JSON.parse(value);
    return {
      deliveryInstructions: Array.isArray(parsed?.deliveryInstructions)
        ? parsed.deliveryInstructions.map((item: unknown) => String(item).trim()).filter(Boolean)
        : [],
      attachments: Array.isArray(parsed?.attachments)
        ? parsed.attachments
            .map((item: unknown) => {
              const normalized = String(item).trim();
              return normalized === 'Reference Image' ? 'Ref Image' : normalized;
            })
            .filter(Boolean)
        : [],
    };
  } catch {
    return {
      deliveryInstructions: [value.trim()],
      attachments: [],
    };
  }
}
