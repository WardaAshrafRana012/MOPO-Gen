const configuredBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL?.trim() || '';

function previewBody(text: string) {
  return text.replace(/\s+/g, ' ').trim().slice(0, 300);
}

export function buildApiUrl(path: string) {
  if (/^https?:\/\//i.test(path)) return path;
  if (!configuredBaseUrl) return path;
  return new URL(path, configuredBaseUrl).toString();
}

export async function parseJsonResponse<T>(response: Response, url: string): Promise<T> {
  const text = await response.text();
  const contentType = response.headers.get('content-type') || '';
  const isJson = contentType.toLowerCase().includes('application/json');
  const bodyPreview = previewBody(text);
  let parsed: unknown = null;

  if (isJson && text) {
    try {
      parsed = JSON.parse(text) as T;
    } catch (error) {
      throw new Error(
        `Invalid JSON from ${url} (${response.status}). ${String(error)}. Body preview: ${bodyPreview}`,
      );
    }
  }

  if (!response.ok) {
    const jsonError =
      parsed && typeof parsed === 'object'
        ? (parsed as { error?: string; message?: string }).error ||
          (parsed as { error?: string; message?: string }).message
        : '';

    throw new Error(
      isJson
        ? `Request failed (${response.status}) for ${url}. ${jsonError || 'Unknown error.'}`
        : `Expected JSON from ${url} but received ${contentType || 'unknown content type'} with status ${response.status}. Body preview: ${bodyPreview}`,
    );
  }

  if (!isJson) {
    throw new Error(
      `Expected JSON from ${url} but received ${contentType || 'unknown content type'} with status ${response.status}. Body preview: ${bodyPreview}`,
    );
  }

  return parsed as T;
}

export async function apiFetchJson<T>(path: string, init?: RequestInit): Promise<T> {
  const url = buildApiUrl(path);
  const method = (init?.method || 'GET').toUpperCase();

  if (typeof window !== 'undefined') {
    console.info(`[MOPO API] ${method} ${url}`);
  }

  const response = await fetch(url, init);
  return parseJsonResponse<T>(response, url);
}

