export interface PurchaseOrderItem {
  itemId:        string;
  poId:          string;
  poNumber:      string;
  description:   string;
  category?:     string;
  quantityType?: string;   // Unit | PCS | Set | Job | RFT | SFT
  poType?:       string;   // Bill | Quote | '' (optional)
  quantity:      number;
  unitPrice:     number;
  amount:        number;
  createdAt:     string;
  updatedAt:     string;
}

export interface PurchaseOrderMain {
  poId:                  string;
  poNumber:              string;
  vendorName:            string;
  poDate:                string;
  deliveryDate?:         string;
  projectReference:      string;   // renamed from reference, now required
  deliveryAddress:       string;
  preparedBy:            string;
  telephone?:            string;
  deliveryInstructions?: string;
  itemCategory?:         string;
  itemsCount:            number;
  totalAmount:           number;
  amountInWords:         string;
  pdfLink?:              string;
  driveFileId?:          string;
  status:                string;
  createdAt:             string;
  updatedAt:             string;
  archived:              boolean;
}

export interface PurchaseOrderPayload {
  vendorName:             string;
  poDate:                 string;
  deliveryDate?:          string;
  projectReference:       string;   // required
  deliveryAddress:        string;
  preparedBy:             string;
  telephone?:             string;
  deliveryInstructions?:  string;
  itemCategory?:          string;
  items: Array<{
    description:   string;
    quantity:      number;
    unitPrice:     number;
    category?:     string;
    quantityType?: string;
    poType?:       string;
  }>;
  saveDraft?: boolean;
}
