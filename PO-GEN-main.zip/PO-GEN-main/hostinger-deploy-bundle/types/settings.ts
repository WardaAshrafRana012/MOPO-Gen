export interface AppSettings {
  spreadsheetId?: string;
  driveFolderId?: string;
  poPrefix?: string;
  companyName?: string;
  companyAddress?: string;
  companyNTN?: string;
  companySTRN?: string;
  footerText?: string;
  logoPath?: string;
  deliveryDateRequired?: boolean;
  archiveInsteadOfDelete?: boolean;
  defaultLogoPath?: string;
}
