# PO Generator From Google Sheets

This app watches a Google Sheet and generates a purchase order PDF from your template when a checkbox is checked.

Flow:

1. A spreadsheet row is checked in the configured checkbox column.
2. The app reads that row.
3. It writes the row values onto the template PDF.
4. It uploads the generated PDF to Google Drive.
5. It writes the PO number, status, and PDF link back into the sheet.

## Template

The current template path is expected in:

`PO_TEMPLATE_PATH`

Example:

`C:\Users\umair\Downloads\PO# 324-ANW_ANWAR TRUCK.pdf`

The current implementation overlays these fields onto the template:

- Vendor name
- PO number
- PO date
- Delivery date
- Reference
- Item description
- Quantity
- Unit price
- Amount
- Amount in words
- Delivery address
- Prepared by
- Telephone
- Delivery instructions

## Auth Modes

The app supports two authentication modes:

1. OAuth client credentials
2. Service account credentials

If both are present, the app prefers the service-account path.

## Spreadsheet Requirements

The sheet must contain a header row with a checkbox column.

Example headers:

`Vendor | Item Description | Quantity | Unit Price | Generate PO | PO Number | PO Status | PO PDF`

The app will add `PO Number`, `PO Status`, and `PO PDF` headers if they do not already exist.

## Setup

1. Install dependencies:
   `npm install`
2. Copy `.env.example` to `.env`
3. Fill in:
   `GOOGLE_SHEET_ID`
   `GOOGLE_SHEET_NAME`
   `GOOGLE_CHECKBOX_COLUMN`
   `PO_TEMPLATE_PATH`
4. Add either:
   `GOOGLE_OAUTH_CLIENT_ID`
   `GOOGLE_OAUTH_CLIENT_SECRET`
   `GOOGLE_OAUTH_REDIRECT_URI`

   or:

   `GOOGLE_SERVICE_ACCOUNT_EMAIL`
   `GOOGLE_PRIVATE_KEY`
5. Start the app:
   `npm run dev`
6. Open:
   `http://localhost:4017`

## OAuth Connection

If you use OAuth client credentials:

1. Start the app locally
2. Open `http://localhost:4017/oauth/start`
3. Sign in with the Google account that owns the sheet or has access to it
4. The app stores tokens locally in `.oauth-tokens.json`

## Running The Automation

1. Tick the checkbox in the configured checkbox column
2. Wait for the poll cycle, or click `Process Checked Rows Now`
3. The app writes the generated PDF link back into the spreadsheet

## Important Notes

- `GOOGLE_OAUTH_REDIRECT_URI` must match the redirect URI configured in Google Cloud, for example `http://localhost:4017/oauth/callback`
- If you use OAuth, the signed-in Google account must have access to the target spreadsheet and Drive folder
- If you use a service account, share the sheet and Drive folder with that service account email
- `PO_TEMPLATE_PATH` must point to a readable local PDF file
