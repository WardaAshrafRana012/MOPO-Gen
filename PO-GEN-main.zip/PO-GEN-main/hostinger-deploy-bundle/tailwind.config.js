export default {
  content: ['./app/**/*.{js,ts,jsx,tsx}', './components/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        charcoal: '#11151e',
        onyx: '#0f131c',
        pearl: '#f5f1eb',
        champagne: '#d4b783',
        frost: 'rgba(255,255,255,0.12)',
      },
      boxShadow: {
        glass: '0 24px 80px rgba(0, 0, 0, 0.26)',
      },
      borderRadius: {
        '4xl': '2rem',
      },
      backdropBlur: {
        xxl: '36px',
      },
    },
  },
  plugins: [],
};
