import {
  appendActivityLog,
  appendSheetRow,
  appendSheetRows,
  findRowByField,
  findRowsByField,
  getSheetRows,
  getSettings,
  SHEET_NAMES,
  updateSheetRow,
  GOOGLE_SPREADSHEET_ID,
} from '@/lib/google/sheets';
import { getSheetsClient } from '@/lib/google/client';
import { uploadPDFToDrive, updateDriveFile, getDriveFileLink } from '@/lib/google/drive';
import { formatAmountInWords, generatePoNumber, getNextVendorSerial } from '@/lib/utils/format';
import { generatePOPDF } from '@/lib/pdf/po';
import { PurchaseOrderItem, PurchaseOrderMain, PurchaseOrderPayload } from '@/types/po';

const MAIN_SHEET  = SHEET_NAMES.main;
const ITEMS_SHEET = SHEET_NAMES.items;

type SheetValue = string | number | boolean | undefined;
type SheetRow   = Record<string, SheetValue>;

// ─── Mappers ─────────────────────────────────────────────────────────────────
function toMainRecord(row: SheetRow): PurchaseOrderMain {
  return {
    poId:                 String(row.PO_ID                 || ''),
    poNumber:             String(row.PO_Number             || ''),
    vendorName:           String(row.Vendor_Name           || ''),
    poDate:               String(row.PO_Date               || ''),
    deliveryDate:         String(row.Delivery_Date         || ''),
    projectReference:     String(row.Project_Reference     || row.Reference || ''),
    deliveryAddress:      String(row.Delivery_Address      || ''),
    preparedBy:           String(row.Prepared_By           || ''),
    telephone:            String(row.Telephone             || ''),
    deliveryInstructions: String(row.Delivery_Instructions || ''),
    itemCategory:         String(row.Item_Category         || ''),
    itemsCount:           Number(row.Items_Count)          || 0,
    totalAmount:          Number(row.Total_Amount)         || 0,
    amountInWords:        String(row.Amount_In_Words       || ''),
    pdfLink:              String(row.PDF_Link              || ''),
    driveFileId:          String(row.Drive_File_ID         || ''),
    status:               String(row.Status                || ''),
    createdAt:            String(row.Created_At            || ''),
    updatedAt:            String(row.Updated_At            || ''),
    archived:             String(row.Archived).toLowerCase() === 'true',
  };
}

function toItemRecord(row: SheetRow): PurchaseOrderItem {
  return {
    itemId:       String(row.Item_ID       || ''),
    poId:         String(row.PO_ID         || ''),
    poNumber:     String(row.PO_Number     || ''),
    description:  String(row.Description  || ''),
    category:     String(row.Category     || ''),
    quantityType: String(row.Quantity_Type || ''),
    poType:       String(row.PO_Type       || ''),
    quantity:     Number(row.Quantity)     || 0,
    unitPrice:    Number(row.Unit_Price)   || 0,
    amount:       Number(row.Amount)       || 0,
    createdAt:    String(row.Created_At    || ''),
    updatedAt:    String(row.Updated_At    || ''),
  };
}

function isArchivedRow(row: { values: SheetRow }) {
  return String(row.values.Archived || '').toLowerCase() === 'true';
}

// ─── Validation ───────────────────────────────────────────────────────────────
function validatePurchaseOrderPayload(payload: PurchaseOrderPayload) {
  if (!payload.vendorName?.trim())          throw new Error('Vendor Name is required.');
  if (!payload.projectReference?.trim())    throw new Error('Project Reference is required.');
  if (!payload.poDate?.trim())              throw new Error('PO Date is required.');
  if (!payload.deliveryAddress?.trim())     throw new Error('Delivery Address is required.');
  if (!payload.preparedBy?.trim())          throw new Error('Prepared By is required.');
  if (!Array.isArray(payload.items) || payload.items.length === 0)
    throw new Error('At least one item is required.');
  for (const item of payload.items) {
    if (!item.description?.trim()) throw new Error('Brief Detail of Item / Service is required.');
    if (!item.category?.trim()) throw new Error('Item Category is required.');
    if (Number(item.quantity) <= 0) throw new Error('Item quantity must be greater than zero.');
    if (Number(item.unitPrice) < 0) throw new Error('Item unit price cannot be negative.');
  }
}

// ─── Row builders ─────────────────────────────────────────────────────────────
async function buildMainRow(
  payload:  PurchaseOrderPayload,
  poId:     string,
  poNumber: string,
  status:   string,
) {
  const totalAmount = payload.items.reduce((s, i) => s + i.quantity * i.unitPrice, 0);
  const now         = new Date().toISOString();
  return {
    PO_ID:                 poId,
    PO_Number:             poNumber,
    Vendor_Name:           payload.vendorName,
    PO_Date:               payload.poDate,
    Delivery_Date:         payload.deliveryDate        || '',
    Project_Reference:     payload.projectReference,
    Delivery_Address:      payload.deliveryAddress,
    Prepared_By:           payload.preparedBy,
    Telephone:             payload.telephone           || '',
    Delivery_Instructions: payload.deliveryInstructions || '',
    Item_Category:         payload.itemCategory        || '',
    Items_Count:           payload.items.length,
    Total_Amount:          totalAmount,
    Amount_In_Words:       formatAmountInWords(totalAmount),
    PDF_Link:              '',
    Drive_File_ID:         '',
    Status:                status,
    Created_At:            now,
    Updated_At:            now,
    Archived:              'FALSE',
  };
}

function buildItemRows(payload: PurchaseOrderPayload, poId: string, poNumber: string) {
  const now = new Date().toISOString();
  return payload.items.map((item) => ({
    Item_ID:       crypto.randomUUID(),
    PO_ID:         poId,
    PO_Number:     poNumber,
    Description:   item.description,
    Category:      item.category      || '',
    Quantity_Type: item.quantityType  || '',
    PO_Type:       item.poType        || '',
    Quantity:      item.quantity,
    Unit_Price:    item.unitPrice,
    Amount:        item.quantity * item.unitPrice,
    Created_At:    now,
    Updated_At:    now,
    Archived:      'FALSE',
  }));
}

async function buildSettings() {
  const s = await getSettings();
  return {
    PO_PREFIX:       s.PO_PREFIX       || process.env.PO_PREFIX       || 'PO',
    COMPANY_NAME:    s.COMPANY_NAME    || process.env.COMPANY_NAME    || 'Molecule Work Place Solution',
    COMPANY_ADDRESS: s.COMPANY_ADDRESS || process.env.COMPANY_ADDRESS || '',
    COMPANY_NTN:     s.COMPANY_NTN     || process.env.COMPANY_NTN     || '',
    COMPANY_STRN:    s.COMPANY_STRN    || process.env.COMPANY_STRN    || '',
    FOOTER_TEXT:     s.FOOTER_TEXT     || 'Thank you for choosing Molecule.',
  };
}

// ─── Public API ───────────────────────────────────────────────────────────────
export async function getAllPurchaseOrders(includeArchived = false) {
  const { rows } = await getSheetRows(MAIN_SHEET);
  return rows
    .map((r) => toMainRecord(r.values))
    .filter((rec) => includeArchived || !rec.archived)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export async function getPurchaseOrderById(poId: string) {
  const mainRow = await findRowByField(MAIN_SHEET, 'PO_ID', poId);
  if (!mainRow) return null;
  const itemRows = await findRowsByField(ITEMS_SHEET, 'PO_ID', poId);
  return {
    main:  toMainRecord(mainRow.values),
    items: itemRows.filter((r) => !isArchivedRow(r)).map((r) => toItemRecord(r.values)),
  };
}

export async function createPurchaseOrder(payload: PurchaseOrderPayload) {
  validatePurchaseOrderPayload(payload);

  const { rows: existingRows } = await getSheetRows(MAIN_SHEET);
  const existingNumbers        = existingRows.map((r) => String(r.values.PO_Number || ''));
  const settings               = await buildSettings();

  // Vendor-wise independent serial
  const serial   = getNextVendorSerial(existingNumbers, payload.vendorName, settings.PO_PREFIX);
  const poNumber = generatePoNumber(payload.vendorName, serial, settings.PO_PREFIX);
  const poId     = crypto.randomUUID();

  const mainRow  = await buildMainRow(payload, poId, poNumber, 'Generated');
  const itemRows = buildItemRows(payload, poId, poNumber);

  await appendSheetRow(MAIN_SHEET, mainRow);
  await appendSheetRows(ITEMS_SHEET, itemRows);

  const purchaseOrder: PurchaseOrderMain = {
    poId,
    poNumber,
    vendorName:           payload.vendorName,
    poDate:               payload.poDate,
    deliveryDate:         payload.deliveryDate        || '',
    projectReference:     payload.projectReference,
    deliveryAddress:      payload.deliveryAddress,
    preparedBy:           payload.preparedBy,
    telephone:            payload.telephone           || '',
    deliveryInstructions: payload.deliveryInstructions || '',
    itemCategory:         payload.itemCategory        || '',
    itemsCount:           payload.items.length,
    totalAmount:          Number(mainRow.Total_Amount),
    amountInWords:        mainRow.Amount_In_Words,
    pdfLink:              '',
    driveFileId:          '',
    status:               'Generated',
    createdAt:            mainRow.Created_At,
    updatedAt:            mainRow.Updated_At,
    archived:             false,
  };

  const pdfBuffer = await generatePOPDF(purchaseOrder, itemRows.map(toItemRecord), settings);
  const fileName  = `${poNumber}.pdf`;
  const uploaded  = await uploadPDFToDrive(pdfBuffer, fileName);
  const pdfLink   = getDriveFileLink(uploaded.id);

  await updateSheetRow(MAIN_SHEET, 'PO_ID', poId, {
    PDF_Link:      pdfLink,
    Drive_File_ID: uploaded.id,
    Status:        'Generated',
    Updated_At:    new Date().toISOString(),
  });

  await appendActivityLog({
    Log_ID:    crypto.randomUUID(),
    Time:      new Date().toISOString(),
    Action:    'PO generated',
    PO_Number: poNumber,
    User:      'System',
    Status:    'Generated',
    Details:   `PO created, PDF uploaded. Vendor: ${payload.vendorName}`,
  });

  return { poId, poNumber, status: 'Generated', pdfLink, driveFileId: uploaded.id };
}

export async function updatePurchaseOrder(poId: string, payload: PurchaseOrderPayload) {
  validatePurchaseOrderPayload(payload);
  const existing = await getPurchaseOrderById(poId);
  if (!existing) throw new Error(`Purchase order ${poId} not found.`);

  const settings  = await buildSettings();
  const poNumber  = existing.main.poNumber;
  const mainRow   = await buildMainRow(payload, poId, poNumber, 'Updated');
  mainRow.Created_At    = existing.main.createdAt;
  mainRow.Updated_At    = new Date().toISOString();
  mainRow.PDF_Link      = existing.main.pdfLink      || '';
  mainRow.Drive_File_ID = existing.main.driveFileId  || '';

  await updateSheetRow(MAIN_SHEET, 'PO_ID', poId, mainRow);

  const prevItems = await findRowsByField(ITEMS_SHEET, 'PO_ID', poId);
  for (const row of prevItems) {
    await updateSheetRow(ITEMS_SHEET, 'Item_ID', String(row.values.Item_ID), {
      ...row.values, Archived: 'TRUE',
    });
  }

  const newRows = buildItemRows(payload, poId, poNumber);
  await appendSheetRows(ITEMS_SHEET, newRows);

  const purchaseOrder: PurchaseOrderMain = {
    poId, poNumber,
    vendorName:           payload.vendorName,
    poDate:               payload.poDate,
    deliveryDate:         payload.deliveryDate        || '',
    projectReference:     payload.projectReference,
    deliveryAddress:      payload.deliveryAddress,
    preparedBy:           payload.preparedBy,
    telephone:            payload.telephone           || '',
    deliveryInstructions: payload.deliveryInstructions || '',
    itemCategory:         payload.itemCategory        || '',
    itemsCount:           payload.items.length,
    totalAmount:          Number(mainRow.Total_Amount),
    amountInWords:        mainRow.Amount_In_Words,
    pdfLink:              existing.main.pdfLink    || '',
    driveFileId:          existing.main.driveFileId || '',
    status:               'Updated',
    createdAt:            mainRow.Created_At,
    updatedAt:            mainRow.Updated_At,
    archived:             existing.main.archived,
  };

  const pdfBuffer = await generatePOPDF(purchaseOrder, newRows.map(toItemRecord), settings);
  const fileName  = `${poNumber}.pdf`;
  const uploaded  = existing.main.driveFileId
    ? await updateDriveFile(existing.main.driveFileId, pdfBuffer)
    : await uploadPDFToDrive(pdfBuffer, fileName);
  const pdfLink   = getDriveFileLink(uploaded.id);

  await updateSheetRow(MAIN_SHEET, 'PO_ID', poId, {
    PDF_Link: pdfLink, Drive_File_ID: uploaded.id, Status: 'Updated', Updated_At: new Date().toISOString(),
  });

  await appendActivityLog({
    Log_ID: crypto.randomUUID(), Time: new Date().toISOString(),
    Action: 'PO updated', PO_Number: poNumber, User: 'System', Status: 'Updated',
    Details: 'PO edited and PDF regenerated.',
  });

  return { poId, poNumber, status: 'Updated', pdfLink, driveFileId: uploaded.id };
}

export async function regeneratePurchaseOrderPDF(poId: string) {
  const existing = await getPurchaseOrderById(poId);
  if (!existing) throw new Error(`Purchase order ${poId} not found.`);

  const settings  = await buildSettings();
  const pdfBuffer = await generatePOPDF(existing.main, existing.items, settings);
  const fileName  = `${existing.main.poNumber}.pdf`;
  const uploaded  = existing.main.driveFileId
    ? await updateDriveFile(existing.main.driveFileId, pdfBuffer)
    : await uploadPDFToDrive(pdfBuffer, fileName);
  const pdfLink   = getDriveFileLink(uploaded.id);

  await updateSheetRow(MAIN_SHEET, 'PO_ID', poId, {
    PDF_Link: pdfLink, Drive_File_ID: uploaded.id, Status: 'PDF Regenerated', Updated_At: new Date().toISOString(),
  });

  await appendActivityLog({
    Log_ID: crypto.randomUUID(), Time: new Date().toISOString(),
    Action: 'PDF regenerated', PO_Number: existing.main.poNumber, User: 'System', Status: 'Generated',
    Details: 'PDF regenerated on Drive.',
  });

  return { poId, poNumber: existing.main.poNumber, pdfLink, driveFileId: uploaded.id };
}

export async function archivePurchaseOrder(poId: string) {
  const existing = await getPurchaseOrderById(poId);
  if (!existing) throw new Error(`Purchase order ${poId} not found.`);

  await updateSheetRow(MAIN_SHEET, 'PO_ID', poId, {
    Archived: 'TRUE', Status: 'Archived', Updated_At: new Date().toISOString(),
  });

  await appendActivityLog({
    Log_ID: crypto.randomUUID(), Time: new Date().toISOString(),
    Action: 'PO archived', PO_Number: existing.main.poNumber, User: 'System', Status: 'Archived',
    Details: 'Purchase order archived.',
  });

  return { poId, poNumber: existing.main.poNumber };
}

export async function deletePurchaseOrder(poId: string) {
  const existing = await getPurchaseOrderById(poId);
  if (!existing) throw new Error(`Purchase order ${poId} not found.`);

  const sheets = await getSheetsClient();
  const meta   = await sheets.spreadsheets.get({
    spreadsheetId: GOOGLE_SPREADSHEET_ID,
    fields:        'sheets(properties(title,sheetId))',
  });
  const sheetIdMap: Record<string, number> = {};
  for (const s of meta.data.sheets || []) {
    if (s.properties?.title != null) sheetIdMap[s.properties.title] = s.properties.sheetId!;
  }

  const itemRowsData      = await findRowsByField(ITEMS_SHEET, 'PO_ID', poId);
  const { rows: mainAll } = await getSheetRows(MAIN_SHEET);
  const mainTarget        = mainAll.find((r) => r.values.PO_ID === poId);

  const requests: any[] = [];
  const itemIndices = itemRowsData.map((r) => r.rowIndex - 1).sort((a, b) => b - a);
  for (const idx of itemIndices) {
    requests.push({ deleteDimension: { range: { sheetId: sheetIdMap[ITEMS_SHEET], dimension: 'ROWS', startIndex: idx, endIndex: idx + 1 } } });
  }
  if (mainTarget) {
    requests.push({ deleteDimension: { range: { sheetId: sheetIdMap[MAIN_SHEET], dimension: 'ROWS', startIndex: mainTarget.rowIndex - 1, endIndex: mainTarget.rowIndex } } });
  }

  if (requests.length > 0) {
    await sheets.spreadsheets.batchUpdate({ spreadsheetId: GOOGLE_SPREADSHEET_ID, requestBody: { requests } });
  }

  await appendActivityLog({
    Log_ID: crypto.randomUUID(), Time: new Date().toISOString(),
    Action: 'PO deleted', PO_Number: existing.main.poNumber, User: 'System', Status: 'Deleted',
    Details: `PO ${existing.main.poNumber} permanently deleted.`,
  });

  return { poId, poNumber: existing.main.poNumber };
}
