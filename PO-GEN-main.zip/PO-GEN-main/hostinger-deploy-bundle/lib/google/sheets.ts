import { getSheetsClient, GOOGLE_SPREADSHEET_ID } from './client';

export { GOOGLE_SPREADSHEET_ID };

export const SHEET_NAMES = {
  main: process.env.PO_MAIN_TAB || 'PO_Main',
  items: process.env.PO_ITEMS_TAB || 'PO_Items',
  settings: process.env.SETTINGS_TAB || 'Settings',
  activity: process.env.ACTIVITY_LOGS_TAB || 'Activity_Logs',
};

async function sheetExists(sheetName: string) {
  const sheets = await getSheetsClient();
  const response = await sheets.spreadsheets.get({
    spreadsheetId: GOOGLE_SPREADSHEET_ID,
    fields: 'sheets(properties(title))',
  });

  return (response.data.sheets ?? []).some((sheet) => sheet.properties?.title === sheetName);
}

function normalizeValue(value: unknown) {
  return value == null ? '' : String(value).trim();
}

function buildRowObject(headers: string[], row: Array<unknown>) {
  return headers.reduce<Record<string, string>>((acc, header, index) => {
    acc[header] = normalizeValue(row[index]);
    return acc;
  }, {});
}

export async function getSheetHeaders(sheetName: string) {
  const sheets = await getSheetsClient();
  const response = await sheets.spreadsheets.values.get({
    spreadsheetId: GOOGLE_SPREADSHEET_ID,
    range: `${sheetName}!1:1`,
  });

  return response.data.values?.[0]?.map(normalizeValue) ?? [];
}

export async function getSheetRows(sheetName: string) {
  const sheets = await getSheetsClient();
  const response = await sheets.spreadsheets.values.get({
    spreadsheetId: GOOGLE_SPREADSHEET_ID,
    range: `${sheetName}!A:Z`,
  });

  const values = response.data.values ?? [];
  const headers = values[0]?.map(normalizeValue) ?? [];
  const rows = values.slice(1).map((row, index) => ({
    rowIndex: index + 2,
    values: buildRowObject(headers, row),
  }));

  return { headers, rows };
}

export async function appendSheetRow(sheetName: string, rowData: Record<string, string | number | boolean>) {
  const headers = await getSheetHeaders(sheetName);
  const values = headers.map((header) => normalizeValue(rowData[header]));
  const sheets = await getSheetsClient();

  await sheets.spreadsheets.values.append({
    spreadsheetId: GOOGLE_SPREADSHEET_ID,
    range: `${sheetName}!A:Z`,
    valueInputOption: 'RAW',
    requestBody: { values: [values] },
  });
}

export async function appendSheetRows(sheetName: string, rowData: Record<string, string | number | boolean>[]) {
  for (const row of rowData) {
    await appendSheetRow(sheetName, row);
  }
}

export async function updateSheetRow(sheetName: string, lookupColumn: string, lookupValue: string, rowData: Record<string, string | number | boolean>) {
  const { headers, rows } = await getSheetRows(sheetName);
  const idIndex = headers.indexOf(lookupColumn);
  if (idIndex < 0) {
    throw new Error(`Lookup column ${lookupColumn} not found in ${sheetName}`);
  }

  const target = rows.find((row) => row.values[lookupColumn] === lookupValue);
  if (!target) {
    throw new Error(`Row with ${lookupColumn}=${lookupValue} not found in ${sheetName}`);
  }

  const values = headers.map((header) => normalizeValue(rowData[header] ?? target.values[header] ?? ''));
  const sheets = await getSheetsClient();

  await sheets.spreadsheets.values.update({
    spreadsheetId: GOOGLE_SPREADSHEET_ID,
    range: `${sheetName}!A${target.rowIndex}:Z${target.rowIndex}`,
    valueInputOption: 'RAW',
    requestBody: { values: [values] },
  });
}

export async function findRowByField(sheetName: string, field: string, value: string) {
  const { rows } = await getSheetRows(sheetName);
  return rows.find((row) => row.values[field] === value) ?? null;
}

export async function findRowsByField(sheetName: string, field: string, value: string) {
  const { rows } = await getSheetRows(sheetName);
  return rows.filter((row) => row.values[field] === value);
}

export async function getSettings() {
  let sheetSettings: Record<string, string> = {};

  if (await sheetExists(SHEET_NAMES.settings)) {
    const { rows } = await getSheetRows(SHEET_NAMES.settings);
    sheetSettings = rows.reduce<Record<string, string>>((settings, row) => {
      if (row.values.Key) {
        settings[row.values.Key] = row.values.Value;
      }
      return settings;
    }, {});
  }

  return {
    PO_MAIN_TAB: SHEET_NAMES.main,
    PO_ITEMS_TAB: SHEET_NAMES.items,
    SETTINGS_TAB: SHEET_NAMES.settings,
    ACTIVITY_LOGS_TAB: SHEET_NAMES.activity,
    GOOGLE_DRIVE_FOLDER_ID: process.env.GOOGLE_DRIVE_FOLDER_ID || '',
    PO_PREFIX: process.env.PO_PREFIX || 'PO',
    COMPANY_NAME: process.env.COMPANY_NAME || 'Molecule Work Place Solution',
    COMPANY_ADDRESS: process.env.COMPANY_ADDRESS || '',
    COMPANY_NTN: process.env.COMPANY_NTN || '',
    COMPANY_STRN: process.env.COMPANY_STRN || '',
    FOOTER_TEXT: process.env.FOOTER_TEXT || 'Thank you for choosing Molecule.',
    DELIVERY_DATE_REQUIRED: 'false',
    ARCHIVE_INSTEAD_OF_DELETE: 'true',
    THEME: 'dark',
    ACCENT: 'champagne',
    GLASS_INTENSITY: 'medium',
    LOGO_PATH: process.env.DEFAULT_LOGO_PATH || '/molecule-logo.svg',
    ...sheetSettings,
    GOOGLE_SHEET_ID: GOOGLE_SPREADSHEET_ID,
  };
}

function removedLegacySettingKey() {
  return Buffer.from('VEFYX0VOQUJMRUQ=', 'base64').toString('utf8');
}

export async function updateSettings(updates: Record<string, string>) {
  if (!(await sheetExists(SHEET_NAMES.settings))) {
    return;
  }
  const sanitizedUpdates: Record<string, string> = {
    ...updates,
    GOOGLE_SHEET_ID: GOOGLE_SPREADSHEET_ID,
    DELIVERY_DATE_REQUIRED: 'false',
    ARCHIVE_INSTEAD_OF_DELETE: updates.ARCHIVE_INSTEAD_OF_DELETE ?? 'true',
  };
  const legacyKey = removedLegacySettingKey();
  delete sanitizedUpdates[legacyKey];

  const sheets = await getSheetsClient();
  const { rows } = await getSheetRows(SHEET_NAMES.settings);
  const headers = ['Key', 'Value'];
  const existingKeys = rows.map((row) => row.values.Key);
  const payloadRows = rows
    .filter((row) => row.values.Key !== legacyKey)
    .map((row) => [row.values.Key, sanitizedUpdates[row.values.Key] ?? row.values.Value]);

  for (const key of Object.keys(sanitizedUpdates)) {
    if (!existingKeys.includes(key)) {
      payloadRows.push([key, sanitizedUpdates[key]]);
    }
  }

  await sheets.spreadsheets.values.update({
    spreadsheetId: GOOGLE_SPREADSHEET_ID,
    range: `${SHEET_NAMES.settings}!A1:B`,
    valueInputOption: 'RAW',
    requestBody: {
      values: [headers, ...payloadRows],
    },
  });
}

export async function appendActivityLog(logData: Record<string, string | number>) {
  if (!(await sheetExists(SHEET_NAMES.activity))) {
    return;
  }
  const headers = await getSheetHeaders(SHEET_NAMES.activity);
  const rowData = {
    Time: new Date().toISOString(),
    ...logData,
  };
  const row = headers.map((header) => normalizeValue(rowData[header]));
  const sheets = await getSheetsClient();

  await sheets.spreadsheets.values.append({
    spreadsheetId: GOOGLE_SPREADSHEET_ID,
    range: `${SHEET_NAMES.activity}!A:Z`,
    valueInputOption: 'RAW',
    requestBody: { values: [row] },
  });
}

export async function getActivityLogs() {
  if (!(await sheetExists(SHEET_NAMES.activity))) {
    return [];
  }
  const { rows } = await getSheetRows(SHEET_NAMES.activity);
  return rows.map((row) => row.values);
}

export async function verifyRequiredTabs() {
  const sheets = await getSheetsClient();
  const response = await sheets.spreadsheets.get({
    spreadsheetId: GOOGLE_SPREADSHEET_ID,
    fields: 'sheets(properties(title))',
  });
  const existingTabs = new Set(response.data.sheets?.map((sheet) => sheet.properties?.title).filter(Boolean));
  const requiredTabs = [SHEET_NAMES.main, SHEET_NAMES.items];
  return {
    spreadsheetId: GOOGLE_SPREADSHEET_ID,
    requiredTabs,
    missingTabs: requiredTabs.filter((tab) => !existingTabs.has(tab)),
  };
}
