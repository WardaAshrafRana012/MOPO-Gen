import { Readable } from 'stream';
import { getDriveClient, GOOGLE_DRIVE_FOLDER_ID } from './client';

/** Convert any buffer-like value to a Node.js Readable stream (required by googleapis v100+) */
function toReadable(buffer: Uint8Array | ArrayBuffer | Buffer): Readable {
  const buf = buffer instanceof Buffer ? buffer : Buffer.from(buffer as ArrayBuffer);
  return Readable.from(buf);
}

export async function uploadPDFToDrive(buffer: Uint8Array | ArrayBuffer, fileName: string) {
  const drive    = await getDriveClient();
  const response = await drive.files.create({
    requestBody: {
      name:     fileName,
      parents:  [GOOGLE_DRIVE_FOLDER_ID],
      mimeType: 'application/pdf',
    },
    media: {
      mimeType: 'application/pdf',
      body:     toReadable(buffer),
    },
    fields: 'id, webViewLink',
  });

  return {
    id:          response.data.id          || '',
    webViewLink: response.data.webViewLink || '',
  };
}

export async function updateDriveFile(fileId: string, buffer: Uint8Array | ArrayBuffer) {
  const drive    = await getDriveClient();
  const response = await drive.files.update({
    fileId,
    media: {
      mimeType: 'application/pdf',
      body:     toReadable(buffer),
    },
    fields: 'id, webViewLink',
  });

  return {
    id:          response.data.id          || fileId,
    webViewLink: response.data.webViewLink || '',
  };
}

export function getDriveFileLink(fileId: string) {
  return `https://drive.google.com/file/d/${fileId}/view`;
}
