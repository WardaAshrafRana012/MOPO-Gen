import { google } from 'googleapis';
import fs from 'fs';
import path from 'path';

const privateKey = process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, '\n');
const clientEmail = process.env.GOOGLE_CLIENT_EMAIL || process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
const projectId = process.env.GOOGLE_PROJECT_ID;

export const GOOGLE_SPREADSHEET_ID = process.env.GOOGLE_SHEET_ID || '';
export const GOOGLE_DRIVE_FOLDER_ID = process.env.GOOGLE_DRIVE_FOLDER_ID || '';

const OAUTH_CLIENT_ID = process.env.GOOGLE_OAUTH_CLIENT_ID;
const OAUTH_CLIENT_SECRET = process.env.GOOGLE_OAUTH_CLIENT_SECRET;
const OAUTH_REDIRECT_URI = process.env.GOOGLE_OAUTH_REDIRECT_URI;
const OAUTH_TOKEN_PATH = process.env.GOOGLE_OAUTH_TOKEN_PATH || '.local/google-oauth-tokens.json';

async function getAuth() {
  // Prefer service account (JWT) if credentials are present
  if (clientEmail && privateKey && GOOGLE_SPREADSHEET_ID && GOOGLE_DRIVE_FOLDER_ID) {
    return new google.auth.JWT({
      email: clientEmail,
      key: privateKey,
      scopes: ['https://www.googleapis.com/auth/spreadsheets', 'https://www.googleapis.com/auth/drive.file'],
      projectId,
    });
  }

  // Fallback to OAuth2 if OAuth client is configured
  if (OAUTH_CLIENT_ID && OAUTH_CLIENT_SECRET && OAUTH_REDIRECT_URI) {
    const oauth2Client = new google.auth.OAuth2(OAUTH_CLIENT_ID, OAUTH_CLIENT_SECRET, OAUTH_REDIRECT_URI);
    const tokenFullPath = path.resolve(process.cwd(), OAUTH_TOKEN_PATH);
    if (!fs.existsSync(tokenFullPath)) {
      throw new Error(`OAuth token file not found at ${tokenFullPath}. Visit /oauth/start to authorize.`);
    }

    const raw = fs.readFileSync(tokenFullPath, 'utf8');
    const tokens = JSON.parse(raw);
    oauth2Client.setCredentials(tokens);
    return oauth2Client;
  }

  throw new Error('Missing required Google API environment variables. Please set either service-account vars (GOOGLE_CLIENT_EMAIL/GOOGLE_PRIVATE_KEY/GOOGLE_SHEET_ID/GOOGLE_DRIVE_FOLDER_ID) or OAuth vars (GOOGLE_OAUTH_CLIENT_ID/GOOGLE_OAUTH_CLIENT_SECRET/GOOGLE_OAUTH_REDIRECT_URI).');
}

export async function getSheetsClient() {
  const auth = await getAuth();
  if (typeof (auth as any).authorize === 'function') {
    await (auth as any).authorize();
  }
  return google.sheets({ version: 'v4', auth });
}

export async function getDriveClient() {
  const auth = await getAuth();
  if (typeof (auth as any).authorize === 'function') {
    await (auth as any).authorize();
  }
  return google.drive({ version: 'v3', auth });
}
