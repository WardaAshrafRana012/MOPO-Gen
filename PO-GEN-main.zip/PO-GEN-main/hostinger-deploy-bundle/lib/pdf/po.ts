import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import type { RGB } from 'pdf-lib';
import type { PurchaseOrderItem, PurchaseOrderMain } from '@/types/po';

const C_BLACK = rgb(0.04, 0.04, 0.04);
const C_DARK = rgb(0.1, 0.1, 0.1);
const C_MID = rgb(0.28, 0.28, 0.28);
const C_LGREY = rgb(0.75, 0.75, 0.75);
const C_BGCELL = rgb(0.95, 0.95, 0.95);
const C_WHITE = rgb(1, 1, 1);

type Page = ReturnType<PDFDocument['addPage']>;
type Font = Awaited<ReturnType<PDFDocument['embedFont']>>;

function drawRight(page: Page, text: string, rx: number, y: number, size: number, font: Font, color: RGB) {
  page.drawText(text, { x: rx - font.widthOfTextAtSize(text, size), y, size, font, color });
}

function box(page: Page, x: number, y: number, w: number, h: number, fill?: RGB, border?: RGB, bw = 0.5) {
  page.drawRectangle({ x, y, width: w, height: h, color: fill, borderColor: border, borderWidth: border ? bw : undefined });
}

function vline(page: Page, x: number, y1: number, y2: number, color: RGB = C_LGREY, t = 0.5) {
  page.drawLine({ start: { x, y: y1 }, end: { x, y: y2 }, thickness: t, color });
}

function numFmt(n: number): string {
  return new Intl.NumberFormat('en-PK', { minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(n);
}

function dateFmt(v?: string): string {
  if (!v) return '-';
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return v;
  return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }).toUpperCase();
}

function wrap(text: string, maxW: number, font: Font, size: number): string[] {
  if (!text.trim()) return [''];
  const words = text.split(' ');
  const lines: string[] = [];
  let cur = '';
  for (const word of words) {
    const candidate = cur ? `${cur} ${word}` : word;
    if (font.widthOfTextAtSize(candidate, size) <= maxW) {
      cur = candidate;
    } else {
      if (cur) lines.push(cur);
      cur = word;
    }
  }
  if (cur) lines.push(cur);
  return lines.length ? lines : [''];
}

function drawWrapped(page: Page, text: string, x: number, y: number, maxW: number, font: Font, size: number, color: RGB, lh?: number): number {
  const step = lh ?? size * 1.45;
  for (const line of wrap(text, maxW, font, size)) {
    page.drawText(line, { x, y, size, font, color });
    y -= step;
  }
  return y;
}

function toWords(amount: number): string {
  const ones = ['', 'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX', 'SEVEN', 'EIGHT', 'NINE', 'TEN', 'ELEVEN', 'TWELVE', 'THIRTEEN', 'FOURTEEN', 'FIFTEEN', 'SIXTEEN', 'SEVENTEEN', 'EIGHTEEN', 'NINETEEN'];
  const tens = ['', '', 'TWENTY', 'THIRTY', 'FORTY', 'FIFTY', 'SIXTY', 'SEVENTY', 'EIGHTY', 'NINETY'];

  function belowOneThousand(n: number): string {
    if (!n) return '';
    if (n < 20) return ones[n];
    if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 ? '-' + ones[n % 10] : '');
    return ones[Math.floor(n / 100)] + ' HUNDRED' + (n % 100 ? ' ' + belowOneThousand(n % 100) : '');
  }

  const n = Math.round(Number(amount) || 0);
  if (!n) return 'ZERO RUPEES ONLY';

  const parts: string[] = [];
  if (Math.floor(n / 10000000)) parts.push(belowOneThousand(Math.floor(n / 10000000)) + ' CRORE');
  if (Math.floor((n % 10000000) / 100000)) parts.push(belowOneThousand(Math.floor((n % 10000000) / 100000)) + ' LAKH');
  if (Math.floor((n % 100000) / 1000)) parts.push(belowOneThousand(Math.floor((n % 100000) / 1000)) + ' THOUSAND');
  if (n % 1000) parts.push(belowOneThousand(n % 1000));
  return parts.join(' ') + ' RUPEES ONLY';
}

function drawMoleculeLogo(page: Page, x: number, y: number, width: number, height: number) {
  const sx = width / 120;
  const sy = height / 120;
  const stroke = 6 * Math.min(sx, sy);
  const line = (x1: number, y1: number, x2: number, y2: number) => {
    page.drawLine({
      start: { x: x + x1 * sx, y: y + y1 * sy },
      end: { x: x + x2 * sx, y: y + y2 * sy },
      thickness: stroke,
      color: C_DARK,
    });
  };

  const points = [
    [60, 110, 78, 96],
    [78, 96, 78, 64],
    [78, 64, 60, 50],
    [60, 50, 42, 64],
    [42, 64, 42, 96],
    [42, 96, 60, 110],
    [42, 96, 24, 92],
    [24, 92, 24, 64],
    [24, 64, 36, 54],
    [78, 96, 96, 92],
    [96, 92, 96, 64],
    [96, 64, 84, 54],
    [42, 64, 24, 52],
    [24, 52, 24, 28],
    [24, 28, 46, 24],
    [46, 24, 60, 10],
    [60, 10, 74, 24],
    [74, 24, 96, 28],
    [96, 28, 96, 52],
    [78, 64, 96, 52],
    [42, 64, 60, 80],
    [60, 80, 78, 64],
    [42, 64, 60, 48],
    [60, 48, 78, 64],
    [42, 32, 60, 48],
    [60, 48, 78, 32],
    [42, 32, 42, 96],
    [78, 32, 78, 96],
    [42, 32, 60, 16],
    [60, 16, 78, 32],
  ];

  points.forEach(([x1, y1, x2, y2]) => line(x1, y1, x2, y2));
}

export async function generatePOPDF(
  po: PurchaseOrderMain,
  items: PurchaseOrderItem[],
  settings: Record<string, string>,
): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([595.28, 841.89]);
  const regular = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const bold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

  const PW = page.getWidth();
  const PH = page.getHeight();
  const ML = 42;
  const MR = 42;
  const MT = 38;
  const UW = PW - ML - MR;

  box(page, 0, 0, PW, PH, C_WHITE);

  const logoWidth = 56;
  const logoHeight = 48;
  const logoX = ML;
  const logoY = PH - MT - logoHeight;
  drawMoleculeLogo(page, logoX, logoY, logoWidth, logoHeight);

  const brandX = logoX + logoWidth + 10;
  const brandTopY = PH - MT - 4;
  page.drawText('Molecule', { x: brandX, y: brandTopY - 12, size: 15.5, font: regular, color: C_BLACK });
  for (const [index, word] of ['WORK', 'PLACE', 'SOLUTION'].entries()) {
    page.drawText(word, { x: brandX + 2, y: brandTopY - 26 - index * 8, size: 5.5, font: regular, color: rgb(0.45, 0.45, 0.45) });
  }

  const rightEdge = PW - MR;
  const infoTopY = PH - MT - 8;
  const infoLineHeight = 14;
  const infoRows: [string, boolean][] = [
    [`VENDOR NAME: ${(po.vendorName || '').toUpperCase()}`, true],
    [`PO NUMBER: ${po.poNumber || ''}`, true],
    [`PO DATE: ${dateFmt(po.poDate)}`, false],
    [`PROJECT REFERENCE: ${po.projectReference || '-'}`, false],
    ...(po.deliveryDate ? [[`DELIVERY DATE: ${dateFmt(po.deliveryDate)}`, false] as [string, boolean]] : []),
  ];
  infoRows.forEach(([text, isBold], index) => {
    drawRight(page, text, rightEdge, infoTopY - index * infoLineHeight, 8.5, isBold ? bold : regular, C_DARK);
  });

  const headingY = PH - MT - 72;
  page.drawText('PURCHASE ORDER', { x: ML, y: headingY, size: 28, font: bold, color: C_BLACK });

  const companyName = (settings.COMPANY_NAME || 'Molecule Work Place Solution').toUpperCase();
  const companyAddr = (settings.COMPANY_ADDRESS || '47-B, Main Kh-e-Shamsheer, DHA-5, Karachi').toUpperCase();
  const ntn = settings.COMPANY_NTN || '8660135-2';
  const strn = settings.COMPANY_STRN || '32-77-8762-10932';

  let addrY = headingY - 18;
  addrY = drawWrapped(page, `${companyName}, ${companyAddr}`, ML, addrY, UW * 0.54, bold, 7.5, C_DARK, 11);
  page.drawText(`NTN# ${ntn}`, { x: ML, y: addrY - 2, size: 7.5, font: regular, color: C_DARK });
  page.drawText(`STRN# ${strn}`, { x: ML, y: addrY - 13, size: 7.5, font: regular, color: C_DARK });

  const tableTop = addrY - 34;
  const tableLeft = ML;
  const tableRight = PW - MR;
  const tableWidth = UW;
  const headerHeight = 30;

  const col1X = tableLeft + tableWidth * 0.5;
  const col2X = tableLeft + tableWidth * 0.615;
  const col3X = tableLeft + tableWidth * 0.76;
  const col4X = tableLeft + tableWidth * 0.878;

  const col1W = col2X - col1X;
  const col2W = col3X - col2X;
  const col3W = col4X - col3X;
  const col4W = tableRight - col4X;

  box(page, tableLeft, tableTop - headerHeight, tableWidth, headerHeight, C_BGCELL, C_LGREY, 0.6);
  vline(page, col1X, tableTop, tableTop - headerHeight);
  vline(page, col2X, tableTop, tableTop - headerHeight);
  vline(page, col3X, tableTop, tableTop - headerHeight);
  vline(page, col4X, tableTop, tableTop - headerHeight);

  page.drawText('Brief Detail of Major Type Of Item / Service', {
    x: tableLeft + 8,
    y: tableTop - headerHeight / 2 - 3,
    size: 8,
    font: bold,
    color: C_DARK,
    maxWidth: col1X - tableLeft - 12,
  });

  function centerHeader(text: string, colX: number, colW: number) {
    page.drawText(text, {
      x: colX + (colW - bold.widthOfTextAtSize(text, 8)) / 2,
      y: tableTop - headerHeight / 2 - 3,
      size: 8,
      font: bold,
      color: C_DARK,
    });
  }

  centerHeader('Qty', col1X, col1W);
  centerHeader('Qty Type', col2X, col2W);
  centerHeader('Unit Price', col3X, col3W);
  page.drawText('Amount', { x: col4X + (col4W - bold.widthOfTextAtSize('Amount', 8)) / 2, y: tableTop - 11, size: 8, font: bold, color: C_DARK });
  page.drawText('PKR', { x: col4X + (col4W - bold.widthOfTextAtSize('PKR', 8)) / 2, y: tableTop - 21, size: 8, font: bold, color: C_DARK });

  const minRowHeight = 24;
  let curY = tableTop - headerHeight;

  for (const item of items) {
    const descLines = wrap(item.description || '', col1X - tableLeft - 14, regular, 9);
    const categoryLines = item.category?.trim() ? [`Category: ${item.category}`] : [];
    const poTypeLines = item.poType?.trim() ? [`(${item.poType})`] : [];
    const allDescLines = [...descLines, ...categoryLines, ...poTypeLines];
    const rowHeight = Math.max(minRowHeight, allDescLines.length * 13 + 10);

    box(page, tableLeft, curY - rowHeight, tableWidth, rowHeight, undefined, C_LGREY, 0.5);
    vline(page, col1X, curY, curY - rowHeight);
    vline(page, col2X, curY, curY - rowHeight);
    vline(page, col3X, curY, curY - rowHeight);
    vline(page, col4X, curY, curY - rowHeight);

    let descY = curY - 11;
    for (const line of descLines) {
      page.drawText(line, { x: tableLeft + 8, y: descY, size: 9, font: regular, color: C_DARK });
      descY -= 13;
    }
    for (const line of categoryLines) {
      page.drawText(line, { x: tableLeft + 8, y: descY, size: 7.5, font: regular, color: C_MID });
      descY -= 11;
    }
    for (const line of poTypeLines) {
      page.drawText(line, { x: tableLeft + 8, y: descY, size: 7.5, font: regular, color: C_MID });
      descY -= 11;
    }

    const midY = curY - rowHeight / 2 - 3.5;
    const qtyText = numFmt(item.quantity);
    page.drawText(qtyText, { x: col1X + (col1W - regular.widthOfTextAtSize(qtyText, 9)) / 2, y: midY, size: 9, font: regular, color: C_DARK });

    const qtyTypeText = item.quantityType || '';
    if (qtyTypeText) {
      page.drawText(qtyTypeText, { x: col2X + (col2W - regular.widthOfTextAtSize(qtyTypeText, 9)) / 2, y: midY, size: 9, font: regular, color: C_DARK });
    }

    drawRight(page, numFmt(item.unitPrice), col4X - 6, midY, 9, regular, C_DARK);
    drawRight(page, numFmt(item.amount), tableRight - 6, midY, 9, regular, C_DARK);
    curY -= rowHeight;
  }

  const totalHeight = 28;
  box(page, tableLeft, curY - totalHeight, tableWidth, totalHeight, C_BGCELL, C_LGREY, 0.6);
  vline(page, col3X, curY, curY - totalHeight);
  vline(page, col4X, curY, curY - totalHeight);

  const words = toWords(po.totalAmount);
  page.drawText(words, { x: tableLeft + 8, y: curY - totalHeight / 2 - 3.5, size: 8.5, font: bold, color: C_DARK, maxWidth: col3X - tableLeft - 14 });

  const totalLabel = 'TOTAL';
  page.drawText(totalLabel, {
    x: col3X + (col4X - col3X - bold.widthOfTextAtSize(totalLabel, 9.5)) / 2,
    y: curY - totalHeight / 2 - 3.5,
    size: 9.5,
    font: bold,
    color: C_DARK,
  });
  drawRight(page, numFmt(po.totalAmount), tableRight - 6, curY - totalHeight / 2 - 3.5, 9.5, bold, C_DARK);

  const tableBottom = curY - totalHeight;
  box(page, tableLeft, tableBottom, tableWidth, tableTop - tableBottom, undefined, C_LGREY, 0.8);

  const deliveryTop = tableBottom - 28;
  page.drawText('DELIVERY DETAILS', { x: ML, y: deliveryTop, size: 14, font: bold, color: C_BLACK });

  const deliveryBoxTop = deliveryTop - 16;
  const deliveryMid = ML + UW * 0.54;
  const leftPad = ML + 10;
  const leftWidth = deliveryMid - ML - 16;
  const rightPad = deliveryMid + 10;
  const rightWidth = ML + UW - deliveryMid - 10;

  const leftRows = [
    ...wrap(`DELIVERY ADDRESS : ${po.deliveryAddress || ''}`, leftWidth, bold, 8),
    `PREPARED BY : ${po.preparedBy || ''}`,
    ...(po.telephone?.trim() ? [`TELEPHONE : ${po.telephone}`] : []),
  ];

  const rightBlocks = [
    ...(po.deliveryInstructions?.trim() ? [{ label: 'DELIVERY INSTRUCTIONS', lines: wrap(po.deliveryInstructions, rightWidth, regular, 8), bodyFont: regular, bodyColor: C_MID }] : []),
    ...(po.deliveryDate ? [{ label: 'DELIVERY DATE', lines: [dateFmt(po.deliveryDate)], bodyFont: bold, bodyColor: C_DARK }] : []),
  ];

  const leftHeight = leftRows.length * 12 + 16;
  const rightHeight = rightBlocks.reduce((sum, block) => sum + 13 + block.lines.length * 11 + 6, 16);
  const deliveryHeight = Math.max(52, leftHeight, rightHeight);

  box(page, ML, deliveryBoxTop - deliveryHeight, UW, deliveryHeight, undefined, C_LGREY, 0.6);
  vline(page, deliveryMid, deliveryBoxTop, deliveryBoxTop - deliveryHeight);

  let leftY = deliveryBoxTop - 14;
  leftRows.forEach((line) => {
    page.drawText(line, { x: leftPad, y: leftY, size: 8, font: bold, color: C_DARK });
    leftY -= 12;
  });

  let rightY = deliveryBoxTop - 14;
  rightBlocks.forEach((block) => {
    page.drawText(block.label, { x: rightPad, y: rightY, size: 8, font: bold, color: C_DARK });
    rightY -= 13;
    block.lines.forEach((line) => {
      page.drawText(line, { x: rightPad, y: rightY, size: 8, font: block.bodyFont, color: block.bodyColor });
      rightY -= 11;
    });
    rightY -= 6;
  });


  return pdfDoc.save();
}
