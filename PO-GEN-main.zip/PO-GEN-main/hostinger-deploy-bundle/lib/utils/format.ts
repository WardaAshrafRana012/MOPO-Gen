import numberToWords from 'number-to-words';

export function formatCurrency(value: number | string) {
  const amount = Number(value) || 0;
  return new Intl.NumberFormat('en-PK', {
    style: 'currency',
    currency: 'PKR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function formatDate(value?: string) {
  if (!value) return '-';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function formatAmountInWords(amount: number) {
  const numeric = Number(amount) || 0;
  const whole = Math.floor(numeric);
  const cents = Math.round((numeric - whole) * 100);
  const words = numberToWords.toWords(whole) || 'zero';
  const formatted = `${words.charAt(0).toUpperCase() + words.slice(1)} Pakistani Rupees`;
  return cents > 0 ? `${formatted} and ${cents}/100` : formatted;
}

export function createVendorCode(vendorName: string): string {
  // Strategy: if name has 3+ words, use first letter of each of first 3 words (initials)
  // Otherwise use first 3 letters of the name
  const words = vendorName.trim().split(/\s+/).filter(Boolean);
  let code: string;
  if (words.length >= 3) {
    code = words.slice(0, 3).map((w) => w[0]).join('').toUpperCase();
  } else {
    code = vendorName.replace(/[^a-zA-Z]/g, '').slice(0, 3).toUpperCase();
  }
  return code.padEnd(3, 'X').slice(0, 3);
}

// Kept as alias for backwards compat
export const createVendorInitials = createVendorCode;

export function parseSerialFromPoNumber(poNumber: string, prefix = 'PO') {
  const match = String(poNumber).match(new RegExp(`^${prefix}-(\\d+)-`));
  return match ? Number(match[1]) : 0;
}

/**
 * Returns the next serial for a given vendor, based on existing PO numbers.
 * Each vendor has its own independent counter (filtered by vendor code).
 */
export function getNextVendorSerial(
  existingPoNumbers: string[],
  vendorName: string,
  prefix = 'PO',
): number {
  const code = createVendorCode(vendorName);
  const suffix = `-${code}`;
  const vendorNos = existingPoNumbers.filter((n) => String(n).endsWith(suffix));
  const max = vendorNos.reduce((cur, n) => Math.max(cur, parseSerialFromPoNumber(n, prefix)), 0);
  return max + 1;
}

/** Legacy global serial (kept for non-vendor-specific use) */
export function getNextPoSerial(existingPoNumbers: string[], prefix = 'PO') {
  const max = existingPoNumbers.reduce((cur, n) => Math.max(cur, parseSerialFromPoNumber(n, prefix)), 0);
  return max + 1;
}

export function generatePoNumber(vendorName: string, serial: number, prefix = 'PO') {
  const serialText = String(serial).padStart(4, '0');
  const code       = createVendorCode(vendorName);
  return `${prefix}-${serialText}-${code}`;
}
