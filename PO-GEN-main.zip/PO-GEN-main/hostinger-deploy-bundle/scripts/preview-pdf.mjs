/**
 * Quick preview script — generates a sample PO PDF to .local/po-preview-new.pdf
 * Run: node scripts/preview-pdf.mjs
 */
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');

// ── Load env ──────────────────────────────────────────────────────────────────
const envLines = fs.readFileSync(path.join(root, '.env'), 'utf8').split('\n');
for (const line of envLines) {
  const t = line.trim();
  if (!t || t.startsWith('#')) continue;
  const eq = t.indexOf('=');
  if (eq < 0) continue;
  const k = t.slice(0, eq).trim();
  const v = t.slice(eq + 1).trim().replace(/^"|"$/g, '');
  if (k && !process.env[k]) process.env[k] = v;
}

// ── Register path alias @/ ────────────────────────────────────────────────────
// We transpile on the fly via a tiny shim using tsx/ts-node — but since this is
// .mjs we'll just inline the transpiled logic by importing the compiled output.
// Instead: call the Next.js API endpoint if server is running.

const url = 'http://localhost:4017/api/po';
console.log('Checking server at', url, '...');

// ── Sample PO data ────────────────────────────────────────────────────────────
const payload = {
  vendorName: 'ANWAR TRUCK',
  poDate: '2026-05-02',
  deliveryDate: '2026-05-04',
  reference: 'HUBCO Thal Nova',
  deliveryAddress: 'Molecule 47-B, Main Kh-e-Shamsheer, DHA-5, Karachi',
  preparedBy: 'Arsalan',
  telephone: '021-3567890',
  deliveryInstructions: '',
  itemCategory: 'Logistics',
  saveDraft: true,
  items: [
    { description: 'Furniture Delivery', quantity: 1, unitPrice: 84000 },
  ],
};

console.log('\nPosting sample PO (draft) to create a test record...');
const res = await fetch(url, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(payload),
});
const json = await res.json();
console.log('Response:', JSON.stringify(json, null, 2));

if (json.error) {
  console.error('\n❌ Error:', json.error);
  console.log('\nNOTE: Make sure the Google Sheet tabs are set up first.');
  console.log('Run: node scripts/setup-sheets.mjs');
} else {
  console.log('\n✅ Draft PO created:', json.data?.poNumber);
  console.log('Now regenerate as PDF via: POST /api/po/[id]/regenerate');
}
