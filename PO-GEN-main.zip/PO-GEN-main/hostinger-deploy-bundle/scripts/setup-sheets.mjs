/**
 * One-time setup script: creates required tabs (PO_Main, PO_Items)
 * in the Google Sheet if they don't already exist, and populates headers.
 *
 * Run with: node scripts/setup-sheets.mjs
 */

import { google } from 'googleapis';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');

// Load .env manually
const envPath = path.join(root, '.env');
const envLines = fs.readFileSync(envPath, 'utf8').split('\n');
for (const line of envLines) {
  const trimmed = line.trim();
  if (!trimmed || trimmed.startsWith('#')) continue;
  const eqIdx = trimmed.indexOf('=');
  if (eqIdx < 0) continue;
  const key = trimmed.slice(0, eqIdx).trim();
  const val = trimmed.slice(eqIdx + 1).trim().replace(/^"|"$/g, '');
  if (key && !process.env[key]) process.env[key] = val;
}

const SPREADSHEET_ID = process.env.GOOGLE_SHEET_ID;
const TOKEN_PATH = path.resolve(root, process.env.GOOGLE_OAUTH_TOKEN_PATH || '.local/google-oauth-tokens.json');

if (!SPREADSHEET_ID) {
  console.error('❌ GOOGLE_SHEET_ID not set in .env');
  process.exit(1);
}

if (!fs.existsSync(TOKEN_PATH)) {
  console.error(`❌ OAuth token not found at ${TOKEN_PATH}. Visit http://localhost:4017/oauth/start to authorize.`);
  process.exit(1);
}

const tokens = JSON.parse(fs.readFileSync(TOKEN_PATH, 'utf8'));
const oauth2 = new google.auth.OAuth2(
  process.env.GOOGLE_OAUTH_CLIENT_ID,
  process.env.GOOGLE_OAUTH_CLIENT_SECRET,
  process.env.GOOGLE_OAUTH_REDIRECT_URI,
);
oauth2.setCredentials(tokens);

const sheets = google.sheets({ version: 'v4', auth: oauth2 });

const TAB_HEADERS = {
  PO_Main: [
    'PO_ID', 'PO_Number', 'Vendor_Name', 'PO_Date', 'Delivery_Date',
    'Reference', 'Delivery_Address', 'Prepared_By', 'Telephone',
    'Delivery_Instructions', 'Item_Category', 'Items_Count', 'Total_Amount',
    'Amount_In_Words', 'PDF_Link', 'Drive_File_ID', 'Status',
    'Created_At', 'Updated_At', 'Archived',
  ],
  PO_Items: [
    'Item_ID', 'PO_ID', 'PO_Number', 'Description', 'Category',
    'Quantity', 'Unit_Price', 'Amount', 'Created_At', 'Updated_At', 'Archived',
  ],
};

const DEFAULT_SETTINGS = [
  ['COMPANY_NAME', 'Molecule Work Place Solution'],
  ['COMPANY_ADDRESS', '47-B, Main Kh-e-Shamsheer, DHA-5, Karachi'],
  ['COMPANY_NTN', '8660135-2'],
  ['COMPANY_STRN', '32-77-8762-10932'],
  ['FOOTER_TEXT', 'Thank you for choosing Molecule.'],
  ['PO_PREFIX', 'PO'],
  ['THEME', 'dark'],
  ['ACCENT', 'champagne'],
  ['GLASS_INTENSITY', 'medium'],
  ['LOGO_PATH', '/molecule-logo.svg'],
  ['DELIVERY_DATE_REQUIRED', 'false'],
  ['ARCHIVE_INSTEAD_OF_DELETE', 'true'],
];

async function main() {
  console.log('🔗 Connecting to spreadsheet:', SPREADSHEET_ID);

  // Get existing tabs
  const meta = await sheets.spreadsheets.get({
    spreadsheetId: SPREADSHEET_ID,
    fields: 'sheets(properties(title,sheetId))',
  });
  const existing = new Map(
    (meta.data.sheets || []).map((s) => [s.properties.title, s.properties.sheetId])
  );
  console.log('📋 Existing tabs:', [...existing.keys()].join(', '));

  const tabsToCreate = Object.keys(TAB_HEADERS).filter((t) => !existing.has(t));

  if (tabsToCreate.length === 0) {
    console.log('✅ All required tabs already exist. Nothing to create.');
  } else {
    console.log('➕ Creating tabs:', tabsToCreate.join(', '));
    const requests = tabsToCreate.map((title) => ({
      addSheet: { properties: { title } },
    }));

    await sheets.spreadsheets.batchUpdate({
      spreadsheetId: SPREADSHEET_ID,
      requestBody: { requests },
    });
    console.log('✅ Tabs created.');
  }

  // Add headers to each tab
  for (const [tabName, headers] of Object.entries(TAB_HEADERS)) {
    // Check if headers already exist
    const rangeRes = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: `${tabName}!1:1`,
    });
    const firstRow = rangeRes.data.values?.[0] ?? [];
    if (firstRow.length > 0) {
      console.log(`⏭  ${tabName}: headers already present, skipping.`);
      continue;
    }

    await sheets.spreadsheets.values.update({
      spreadsheetId: SPREADSHEET_ID,
      range: `${tabName}!A1`,
      valueInputOption: 'RAW',
      requestBody: { values: [headers] },
    });
    console.log(`✅ ${tabName}: headers written.`);

    // Write default settings rows
    if (tabName === 'Settings') {
      await sheets.spreadsheets.values.append({
        spreadsheetId: SPREADSHEET_ID,
        range: `Settings!A:B`,
        valueInputOption: 'RAW',
        requestBody: { values: DEFAULT_SETTINGS },
      });
      console.log('✅ Settings: default values written.');
    }
  }

  console.log('\n🎉 Sheet setup complete! Your MOPO app is ready at http://localhost:4017');
}

main().catch((err) => {
  console.error('❌ Setup failed:', err.message);
  process.exit(1);
});
