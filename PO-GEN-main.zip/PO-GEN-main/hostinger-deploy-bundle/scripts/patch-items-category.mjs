/**
 * Adds 'Category' column to PO_Items tab after 'Description' if not already present.
 * Run: node scripts/patch-items-category.mjs
 */
import path from 'path';
import fs   from 'fs';
import { fileURLToPath } from 'url';
import { google } from 'googleapis';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root      = path.resolve(__dirname, '..');

// Load .env
const envLines  = fs.readFileSync(path.join(root, '.env'), 'utf8').split('\n');
for (const line of envLines) {
  const t = line.trim(); if (!t || t.startsWith('#')) continue;
  const eq = t.indexOf('='); if (eq < 0) continue;
  const k = t.slice(0, eq).trim();
  const v = t.slice(eq + 1).trim().replace(/^"|"$/g, '');
  if (k && !process.env[k]) process.env[k] = v;
}

const SPREADSHEET_ID = process.env.GOOGLE_SHEET_ID;
const TOKEN_PATH     = path.resolve(root, process.env.GOOGLE_OAUTH_TOKEN_PATH || '.local/google-oauth-tokens.json');
const tokens         = JSON.parse(fs.readFileSync(TOKEN_PATH, 'utf8'));
const oauth2         = new google.auth.OAuth2(process.env.GOOGLE_OAUTH_CLIENT_ID, process.env.GOOGLE_OAUTH_CLIENT_SECRET, process.env.GOOGLE_OAUTH_REDIRECT_URI);
oauth2.setCredentials(tokens);
const sheets = google.sheets({ version: 'v4', auth: oauth2 });

const res     = await sheets.spreadsheets.values.get({ spreadsheetId: SPREADSHEET_ID, range: 'PO_Items!1:1' });
const headers = res.data.values?.[0] ?? [];
console.log('Current PO_Items headers:', headers.join(', '));

if (headers.includes('Category')) {
  console.log('✅ Category column already exists. Nothing to do.');
} else {
  // Insert after Description (index 3 = column D, 0-based)
  const descIdx = headers.indexOf('Description');
  const insertAt = descIdx >= 0 ? descIdx + 1 : headers.length;
  const newHeaders = [...headers.slice(0, insertAt), 'Category', ...headers.slice(insertAt)];

  await sheets.spreadsheets.values.update({
    spreadsheetId:   SPREADSHEET_ID,
    range:           'PO_Items!A1',
    valueInputOption:'RAW',
    requestBody:     { values: [newHeaders] },
  });
  console.log('✅ Category column added. New headers:', newHeaders.join(', '));
}
