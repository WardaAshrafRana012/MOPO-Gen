/**
 * Standalone PDF preview — generates .local/po-preview-new.pdf
 * using the exact same logic as lib/pdf/po.ts (copy of the renderer, no TS).
 *
 * Run: node scripts/gen-preview.mjs
 */
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const out  = path.join(root, '.local', 'po-preview-v2.pdf');

// ── Colours ──────────────────────────────────────────────────────────────────
const C_BLACK  = rgb(0.05, 0.05, 0.05);
const C_DARK   = rgb(0.12, 0.12, 0.12);
const C_MID    = rgb(0.25, 0.25, 0.25);
const C_GREY   = rgb(0.45, 0.45, 0.45);
const C_LGREY  = rgb(0.82, 0.82, 0.82);
const C_BGCELL = rgb(0.96, 0.96, 0.96);
const C_WHITE  = rgb(1, 1, 1);

function drawRight(page, text, rightX, y, size, font, color) {
  const w = font.widthOfTextAtSize(text, size);
  page.drawText(text, { x: rightX - w, y, size, font, color });
}

function rect(page, x, y, w, h, fill, borderColor, borderWidth = 0.6) {
  page.drawRectangle({ x, y, width: w, height: h, color: fill, borderColor, borderWidth: borderColor ? borderWidth : undefined });
}

function hLine(page, x1, x2, y, color = C_LGREY, thickness = 0.6) {
  page.drawLine({ start: { x: x1, y }, end: { x: x2, y }, thickness, color });
}

function vLine(page, x, y1, y2, color = C_LGREY, thickness = 0.6) {
  page.drawLine({ start: { x, y: y1 }, end: { x, y: y2 }, thickness, color });
}

function fmtNum(value) {
  return new Intl.NumberFormat('en-PK', { minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(value);
}

function fmtDate(value) {
  if (!value) return '-';
  const d = new Date(value);
  if (isNaN(d.getTime())) return value;
  return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }).toUpperCase();
}

function wrapText(text, maxWidth, font, size) {
  const words = text.split(' ');
  const lines = [];
  let current = '';
  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (font.widthOfTextAtSize(candidate, size) <= maxWidth) {
      current = candidate;
    } else {
      if (current) lines.push(current);
      current = word;
    }
  }
  if (current) lines.push(current);
  return lines;
}

function drawWrapped(page, text, x, y, maxWidth, font, size, color, lineHeight) {
  const lh = lineHeight ?? size * 1.4;
  const lines = wrapText(text, maxWidth, font, size);
  let curY = y;
  for (const line of lines) {
    page.drawText(line, { x, y: curY, size, font, color });
    curY -= lh;
  }
  return curY;
}

function drawLogo(page, cx, cy, size) {
  const s = size / 50;
  const pts = [
    [cx,          cy + 50*s],
    [cx + 43*s,   cy + 25*s],
    [cx + 43*s,   cy - 25*s],
    [cx,          cy - 50*s],
    [cx - 43*s,   cy - 25*s],
    [cx - 43*s,   cy + 25*s],
  ];
  const lw = 1.2;
  const lc = C_DARK;
  for (let i = 0; i < pts.length; i++) {
    const [ax, ay] = pts[i];
    const [bx, by] = pts[(i + 1) % pts.length];
    page.drawLine({ start: { x: ax, y: ay }, end: { x: bx, y: by }, thickness: lw, color: lc });
  }
  page.drawLine({ start: { x: pts[0][0], y: pts[0][1] }, end: { x: pts[3][0], y: pts[3][1] }, thickness: lw, color: lc });
  page.drawLine({ start: { x: pts[1][0], y: pts[1][1] }, end: { x: pts[4][0], y: pts[4][1] }, thickness: lw, color: lc });
  page.drawLine({ start: { x: pts[2][0], y: pts[2][1] }, end: { x: pts[5][0], y: pts[5][1] }, thickness: lw, color: lc });
}

function amountInWords(amount) {
  const ones = ['','ONE','TWO','THREE','FOUR','FIVE','SIX','SEVEN','EIGHT','NINE','TEN','ELEVEN','TWELVE','THIRTEEN','FOURTEEN','FIFTEEN','SIXTEEN','SEVENTEEN','EIGHTEEN','NINETEEN'];
  const tens = ['','','TWENTY','THIRTY','FORTY','FIFTY','SIXTY','SEVENTY','EIGHTY','NINETY'];
  function below1000(n) {
    if (n === 0) return '';
    if (n < 20) return ones[n];
    if (n < 100) return tens[Math.floor(n/10)] + (n%10 ? '-'+ones[n%10] : '');
    return ones[Math.floor(n/100)] + ' HUNDRED' + (n%100 ? ' '+below1000(n%100) : '');
  }
  const n = Math.round(Number(amount) || 0);
  if (n === 0) return 'ZERO RUPEES ONLY';
  const crore    = Math.floor(n/10_000_000);
  const lakh     = Math.floor((n%10_000_000)/100_000);
  const thousand = Math.floor((n%100_000)/1_000);
  const rest     = n%1_000;
  const parts = [];
  if (crore)    parts.push(below1000(crore)    + ' CRORE');
  if (lakh)     parts.push(below1000(lakh)     + ' LAKH');
  if (thousand) parts.push(below1000(thousand) + ' THOUSAND');
  if (rest)     parts.push(below1000(rest));
  return parts.join(' ') + ' RUPEES ONLY';
}

// ── Sample data ───────────────────────────────────────────────────────────────
const po = {
  poId: 'preview-001',
  poNumber: 'PO# 324-ANW',
  vendorName: 'ANWAR TRUCK',
  poDate: '2026-05-02',
  deliveryDate: '2026-05-04',
  reference: 'HUBCO Thal Nova',
  deliveryAddress: 'Molecule 47-B, Main Kh-e-Shamsheer, DHA-5, Karachi',
  preparedBy: 'Arsalan',
  telephone: '021-3567890',
  deliveryInstructions: '',
  itemCategory: 'Logistics',
  itemsCount: 1,
  totalAmount: 84000,
  amountInWords: '',
  pdfLink: '',
  driveFileId: '',
  status: 'Draft',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  archived: false,
};

const items = [
  { itemId: 'i1', poId: 'preview-001', poNumber: 'PO# 324-ANW', description: 'Furniture Delivery', quantity: 1, unitPrice: 84000, amount: 84000, createdAt: '', updatedAt: '' },
];

const settings = {
  COMPANY_NAME:    'Molecule Work Place Solution',
  COMPANY_ADDRESS: '47-B, Main Kh-e-Shamsheer, DHA-5, Karachi',
  COMPANY_NTN:     '8660135-2',
  COMPANY_STRN:    '32-77-8762-10932',
  FOOTER_TEXT:     'Thank you for choosing Molecule.',
};

// ── Generate PDF ──────────────────────────────────────────────────────────────
const pdfDoc = await PDFDocument.create();
const page   = pdfDoc.addPage([595.28, 841.89]);
const regular = await pdfDoc.embedFont(StandardFonts.Helvetica);
const bold    = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

const PW = page.getWidth();
const PH = page.getHeight();
const ML = 45, MR = 45, MT = 45;
const UW = PW - ML - MR;

rect(page, 0, 0, PW, PH, C_WHITE);

// Logo
const logoSize = 22;
const logoCX = ML + logoSize;
const logoCY = PH - MT - logoSize;
drawLogo(page, logoCX, logoCY, logoSize);

// Brand text
const brandX = ML + logoSize * 2 + 6;
page.drawText('Molecule', { x: brandX, y: PH - MT - 10, size: 16, font: regular, color: C_BLACK });
page.drawText('WORK',     { x: brandX + 2, y: PH - MT - 23, size: 5.5, font: regular, color: C_GREY, characterSpacing: 1.5 });
page.drawText('PLACE',    { x: brandX + 2, y: PH - MT - 30, size: 5.5, font: regular, color: C_GREY, characterSpacing: 1.5 });
page.drawText('SOLUTION', { x: brandX + 2, y: PH - MT - 37, size: 5.5, font: regular, color: C_GREY, characterSpacing: 1.5 });

// Right info block
const rightEdge = PW - MR;
const infoTopY  = PH - MT - 8;
const infoLineH = 14;
const infoLines = [
  [`VENDOR NAME: ${po.vendorName.toUpperCase()}`, true],
  [`PO NUMBER: ${po.poNumber}`,                  true],
  [`PO DATE: ${fmtDate(po.poDate)}`,             false],
  [`DELIVERY DATE: ${fmtDate(po.deliveryDate)}`, false],
  [`REFERENCE: ${po.reference || '-'}`,          false],
];
for (let i = 0; i < infoLines.length; i++) {
  const [text, isBold] = infoLines[i];
  drawRight(page, text, rightEdge, infoTopY - i * infoLineH, 8.5, isBold ? bold : regular, C_DARK);
}

// Heading
const headingY = PH - MT - 62;
page.drawText('PURCHASE ORDER', { x: ML, y: headingY, size: 26, font: bold, color: C_BLACK });

// Company info
const companyName    = settings.COMPANY_NAME;
const companyAddress = settings.COMPANY_ADDRESS;
const addrY = headingY - 20;
page.drawText(companyName.toUpperCase() + ', ' + companyAddress.toUpperCase(), {
  x: ML, y: addrY, size: 7.5, font: bold, color: C_DARK, maxWidth: UW * 0.55,
});
page.drawText(`NTN# ${settings.COMPANY_NTN}`,  { x: ML, y: addrY - 12, size: 7.5, font: regular, color: C_DARK });
page.drawText(`STRN# ${settings.COMPANY_STRN}`, { x: ML, y: addrY - 23, size: 7.5, font: regular, color: C_DARK });

// Table
const tblTop  = addrY - 44;
const tblLeft = ML, tblRight = PW - MR, tblW = UW;
const hdrH = 28;
const col1X = tblLeft + tblW * 0.56;
const col2X = tblLeft + tblW * 0.72;
const col3X = tblLeft + tblW * 0.87;

// Header
rect(page, tblLeft, tblTop - hdrH, tblW, hdrH, C_BGCELL, C_LGREY);
vLine(page, col1X, tblTop, tblTop - hdrH);
vLine(page, col2X, tblTop, tblTop - hdrH);
vLine(page, col3X, tblTop, tblTop - hdrH);

page.drawText('Brief Detail of Major Type Of Item / Service', {
  x: tblLeft + 8, y: tblTop - 16, size: 8.5, font: bold, color: C_DARK,
  maxWidth: col1X - tblLeft - 12,
});

const qCW = col2X - col1X, uCW = col3X - col2X, aCW = tblRight - col3X;
page.drawText('Quantity',   { x: col1X + (qCW - bold.widthOfTextAtSize('Quantity',   8.5))/2, y: tblTop - 16, size: 8.5, font: bold, color: C_DARK });
page.drawText('Unit Price', { x: col2X + (uCW - bold.widthOfTextAtSize('Unit Price', 8.5))/2, y: tblTop - 16, size: 8.5, font: bold, color: C_DARK });
page.drawText('Amount',     { x: col3X + (aCW - bold.widthOfTextAtSize('Amount',     8.5))/2, y: tblTop - 11, size: 8.5, font: bold, color: C_DARK });
page.drawText('PKR',        { x: col3X + (aCW - bold.widthOfTextAtSize('PKR',        8.5))/2, y: tblTop - 22, size: 8.5, font: bold, color: C_DARK });

// Rows
let curY = tblTop - hdrH;
const rowH = 24;
const descColW = col1X - tblLeft - 10;

for (const item of items) {
  const descLines = wrapText(item.description, descColW, regular, 9);
  const dynH = Math.max(rowH, descLines.length * 13 + 10);
  rect(page, tblLeft, curY - dynH, tblW, dynH, undefined, C_LGREY);
  vLine(page, col1X, curY, curY - dynH);
  vLine(page, col2X, curY, curY - dynH);
  vLine(page, col3X, curY, curY - dynH);

  const rowTextY = curY - dynH / 2 - 4;
  let lineY = curY - 12;
  for (const line of descLines) {
    page.drawText(line, { x: tblLeft + 8, y: lineY, size: 9, font: regular, color: C_DARK });
    lineY -= 13;
  }
  const qtyStr = fmtNum(item.quantity);
  page.drawText(qtyStr, { x: col1X + (col2X-col1X - regular.widthOfTextAtSize(qtyStr,9))/2, y: rowTextY, size: 9, font: regular, color: C_DARK });
  drawRight(page, fmtNum(item.unitPrice), col3X - 6, rowTextY, 9, regular, C_DARK);
  drawRight(page, fmtNum(item.amount),    tblRight - 6, rowTextY, 9, regular, C_DARK);
  curY -= dynH;
}

// Total row
const totRowH = 26;
rect(page, tblLeft, curY - totRowH, tblW, totRowH, C_BGCELL, C_LGREY);
vLine(page, col2X, curY, curY - totRowH);
vLine(page, col3X, curY, curY - totRowH);
page.drawText(amountInWords(po.totalAmount), {
  x: tblLeft + 8, y: curY - totRowH/2 - 4, size: 8.5, font: bold, color: C_DARK,
  maxWidth: col2X - tblLeft - 14,
});
const tlW = bold.widthOfTextAtSize('TOTAL', 9.5);
page.drawText('TOTAL', { x: col2X + (col3X-col2X-tlW)/2, y: curY - totRowH/2 - 4, size: 9.5, font: bold, color: C_DARK });
drawRight(page, fmtNum(po.totalAmount), tblRight - 6, curY - totRowH/2 - 4, 9.5, bold, C_DARK);
hLine(page, tblLeft, tblRight, curY - totRowH);
rect(page, tblLeft, curY - totRowH, tblW, tblTop - (curY - totRowH), undefined, C_LGREY, 0.8);

// Delivery details
const ddTopY = curY - totRowH - 28;
const ddH    = 110;
const ddW    = UW;
const ddMid  = ML + ddW * 0.55;
page.drawText('DELIVERY DETAILS', { x: ML, y: ddTopY, size: 13, font: bold, color: C_BLACK });

const boxTop = ddTopY - 14;
rect(page, ML, boxTop - ddH, ddW, ddH, undefined, C_LGREY);
vLine(page, ddMid, boxTop, boxTop - ddH);

let lY = boxTop - 16;
lY = drawWrapped(page, `DELIVERY ADDRESS : ${po.deliveryAddress}`, ML + 8, lY, ddMid - ML - 14, bold, 8, C_DARK, 12);
lY -= 6;
page.drawText(`PREPARED BY : ${po.preparedBy}`,   { x: ML + 8, y: lY,      size: 8, font: bold, color: C_DARK });
page.drawText(`TELEPHONE : ${po.telephone || '-'}`, { x: ML + 8, y: lY - 14, size: 8, font: bold, color: C_DARK });

let rY = boxTop - 16;
page.drawText('DELIVERY INSTRUCTIONS', { x: ddMid + 10, y: rY, size: 8, font: bold, color: C_DARK });
rY -= 14;
if (po.deliveryInstructions) {
  rY = drawWrapped(page, po.deliveryInstructions, ddMid + 10, rY, tblRight - ddMid - 14, regular, 8, C_MID, 12);
  rY -= 6;
}
page.drawText(`DELIVERY DATE : ${fmtDate(po.deliveryDate)}`, { x: ddMid + 10, y: rY, size: 8, font: bold, color: C_DARK });

// Footer
const ftTxt = 'END OF DOCUMENT  –  MOLECULE';
const ftW   = regular.widthOfTextAtSize(ftTxt, 8);
page.drawText(ftTxt, { x: (PW - ftW) / 2, y: 30, size: 8, font: regular, color: C_LGREY, characterSpacing: 0.5 });

// Save
const bytes = await pdfDoc.save();
fs.mkdirSync(path.join(root, '.local'), { recursive: true });
fs.writeFileSync(out, bytes);
console.log('✅ PDF written to', out);
