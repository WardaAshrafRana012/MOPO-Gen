/**
 * Adds new columns to PO_Items: Quantity_Type, PO_Type (after Category)
 * Adds Project_Reference to PO_Main (replacing/alongside Reference)
 * Run: node scripts/patch-new-columns.mjs
 */
import path from 'path'; import fs from 'fs'; import { fileURLToPath } from 'url'; import { google } from 'googleapis';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const envLines = fs.readFileSync(path.join(root, '.env'), 'utf8').split('\n');
for (const line of envLines) {
  const t = line.trim(); if (!t || t.startsWith('#')) continue;
  const eq = t.indexOf('='); if (eq < 0) continue;
  const k = t.slice(0, eq).trim(), v = t.slice(eq+1).trim().replace(/^"|"$/g,'');
  if (k && !process.env[k]) process.env[k] = v;
}
const SPREADSHEET_ID = process.env.GOOGLE_SHEET_ID;
const TOKEN_PATH = path.resolve(root, process.env.GOOGLE_OAUTH_TOKEN_PATH || '.local/google-oauth-tokens.json');
const tokens = JSON.parse(fs.readFileSync(TOKEN_PATH, 'utf8'));
const oauth2 = new google.auth.OAuth2(process.env.GOOGLE_OAUTH_CLIENT_ID, process.env.GOOGLE_OAUTH_CLIENT_SECRET, process.env.GOOGLE_OAUTH_REDIRECT_URI);
oauth2.setCredentials(tokens);
const sheets = google.sheets({ version: 'v4', auth: oauth2 });

async function patchHeaders(tabName, desiredHeaders) {
  const res = await sheets.spreadsheets.values.get({ spreadsheetId: SPREADSHEET_ID, range: `${tabName}!1:1` });
  const current = res.data.values?.[0] ?? [];
  console.log(`${tabName} current headers:`, current.join(', '));
  const toAdd = desiredHeaders.filter(h => !current.includes(h));
  if (toAdd.length === 0) { console.log(`✅ ${tabName}: all columns present.\n`); return; }
  const newHeaders = [...current, ...toAdd];
  await sheets.spreadsheets.values.update({
    spreadsheetId: SPREADSHEET_ID,
    range: `${tabName}!A1`,
    valueInputOption: 'RAW',
    requestBody: { values: [newHeaders] },
  });
  console.log(`✅ ${tabName}: added ${toAdd.join(', ')}\n`);
}

await patchHeaders('PO_Items', ['Item_ID','PO_ID','PO_Number','Description','Category','Quantity_Type','PO_Type','Quantity','Unit_Price','Amount','Created_At','Updated_At','Archived']);
await patchHeaders('PO_Main',  ['PO_ID','PO_Number','Vendor_Name','PO_Date','Delivery_Date','Project_Reference','Delivery_Address','Prepared_By','Telephone','Delivery_Instructions','Item_Category','Items_Count','Total_Amount','Amount_In_Words','PDF_Link','Drive_File_ID','Status','Created_At','Updated_At','Archived']);
console.log('🎉 Sheet columns updated.');
