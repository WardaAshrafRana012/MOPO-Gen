'use client';

import { useEffect, useMemo, useState, useRef, type FocusEvent } from 'react';
import GlassCard from '@/components/ui/GlassCard';
import Badge from '@/components/ui/Badge';
import POPreview from '@/components/po/POPreview';
import { generatePoNumber, getNextVendorSerial, formatCurrency, formatAmountInWords } from '@/lib/utils/format';
import type { PurchaseOrderPayload } from '@/types/po';

// ─── Constants ────────────────────────────────────────────────────────────────
const ITEM_CATEGORIES = [
  'Furniture','Paint Works','Partition Works','Air-Con Works','Ceiling Works',
  'Flooring Works','Electrical Works','Civil & Interior Works','Cartage & Divy',
  'Plumb & Sanitary Works','Design Services','Equip & Appliances','Metal Works',
  'Proj Mng Services','Samples',
];

const QTY_TYPES  = ['Unit', 'PCS', 'Set', 'Job', 'RFT', 'SFT'];
const PO_TYPES   = ['', 'Bill', 'Quote'];  // '' = not selected
const LS_KEYS    = {
  vendors:      'mopo_vendors',
  references:   'mopo_references',
  descriptions: 'mopo_descriptions',
  preparedBy:   'mopo_prepared_by',
};

// ─── localStorage helpers ─────────────────────────────────────────────────────
function lsGet(key: string): string[] {
  if (typeof window === 'undefined') return [];
  try { return JSON.parse(localStorage.getItem(key) || '[]'); } catch { return []; }
}
function lsSave(key: string, value: string) {
  if (!value.trim() || typeof window === 'undefined') return;
  const list = lsGet(key);
  if (!list.includes(value.trim())) {
    localStorage.setItem(key, JSON.stringify([value.trim(), ...list].slice(0, 50)));
  }
}

// ─── Autocomplete input ───────────────────────────────────────────────────────
function AutoInput({
  lsKey, value, onChange, placeholder, className = '',
  required = false,
}: {
  lsKey: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  className?: string;
  required?: boolean;
}) {
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [open, setOpen]               = useState(false);
  const ref                           = useRef<HTMLDivElement>(null);

  function handleChange(v: string) {
    onChange(v);
    if (v.length >= 1) {
      const all = lsGet(lsKey);
      setSuggestions(all.filter((s) => s.toLowerCase().includes(v.toLowerCase()) && s !== v));
    } else {
      setSuggestions([]);
    }
    setOpen(true);
  }

  function pick(s: string) { onChange(s); setSuggestions([]); setOpen(false); }

  // Close on outside click
  useEffect(() => {
    function handler(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const visible = open && suggestions.length > 0;

  return (
    <div ref={ref} className="relative w-full">
      <input
        className={`input-field ${className}`}
        value={value}
        onChange={(e) => handleChange(e.target.value)}
        onFocus={() => { if (suggestions.length) setOpen(true); }}
        placeholder={placeholder}
        required={required}
      />
      {visible && (
        <ul className="absolute z-50 mt-1 w-full overflow-hidden rounded-2xl border border-white/10 bg-slate-900 shadow-xl">
          {suggestions.map((s) => (
            <li
              key={s}
              className="cursor-pointer px-4 py-2.5 text-sm text-slate-200 hover:bg-white/10"
              onMouseDown={() => pick(s)}
            >
              {s}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

// ─── Item row type ────────────────────────────────────────────────────────────
type ItemRow = {
  id:           string;
  description:  string;
  category:     string;
  quantityType: string;
  quantity:     string;
  unitPrice:    string;
};

interface POWizardProps {
  existing?: {
    main:  any;
    items: Array<{
      description: string; quantity: number; unitPrice: number;
      category?: string; quantityType?: string; poType?: string;
    }>;
  };
  poId?: string;
}

const STEPS = ['PO Info', 'Items', 'Delivery', 'Preview & Generate'];

// ─── Component ────────────────────────────────────────────────────────────────
export default function POWizard({ existing, poId }: POWizardProps) {
  const isEdit = Boolean(poId);
  const exMain  = existing?.main;
  const exItems = existing?.items ?? [];

  const [step,       setStep]       = useState(1);
  const [saving,     setSaving]     = useState(false);
  const [msg,        setMsg]        = useState<{ text: string; ok: boolean } | null>(null);
  const [pdfLink,    setPdfLink]    = useState(exMain?.pdfLink    || '');
  const [driveFileId,setDriveFileId]= useState(exMain?.driveFileId|| '');
  const [errors,     setErrors]     = useState<Record<string, string>>({});

  // Step 1
  const [vendorName,        setVendorName]        = useState(exMain?.vendorName        || '');
  const [poNumber,          setPoNumber]          = useState(exMain?.poNumber          || '');
  const [poDate,            setPoDate]            = useState(exMain?.poDate            || '');
  const [deliveryDate,      setDeliveryDate]      = useState(exMain?.deliveryDate      || '');
  const [projectReference,  setProjectReference]  = useState(exMain?.projectReference  || exMain?.reference || '');
  const [poType,            setPoType]            = useState(exItems[0]?.poType || '');

  // Step 2
  const [items, setItems] = useState<ItemRow[]>(
    exItems.length
      ? exItems.map((i) => ({
          id: crypto.randomUUID(),
          description: i.description || '',
          category: i.category || '',
          quantityType: i.quantityType || '',
          quantity: String(i.quantity ?? 1),
          unitPrice: String(i.unitPrice ?? 0),
        }))
      : [{ id: crypto.randomUUID(), description: '', category: '', quantityType: '', quantity: '', unitPrice: '' }],
  );

  // Step 3
  const [deliveryAddress,      setDeliveryAddress]      = useState(exMain?.deliveryAddress      || '');
  const [preparedBy,           setPreparedBy]           = useState(exMain?.preparedBy           || '');
  const [telephone,            setTelephone]            = useState(exMain?.telephone            || '');
  const [deliveryInstructions, setDeliveryInstructions] = useState(exMain?.deliveryInstructions || '');

  // Settings / existing POs
  const [existingNos, setExistingNos] = useState<string[]>([]);
  const [poPrefix,    setPoPrefix]    = useState('PO');
  const [settings,    setSettings]    = useState<Record<string, string>>({});

  useEffect(() => {
    fetch('/api/settings').then((r) => r.json()).then((d) => {
      setPoPrefix(d?.data?.PO_PREFIX || 'PO');
      setSettings(d?.data || {});
    });
    fetch('/api/po').then((r) => r.json()).then((d) => {
      setExistingNos((d?.data ?? []).map((p: any) => p.poNumber));
    });
  }, []);

  // Auto-generate vendor-wise PO number
  useEffect(() => {
    if (isEdit || !vendorName.trim()) return;
    setPoNumber(generatePoNumber(vendorName, getNextVendorSerial(existingNos, vendorName, poPrefix), poPrefix));
  }, [vendorName, existingNos, poPrefix, isEdit]);

  // Computed
  const itemRows = useMemo(() => items.map((item) => {
    const quantity = Number(item.quantity || 0);
    const unitPrice = Number(item.unitPrice || 0);
    return { ...item, quantity, unitPrice, amount: quantity * unitPrice };
  }), [items]);
  const totalAmount = useMemo(() => itemRows.reduce((s, i) => s + i.amount, 0), [itemRows]);

  // ── Validation ──────────────────────────────────────────────────────────────
  function validateStep1() {
    const e: Record<string, string> = {};
    if (!vendorName.trim())       e.vendorName       = 'Vendor Name is required.';
    if (!projectReference.trim()) e.projectReference = 'Project Reference is required.';
    if (!poDate.trim())           e.poDate           = 'PO Date is required.';
    setErrors(e);
    return Object.keys(e).length === 0;
  }
  function validateStep2() {
    const e: Record<string, string> = {};
    itemRows.forEach((item, i) => {
      if (!item.description.trim()) e[`desc_${i}`] = 'Brief Detail of Item / Service is required.';
      if (!item.category.trim())    e[`category_${i}`] = 'Item Category is required.';
      if (item.quantity <= 0)       e[`qty_${i}`]  = 'Quantity must be > 0.';
    });
    setErrors(e);
    return Object.keys(e).length === 0;
  }
  function validateStep3() {
    const e: Record<string, string> = {};
    if (!deliveryAddress.trim()) e.deliveryAddress = 'Delivery Address is required.';
    if (!preparedBy.trim())      e.preparedBy      = 'Prepared By is required.';
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function goNext() {
    const ok = step === 1 ? validateStep1() : step === 2 ? validateStep2() : validateStep3();
    if (ok) { setErrors({}); setStep((s) => s + 1); }
  }

  // ── Item helpers ────────────────────────────────────────────────────────────
  const addItem    = () => setItems((c) => [...c, { id: crypto.randomUUID(), description: '', category: '', quantityType: '', quantity: '', unitPrice: '' }]);
  const removeItem = (id: string) => setItems((c) => c.filter((i) => i.id !== id));
  const updateItem = (id: string, patch: Partial<ItemRow>) => setItems((c) => c.map((i) => (i.id === id ? { ...i, ...patch } : i)));

  // ── Submit ──────────────────────────────────────────────────────────────────
  async function handleSubmit() {
    if (!validateStep1() || !validateStep2() || !validateStep3()) {
      setMsg({ text: 'Please fix validation errors before generating.', ok: false });
      return;
    }
    setSaving(true);
    setMsg(null);
    try {
      const payload: PurchaseOrderPayload = {
        vendorName, poDate, deliveryDate, projectReference,
        deliveryAddress, preparedBy, telephone, deliveryInstructions,
        itemCategory: itemRows[0]?.category || '',
        items: itemRows.map(({ description, quantity, unitPrice, category, quantityType }) => ({
          description, quantity, unitPrice, category, quantityType, poType,
        })),
        saveDraft: false,
      };
      const url    = isEdit && poId ? `/api/po/${poId}` : '/api/po';
      const method = isEdit ? 'PUT' : 'POST';
      const res    = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      const data   = await res.json();
      if (!res.ok) throw new Error(data?.error || 'Unable to save PO');

      // Save to localStorage
      lsSave(LS_KEYS.vendors,      vendorName);
      lsSave(LS_KEYS.references,   projectReference);
      lsSave(LS_KEYS.preparedBy,   preparedBy);
      itemRows.forEach((i) => { if (i.description.trim()) lsSave(LS_KEYS.descriptions, i.description); });

      if (data?.data?.pdfLink)    setPdfLink(data.data.pdfLink);
      if (data?.data?.driveFileId) setDriveFileId(data.data.driveFileId);
      setMsg({ text: isEdit ? 'PO updated successfully.' : `PO ${data.data?.poNumber} generated and uploaded to Drive!`, ok: true });
    } catch (err: any) {
      setMsg({ text: String(err?.message || err), ok: false });
    } finally {
      setSaving(false);
    }
  }

  const selectNumericInput = (event: FocusEvent<HTMLInputElement>) => {
    requestAnimationFrame(() => event.currentTarget.select());
  };

  const sanitizeIntegerInput = (value: string) => value.replace(/[^\d]/g, '');

  const sanitizeDecimalInput = (value: string) => {
    const cleaned = value.replace(/[^\d.]/g, '');
    const [whole, ...rest] = cleaned.split('.');
    return rest.length ? `${whole}.${rest.join('')}` : whole;
  };

  const handleQuantityChange = (id: string, value: string) => {
    updateItem(id, { quantity: sanitizeIntegerInput(value) });
  };

  const handleUnitPriceChange = (id: string, value: string) => {
    updateItem(id, { unitPrice: sanitizeDecimalInput(value) });
  };


  const previewProps = {
    vendorName, poNumber, poDate, deliveryDate, projectReference,
    items: itemRows,
    totalAmount,
    deliveryAddress, preparedBy, telephone, deliveryInstructions,
    companyName:    settings.COMPANY_NAME    || 'Molecule Work Place Solution',
    companyAddress: settings.COMPANY_ADDRESS || '47-B, Main Kh-e-Shamsheer, DHA-5, Karachi',
    companyNTN:     settings.COMPANY_NTN     || '8660135-2',
    companySTRN:    settings.COMPANY_STRN    || '32-77-8762-10932',
  };

  const err = (key: string) => errors[key]
    ? <p className="mt-1 text-xs text-rose-400">{errors[key]}</p>
    : null;

  return (
    <div className="space-y-6">

      {/* Step indicator */}
      <div className="flex items-center overflow-x-auto gap-1">
        {STEPS.map((label, i) => {
          const n = i + 1; const done = step > n; const active = step === n;
          return (
            <div key={n} className="flex items-center gap-1">
              <button type="button" onClick={() => done && setStep(n)}
                className={`flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-semibold transition ${active ? 'bg-champagne/20 text-champagne' : done ? 'text-slate-300 hover:text-champagne cursor-pointer' : 'text-slate-600 cursor-default'}`}
              >
                <span className={`inline-flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold ${active ? 'bg-champagne text-slate-900' : done ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-600'}`}>
                  {done ? '✓' : n}
                </span>
                <span className="hidden sm:inline">{label}</span>
              </button>
              {i < STEPS.length - 1 && <span className="text-slate-700 text-xs">›</span>}
            </div>
          );
        })}
      </div>

      <div className={`grid gap-6 ${step === 4 ? 'xl:grid-cols-2' : 'xl:grid-cols-1'}`}>

        {/* ── FORM CARD ────────────────────────────────────────────────── */}
        <GlassCard className="p-6">
          <div className="mb-5 flex items-start justify-between gap-3">
            <div>
              <p className="section-heading">{isEdit ? 'Edit PO' : 'Create PO'}</p>
              <h2 className="mt-1 text-xl font-semibold text-slate-100">Step {step}: {STEPS[step - 1]}</h2>
            </div>
            <Badge label={`${step} / 4`} tone="muted" />
          </div>

          {/* ── STEP 1 ─────────────────────────────────────────────────── */}
          {step === 1 && (
            <div className="space-y-5">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="block text-sm text-slate-200 mb-1.5">Vendor Name <span className="text-rose-400">*</span></label>
                  <AutoInput lsKey={LS_KEYS.vendors} value={vendorName} onChange={setVendorName} placeholder="e.g. Anwar Truck" required />
                  {err('vendorName')}
                </div>
                <label className="block text-sm text-slate-200">
                  PO Number <span className="text-[10px] text-slate-500">(auto — vendor-wise)</span>
                  <input className="input-field mt-1 cursor-not-allowed opacity-50" value={poNumber} readOnly />
                </label>
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="block text-sm text-slate-200 mb-1.5">PO Date <span className="text-rose-400">*</span></label>
                  <input type="date" className="input-field" value={poDate} onChange={(e) => setPoDate(e.target.value)} />
                  {err('poDate')}
                </div>
                <label className="block text-sm text-slate-200">
                  Delivery Date <span className="text-[10px] text-slate-500">(optional)</span>
                  <input type="date" className="input-field mt-1" value={deliveryDate} onChange={(e) => setDeliveryDate(e.target.value)} />
                </label>
              </div>
              <div>
                <label className="block text-sm text-slate-200 mb-1.5">Project Reference <span className="text-rose-400">*</span></label>
                <AutoInput lsKey={LS_KEYS.references} value={projectReference} onChange={setProjectReference} placeholder="e.g. HUBCO Thal Nova" required />
                {err('projectReference')}
              </div>
              <div>
                <label className="block text-sm text-slate-200 mb-1.5">PO Type <span className="text-[10px] text-slate-500">(optional)</span></label>
                <select className="input-field" value={poType} onChange={(e) => setPoType(e.target.value)}>
                  <option value="">None</option>
                  <option value="Bill">Bill</option>
                  <option value="Quote">Quote</option>
                </select>
              </div>
            </div>
          )}

          {/* ── STEP 2 ─────────────────────────────────────────────────── */}
          {step === 2 && (
            <div className="space-y-4">
              {itemRows.map((item, idx) => (
                <div key={item.id} className="rounded-2xl border border-white/10 bg-slate-900/60 p-4">
                  <div className="mb-3 flex items-center justify-between">
                    <p className="text-xs font-bold uppercase tracking-widest text-slate-400">Item {idx + 1}</p>
                    {itemRows.length > 1 && (
                      <button type="button" onClick={() => removeItem(item.id)} className="text-xs text-rose-400 hover:text-white">Remove</button>
                    )}
                  </div>

                  {/* Description */}
                  <div className="mb-3">
                    <label className="block text-sm text-slate-200 mb-1.5">Brief Detail of Item / Service <span className="text-rose-400">*</span></label>
                    <AutoInput lsKey={LS_KEYS.descriptions} value={item.description}
                      onChange={(v) => updateItem(item.id, { description: v })} placeholder="e.g. Ceiling Work" />
                    {err(`desc_${idx}`)}
                  </div>

                  {/* Category */}
                  <div className="mb-3">
                    <label className="block text-sm text-slate-200 mb-1.5">Item Category <span className="text-rose-400">*</span></label>
                    <select className="input-field" value={item.category} onChange={(e) => updateItem(item.id, { category: e.target.value })}>
                      <option value="">— Select Category —</option>
                      {ITEM_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                    </select>
                    {err(`category_${idx}`)}
                  </div>

                  {/* Qty / Qty Type / Price / Amount */}
                  <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    <div>
                      <label className="block text-sm text-slate-200 mb-1.5">Quantity <span className="text-rose-400">*</span></label>
                      <input
                        type="text"
                        inputMode="numeric"
                        className="input-field"
                        value={item.quantity}
                        placeholder="Enter quantity"
                        onFocus={selectNumericInput}
                        onChange={(e) => handleQuantityChange(item.id, e.target.value)}
                      />
                      {err(`qty_${idx}`)}
                    </div>
                    <div>
                      <label className="block text-sm text-slate-200 mb-1.5">Quantity Type</label>
                      <select className="input-field" value={item.quantityType} onChange={(e) => updateItem(item.id, { quantityType: e.target.value })}>
                        <option value="">— Select —</option>
                        {QTY_TYPES.map((q) => <option key={q} value={q}>{q}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm text-slate-200 mb-1.5">Unit Price (PKR) <span className="text-rose-400">*</span></label>
                      <input
                        type="text"
                        inputMode="decimal"
                        className="input-field"
                        value={item.unitPrice}
                        placeholder="Enter unit price"
                        onFocus={selectNumericInput}
                        onChange={(e) => handleUnitPriceChange(item.id, e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-slate-200 mb-1.5">Amount PKR</label>
                      <div className="rounded-3xl border border-white/8 bg-slate-950/60 px-4 py-3 font-semibold text-champagne text-sm">
                        {formatCurrency(item.amount)}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between pt-1">
                <button type="button" className="secondary-button text-sm" onClick={addItem}>+ Add Item Row</button>
                <div className="rounded-2xl border border-white/10 bg-slate-900/70 px-5 py-4 text-sm">
                  <p className="text-slate-400">Total Amount</p>
                  <p className="mt-1 text-2xl font-bold text-champagne">{formatCurrency(totalAmount)}</p>
                  <p className="mt-0.5 text-[11px] text-slate-500">{formatAmountInWords(totalAmount)}</p>
                </div>
              </div>
            </div>
          )}

          {/* ── STEP 3 ─────────────────────────────────────────────────── */}
          {step === 3 && (
            <div className="space-y-5">
              <div>
                <label className="block text-sm text-slate-200 mb-1.5">Delivery Address <span className="text-rose-400">*</span></label>
                <textarea className="input-field min-h-[90px]" placeholder="Full delivery address"
                  value={deliveryAddress} onChange={(e) => setDeliveryAddress(e.target.value)} />
                {err('deliveryAddress')}
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-sm text-slate-200 mb-1.5">Prepared By <span className="text-rose-400">*</span></label>
                  <AutoInput lsKey={LS_KEYS.preparedBy} value={preparedBy} onChange={setPreparedBy} placeholder="Name" required />
                  {err('preparedBy')}
                </div>
                <label className="block text-sm text-slate-200">
                  Telephone <span className="text-[10px] text-slate-500">(optional)</span>
                  <input className="input-field mt-1" placeholder="021-XXXXXXX" value={telephone} onChange={(e) => setTelephone(e.target.value)} />
                </label>
              </div>
              <label className="block text-sm text-slate-200">
                Delivery Instructions <span className="text-[10px] text-slate-500">(optional)</span>
                <textarea className="input-field mt-1 min-h-[80px]" placeholder="Any special notes"
                  value={deliveryInstructions} onChange={(e) => setDeliveryInstructions(e.target.value)} />
              </label>
            </div>
          )}

          {/* ── STEP 4 ─────────────────────────────────────────────────── */}
          {step === 4 && (
            <div className="space-y-5">
              <div className="rounded-2xl border border-amber-500/20 bg-amber-500/8 px-4 py-3 text-sm text-amber-200">
                Review the live preview. Click <strong>Generate PO</strong> to save to Google Sheets and upload the PDF to Drive.
              </div>
              {msg && (
                <div className={`rounded-2xl border px-4 py-3 text-sm ${msg.ok ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200' : 'border-rose-500/30 bg-rose-500/10 text-rose-200'}`}>
                  {msg.text}
                </div>
              )}
              {pdfLink && (
                <div className="rounded-2xl border border-white/10 bg-slate-900/70 p-5 space-y-3">
                  <p className="text-sm font-semibold text-emerald-300">✓ PDF Generated &amp; Uploaded to Drive</p>
                  <p className="text-xs text-slate-400 break-all">{pdfLink}</p>
                  <div className="flex flex-wrap gap-3">
                    <a href={pdfLink} target="_blank" rel="noreferrer" className="primary-button text-sm">Open PDF</a>
                    <a href={driveFileId ? `/api/po/download?fileId=${encodeURIComponent(driveFileId)}` : `/api/po/download?url=${encodeURIComponent(pdfLink)}`}
                       className="secondary-button text-sm">Download PDF</a>
                    <button type="button" className="secondary-button text-sm" onClick={() => navigator.clipboard?.writeText(pdfLink)}>Copy Link</button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Navigation */}
          <div className="mt-7 flex flex-wrap items-center justify-between gap-3">
            <div className="flex gap-3">
              {step > 1 && (
                <button type="button" className="secondary-button text-sm" onClick={() => { setErrors({}); setStep((s) => s - 1); }}>← Back</button>
              )}
              {step < 4 && (
                <button type="button" className="primary-button text-sm" onClick={goNext}>Continue →</button>
              )}
            </div>
            {step === 4 && (
              <button type="button" className="primary-button text-sm min-w-[140px]" disabled={saving} onClick={handleSubmit}>
                {saving ? (
                  <span className="inline-flex items-center gap-2">
                    <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-slate-900 border-t-transparent" />
                    Generating…
                  </span>
                ) : isEdit ? 'Save Changes' : 'Generate PO'}
              </button>
            )}
          </div>
        </GlassCard>

        {/* ── RIGHT PANEL ─────────────────────────────────────────────── */}
        {step === 4 ? (
          <GlassCard className="p-4">
            <p className="section-heading mb-3">Live PDF Preview</p>
            <div className="overflow-hidden rounded-2xl border border-white/10 bg-white">
              <POPreview {...previewProps} />
            </div>
          </GlassCard>
        ) : null}
      </div>
    </div>
  );
}

