'use client';

import { useEffect, useRef, useState } from 'react';
import Image from 'next/image';

interface PreviewItem {
  description: string;
  category?: string;
  quantity: number;
  quantityType?: string;
  poType?: string;
  unitPrice: number;
  amount: number;
}

export interface POPreviewProps {
  vendorName?: string;
  poNumber?: string;
  poDate?: string;
  deliveryDate?: string;
  projectReference?: string;
  items?: PreviewItem[];
  totalAmount?: number;
  deliveryAddress?: string;
  preparedBy?: string;
  telephone?: string;
  deliveryInstructions?: string;
  companyName?: string;
  companyAddress?: string;
  companyNTN?: string;
  companySTRN?: string;
}

function fmtDate(v?: string): string {
  if (!v) return '-';
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return v;
  return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }).toUpperCase();
}

function fmtNum(n: number): string {
  return new Intl.NumberFormat('en-PK', { minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(n);
}

function toWords(amount: number): string {
  const ones = ['', 'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX', 'SEVEN', 'EIGHT', 'NINE', 'TEN', 'ELEVEN', 'TWELVE', 'THIRTEEN', 'FOURTEEN', 'FIFTEEN', 'SIXTEEN', 'SEVENTEEN', 'EIGHTEEN', 'NINETEEN'];
  const tens = ['', '', 'TWENTY', 'THIRTY', 'FORTY', 'FIFTY', 'SIXTY', 'SEVENTY', 'EIGHTY', 'NINETY'];

  function belowOneThousand(n: number): string {
    if (!n) return '';
    if (n < 20) return ones[n];
    if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 ? '-' + ones[n % 10] : '');
    return ones[Math.floor(n / 100)] + ' HUNDRED' + (n % 100 ? ' ' + belowOneThousand(n % 100) : '');
  }

  const n = Math.round(Number(amount) || 0);
  if (!n) return 'ZERO RUPEES ONLY';

  const parts: string[] = [];
  if (Math.floor(n / 10000000)) parts.push(belowOneThousand(Math.floor(n / 10000000)) + ' CRORE');
  if (Math.floor((n % 10000000) / 100000)) parts.push(belowOneThousand(Math.floor((n % 10000000) / 100000)) + ' LAKH');
  if (Math.floor((n % 100000) / 1000)) parts.push(belowOneThousand(Math.floor((n % 100000) / 1000)) + ' THOUSAND');
  if (n % 1000) parts.push(belowOneThousand(n % 1000));
  return parts.join(' ') + ' RUPEES ONLY';
}

const A4_W = 595;
const A4_H = 842;
const BORDER = '0.5px solid #bbb';

function thStyle(align: 'left' | 'center' | 'right', width: string): React.CSSProperties {
  return { border: BORDER, padding: '6px 6px', textAlign: align, fontWeight: 700, width, fontSize: 8 };
}

const tdStyle: React.CSSProperties = { border: BORDER, padding: '5px 6px', fontSize: 8.5, verticalAlign: 'top' };
const ddCell: React.CSSProperties = { border: BORDER, padding: '9px 11px', verticalAlign: 'top' };

function optionalRows(rows: Array<[string, string | undefined]>): Array<[string, string]> {
  return rows.filter(([, value]) => Boolean(value && value.trim())) as Array<[string, string]>;
}

export default function POPreview({
  vendorName = '',
  poNumber = 'PO-XXXX-XXX',
  poDate = '',
  deliveryDate,
  projectReference = '',
  items = [],
  totalAmount = 0,
  deliveryAddress = '',
  preparedBy = '',
  telephone,
  deliveryInstructions,
  companyName = 'Molecule Work Place Solution',
  companyAddress = '47-B, Main Kh-e-Shamsheer, DHA-5, Karachi',
  companyNTN = '8660135-2',
  companySTRN = '32-77-8762-10932',
}: POPreviewProps) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    if (!wrapRef.current) return;
    const obs = new ResizeObserver((entries) => {
      const w = entries[0]?.contentRect.width;
      if (w) setScale(w / A4_W);
    });
    obs.observe(wrapRef.current);
    setScale(wrapRef.current.clientWidth / A4_W);
    return () => obs.disconnect();
  }, []);

  const words = toWords(totalAmount);
  const headerOptionalRows = optionalRows([
    ['DELIVERY DATE', deliveryDate ? fmtDate(deliveryDate) : ''],
  ]);
  const deliveryLeftRows = optionalRows([
    ['TELEPHONE', telephone],
  ]);
  const deliveryRightRows = optionalRows([
    ['DELIVERY INSTRUCTIONS', deliveryInstructions],
    ['DELIVERY DATE', deliveryDate ? fmtDate(deliveryDate) : ''],
  ]);

  return (
    <div ref={wrapRef} className="relative w-full overflow-hidden bg-white" style={{ height: A4_H * scale }}>
      <div
        style={{
          width: A4_W,
          height: A4_H,
          transform: `scale(${scale})`,
          transformOrigin: 'top left',
          position: 'absolute',
          top: 0,
          left: 0,
          backgroundColor: '#fff',
          fontFamily: 'Helvetica, Arial, sans-serif',
          color: '#1a1a1a',
          boxSizing: 'border-box',
          padding: '38px 42px',
          fontSize: 9,
          lineHeight: 1.4,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 24 }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
            <Image src="/molecule-logo.svg" alt="MOPO" width={56} height={48} style={{ width: 56, height: 48, flexShrink: 0, objectFit: 'fill' }} priority />
            <div style={{ lineHeight: 1.15 }}>
              <div style={{ fontSize: 15.5, fontWeight: 400, marginBottom: 4 }}>Molecule</div>
              {['WORK', 'PLACE', 'SOLUTION'].map((word) => (
                <div key={word} style={{ fontSize: 5.5, letterSpacing: '0.18em', color: '#777' }}>{word}</div>
              ))}
            </div>
          </div>

          <div style={{ textAlign: 'right', fontSize: 8.5, lineHeight: 1.7 }}>
            <div style={{ fontWeight: 700 }}>VENDOR NAME: {vendorName ? vendorName.toUpperCase() : '-'}</div>
            <div style={{ fontWeight: 700 }}>PO NUMBER: {poNumber}</div>
            <div>PO DATE: {fmtDate(poDate)}</div>
            <div>PROJECT REFERENCE: {projectReference || '-'}</div>
            {headerOptionalRows.map(([label, value]) => (
              <div key={label}>{label}: {value}</div>
            ))}
          </div>
        </div>

        <div style={{ fontSize: 28, fontWeight: 700, marginTop: 18, marginBottom: 10 }}>PURCHASE ORDER</div>

        <div style={{ fontSize: 7.5, fontWeight: 700, lineHeight: 1.6 }}>
          {companyName.toUpperCase()}, {companyAddress.toUpperCase()}
        </div>
        <div style={{ fontSize: 7.5, lineHeight: 1.6 }}>NTN# {companyNTN}</div>
        <div style={{ fontSize: 7.5, lineHeight: 1.6, marginBottom: 16 }}>STRN# {companySTRN}</div>

        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: '#f0f0f0' }}>
              <th style={thStyle('left', '42%')}>Brief Detail of Major Type Of Item / Service</th>
              <th style={thStyle('center', '9%')}>Qty</th>
              <th style={thStyle('center', '11%')}>Qty Type</th>
              <th style={thStyle('center', '16%')}>Unit Price</th>
              <th style={{ ...thStyle('center', '14%'), paddingBottom: 3 }}>Amount<br />PKR</th>
            </tr>
          </thead>
          <tbody>
            {items.length === 0 ? (
              <tr>
                <td colSpan={5} style={{ ...tdStyle, color: '#aaa', fontStyle: 'italic' }}>No items added yet.</td>
              </tr>
            ) : (
              items.map((item, i) => (
                <tr key={i}>
                  <td style={tdStyle}>
                    <div>{item.description || '-'}</div>
                    {item.category ? <div style={{ color: '#666', fontSize: 7.5, marginTop: 2 }}>Category: {item.category}</div> : null}
                    {item.poType ? <div style={{ color: '#666', fontSize: 7.5, marginTop: 2 }}>({item.poType})</div> : null}
                  </td>
                  <td style={{ ...tdStyle, textAlign: 'center', verticalAlign: 'middle' }}>{fmtNum(item.quantity)}</td>
                  <td style={{ ...tdStyle, textAlign: 'center', verticalAlign: 'middle' }}>{item.quantityType || ''}</td>
                  <td style={{ ...tdStyle, textAlign: 'right', verticalAlign: 'middle' }}>{fmtNum(item.unitPrice)}</td>
                  <td style={{ ...tdStyle, textAlign: 'right', verticalAlign: 'middle' }}>{fmtNum(item.amount)}</td>
                </tr>
              ))
            )}
            <tr style={{ background: '#f0f0f0' }}>
              <td colSpan={3} style={{ ...tdStyle, fontWeight: 700 }}>{words}</td>
              <td style={{ ...tdStyle, textAlign: 'center', fontWeight: 700 }}>TOTAL</td>
              <td style={{ ...tdStyle, textAlign: 'right', fontWeight: 700 }}>{fmtNum(totalAmount)}</td>
            </tr>
          </tbody>
        </table>

        <div style={{ marginTop: 20 }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 8 }}>DELIVERY DETAILS</div>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <tbody>
              <tr>
                <td style={{ ...ddCell, width: '54%' }}>
                  <div style={{ fontWeight: 700 }}>DELIVERY ADDRESS : {deliveryAddress || '-'}</div>
                  <div style={{ marginTop: 7, fontWeight: 700 }}>PREPARED BY : {preparedBy || '-'}</div>
                  {deliveryLeftRows.map(([label, value]) => (
                    <div key={label} style={{ marginTop: 7, fontWeight: 700 }}>{label} : {value}</div>
                  ))}
                </td>
                <td style={ddCell}>
                  {deliveryRightRows.length > 0 ? (
                    deliveryRightRows.map(([label, value], index) => (
                      <div key={label} style={{ marginTop: index === 0 ? 0 : 9 }}>
                        <div style={{ fontWeight: 700 }}>{label}</div>
                        {label === 'DELIVERY INSTRUCTIONS' ? <div style={{ marginTop: 4, lineHeight: 1.5 }}>{value}</div> : <div style={{ marginTop: 4 }}>{value}</div>}
                      </div>
                    ))
                  ) : (
                    <div style={{ minHeight: 18 }} />
                  )}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

      </div>
    </div>
  );
}
