'use client';

import { useEffect, useMemo, useState, useCallback, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import GlassCard from '@/components/ui/GlassCard';
import { formatCurrency, formatDate } from '@/lib/utils/format';

type Order = {
  poId:         string;
  poNumber:     string;
  vendorName:   string;
  poDate:       string;
  deliveryDate: string;
  itemsCount:   number;
  totalAmount:  number;
  pdfLink:      string;
  driveFileId:  string;
  status:       string;
  archived:     boolean;
};

function PORecordsInner() {
  const searchParams = useSearchParams();

  const [orders,     setOrders]     = useState<Order[]>([]);
  const [search,     setSearch]     = useState(searchParams.get('search') ?? '');
  const [dateFilter, setDateFilter] = useState('');
  const [loading,    setLoading]    = useState(true);
  const [flash,      setFlash]      = useState<{ text: string; ok: boolean } | null>(null);
  const [deleting,   setDeleting]   = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const res  = await fetch('/api/po');
    const data = await res.json();
    setOrders(data?.data ?? []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    const q = searchParams.get('search');
    if (q !== null) setSearch(q);
  }, [searchParams]);

  function notify(text: string, ok = true) {
    setFlash({ text, ok });
    setTimeout(() => setFlash(null), 5000);
  }

  async function copyLink(link: string) {
    if (!link) { notify('No PDF link available.', false); return; }
    await navigator.clipboard.writeText(link).catch(() => {});
    notify('PDF link copied to clipboard.');
  }

  async function deletePO(poId: string, poNumber: string) {
    if (!confirm(`Permanently delete ${poNumber}?\n\nThis will remove it from Google Sheets. This cannot be undone.`)) return;
    setDeleting(poId);
    try {
      const res  = await fetch(`/api/po/${poId}/delete`, { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok) { notify(data?.error || 'Delete failed.', false); return; }
      notify(`${poNumber} deleted.`);
      load();
    } finally {
      setDeleting(null);
    }
  }

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return orders
      .filter((o) => !o.archived)
      .filter((o) => !dateFilter || o.poDate === dateFilter)
      .filter((o) => !q || o.poNumber?.toLowerCase().includes(q) || o.vendorName?.toLowerCase().includes(q));
  }, [orders, search, dateFilter]);

  const totalValue = useMemo(() =>
    orders.filter((o) => !o.archived).reduce((s, o) => s + Number(o.totalAmount || 0), 0),
  [orders]);

  const withPdf = useMemo(() => orders.filter((o) => !o.archived && !!o.pdfLink).length, [orders]);

  // Build download URL — prefer fileId for direct stream, fallback to url proxy
  function downloadUrl(order: Order) {
    if (order.driveFileId) return `/api/po/download?fileId=${encodeURIComponent(order.driveFileId)}`;
    if (order.pdfLink)     return `/api/po/download?url=${encodeURIComponent(order.pdfLink)}`;
    return null;
  }

  return (
    <div className="space-y-6 py-6">

      {/* Header */}
      <GlassCard className="p-8">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="section-heading">Purchase Orders</p>
            <h1 className="page-heading mt-1">PO Records</h1>
            <p className="mt-3 max-w-2xl text-sm text-slate-400">
              Every row is one vendor PO. Data is saved in Google Sheets. PDFs are stored in Google Drive.
            </p>
          </div>
          <Link href="/create-po" className="primary-button text-sm">+ Create PO</Link>
        </div>
      </GlassCard>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: 'Total POs',     val: loading ? '…' : String(orders.filter((o) => !o.archived).length) },
          { label: 'PDFs on Drive', val: loading ? '…' : String(withPdf) },
          { label: 'Showing',       val: loading ? '…' : String(filtered.length) },
          { label: 'Total Value',   val: loading ? '…' : formatCurrency(totalValue), accent: true },
        ].map(({ label, val, accent }) => (
          <GlassCard key={label} className="p-4">
            <p className="text-xs uppercase tracking-widest text-slate-500">{label}</p>
            <p className={`mt-1 font-semibold ${accent ? 'text-lg text-champagne' : 'text-2xl text-slate-100'}`}>{val}</p>
          </GlassCard>
        ))}
      </div>

      {/* Filters */}
      <GlassCard className="p-4">
        <div className="grid gap-3 sm:grid-cols-2">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search PO number or vendor…"
            className="input-field"
          />
          <input
            type="date"
            className="input-field"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            title="Filter by PO date"
          />
        </div>
      </GlassCard>

      {/* Flash */}
      {flash && (
        <div className={`rounded-2xl border px-5 py-3 text-sm ${flash.ok ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200' : 'border-rose-500/30 bg-rose-500/10 text-rose-200'}`}>
          {flash.text}
        </div>
      )}

      {/* Table */}
      <GlassCard className="overflow-hidden p-0">
        <div className="overflow-x-auto">
          <table className="min-w-full border-separate border-spacing-0 text-left text-sm">
            <thead>
              <tr className="bg-slate-950/90 text-xs uppercase tracking-wider text-slate-500">
                <th className="px-5 py-3.5 font-medium">PO Number</th>
                <th className="px-5 py-3.5 font-medium">Vendor</th>
                <th className="px-5 py-3.5 font-medium">PO Date</th>
                <th className="px-5 py-3.5 font-medium">Delivery Date</th>
                <th className="px-5 py-3.5 font-medium text-center">Items</th>
                <th className="px-5 py-3.5 font-medium text-right">Total (PKR)</th>
                <th className="px-5 py-3.5 font-medium text-center">PDF</th>
                <th className="px-5 py-3.5 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i} className="border-t border-white/5">
                    {Array.from({ length: 8 }).map((_, j) => (
                      <td key={j} className="px-5 py-4">
                        <span className="inline-block h-3 w-20 animate-pulse rounded bg-slate-800" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-14 text-center text-slate-500">
                    {orders.length === 0
                      ? <span>No purchase orders yet.{' '}<Link href="/create-po" className="text-champagne hover:text-white underline">Create your first PO →</Link></span>
                      : 'No records match your search.'}
                  </td>
                </tr>
              ) : (
                filtered.map((order) => {
                  const dl = downloadUrl(order);
                  return (
                    <tr key={order.poId} className={`border-t border-white/5 text-slate-200 transition hover:bg-white/[0.03] ${deleting === order.poId ? 'opacity-40' : ''}`}>
                      <td className="px-5 py-3.5 font-semibold text-slate-100 whitespace-nowrap">{order.poNumber}</td>
                      <td className="px-5 py-3.5 whitespace-nowrap">{order.vendorName}</td>
                      <td className="px-5 py-3.5 whitespace-nowrap text-slate-400">{formatDate(order.poDate)}</td>
                      <td className="px-5 py-3.5 whitespace-nowrap text-slate-400">
                        {order.deliveryDate ? formatDate(order.deliveryDate) : '—'}
                      </td>
                      <td className="px-5 py-3.5 text-center text-slate-400">{order.itemsCount}</td>
                      <td className="px-5 py-3.5 text-right font-semibold text-slate-100 whitespace-nowrap">
                        {formatCurrency(order.totalAmount)}
                      </td>
                      <td className="px-5 py-3.5 text-center">
                        {order.pdfLink
                          ? <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2.5 py-0.5 text-[10px] font-semibold text-emerald-300">✓ Ready</span>
                          : <span className="inline-flex rounded-full bg-slate-700/50 px-2.5 py-0.5 text-[10px] font-semibold text-slate-400">Pending</span>
                        }
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-3 text-xs whitespace-nowrap">
                          <Link href={`/po-records/${order.poId}`} className="font-semibold text-champagne hover:text-white">
                            View
                          </Link>
                          <Link href={`/po-records/${order.poId}/edit`} className="text-slate-400 hover:text-white">
                            Edit
                          </Link>
                          {dl ? (
                            <a href={dl} className="text-slate-400 hover:text-white">
                              Download PDF
                            </a>
                          ) : (
                            <span className="text-slate-600">No PDF</span>
                          )}
                          {order.pdfLink && (
                            <button type="button" onClick={() => copyLink(order.pdfLink)} className="text-slate-400 hover:text-white">
                              Copy Link
                            </button>
                          )}
                          <button
                            type="button"
                            disabled={deleting === order.poId}
                            onClick={() => deletePO(order.poId, order.poNumber)}
                            className="text-rose-400 hover:text-rose-200 font-medium disabled:opacity-40"
                          >
                            {deleting === order.poId ? 'Deleting…' : 'Delete'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
}

export default function PORecordsPage() {
  return (
    <Suspense>
      <PORecordsInner />
    </Suspense>
  );
}
