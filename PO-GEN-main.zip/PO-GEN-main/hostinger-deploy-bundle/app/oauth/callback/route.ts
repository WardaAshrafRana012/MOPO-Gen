import { NextResponse } from 'next/server';
import { google } from 'googleapis';
import fs from 'fs';
import path from 'path';

export async function GET(request: Request) {
  const url = new URL(request.url);
  const code = url.searchParams.get('code');
  if (!code) return NextResponse.json({ error: 'Missing code' }, { status: 400 });

  const clientId = process.env.GOOGLE_OAUTH_CLIENT_ID;
  const clientSecret = process.env.GOOGLE_OAUTH_CLIENT_SECRET;
  const redirect = process.env.GOOGLE_OAUTH_REDIRECT_URI;
  const tokenPath = process.env.GOOGLE_OAUTH_TOKEN_PATH || '.local/google-oauth-tokens.json';

  if (!clientId || !clientSecret || !redirect) {
    return NextResponse.json({ error: 'Missing OAuth config in env' }, { status: 400 });
  }

  const oauth2Client = new google.auth.OAuth2(clientId, clientSecret, redirect);
  const { tokens } = await oauth2Client.getToken(code);

  const tokenFullPath = path.resolve(process.cwd(), tokenPath);
  fs.mkdirSync(path.dirname(tokenFullPath), { recursive: true });
  fs.writeFileSync(tokenFullPath, JSON.stringify(tokens, null, 2));

  return NextResponse.redirect(new URL('/', request.url).toString());
}
