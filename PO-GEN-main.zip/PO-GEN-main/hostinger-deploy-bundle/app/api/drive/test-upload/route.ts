import { NextResponse } from 'next/server';
import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';
import { uploadPDFToDrive, getDriveFileLink } from '@/lib/google/drive';
import { appendActivityLog } from '@/lib/google/sheets';

export async function POST() {
  try {
    const pdf  = await PDFDocument.create();
    const page = pdf.addPage([320, 180]);
    const font = await pdf.embedFont(StandardFonts.HelveticaBold);
    page.drawText('MOPO Drive Test Upload', { x: 32, y: 96, size: 16, font, color: rgb(0.1, 0.1, 0.1) });

    // pdf.save() returns Uint8Array — pass directly, drive.ts handles Readable conversion
    const buffer   = await pdf.save();
    const uploaded = await uploadPDFToDrive(buffer, `mopo-drive-test-${Date.now()}.pdf`);
    const pdfLink  = getDriveFileLink(uploaded.id);

    await appendActivityLog({
      Log_ID:    crypto.randomUUID(),
      Time:      new Date().toISOString(),
      Action:    'Drive test upload',
      PO_Number: '',
      User:      'System',
      Status:    'Uploaded',
      Details:   `Test upload OK: ${pdfLink}`,
    });

    return NextResponse.json({ data: { driveFileId: uploaded.id, pdfLink } });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
