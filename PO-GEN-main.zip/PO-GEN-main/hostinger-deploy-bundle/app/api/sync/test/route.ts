import { NextResponse } from 'next/server';
import { verifyRequiredTabs } from '@/lib/google/sheets';
import { getDriveClient, GOOGLE_DRIVE_FOLDER_ID } from '@/lib/google/client';

export async function POST() {
  try {
    const sheetStatus = await verifyRequiredTabs();
    const drive = await getDriveClient();
    const response = await drive.files.get({
      fileId: GOOGLE_DRIVE_FOLDER_ID,
      fields: 'id,name,mimeType',
    });
    return NextResponse.json({
      data: {
        spreadsheetId: sheetStatus.spreadsheetId,
        sheets: sheetStatus.missingTabs.length === 0,
        requiredTabs: sheetStatus.requiredTabs,
        missingTabs: sheetStatus.missingTabs,
        driveFolder: Boolean(response.data.id),
        driveFolderName: response.data.name,
      },
    });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
