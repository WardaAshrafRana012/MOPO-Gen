import { NextResponse } from 'next/server';
import { appendActivityLog, getSheetRows, verifyRequiredTabs, SHEET_NAMES } from '@/lib/google/sheets';
import { getAllPurchaseOrders, getPurchaseOrderById } from '@/lib/po';
import { getSheetsClient } from '@/lib/google/client';
import { GOOGLE_SPREADSHEET_ID } from '@/lib/google/client';

/**
 * POST /api/sync
 * 1. Verifies all required tabs exist
 * 2. Reads all POs from the app (PO_Main sheet)
 * 3. Ensures every PO row is present and up-to-date in the sheet
 *    (The sheet IS the database, so sync = verify tabs + return status)
 */
export async function POST() {
  try {
    // Step 1: verify tabs exist
    const tabResult = await verifyRequiredTabs();

    if (tabResult.missingTabs.length > 0) {
      return NextResponse.json({
        data: {
          ...tabResult,
          synced: 0,
          message: `Missing tabs: ${tabResult.missingTabs.join(', ')}. Run setup first.`,
        },
      });
    }

    // Step 2: count POs currently in sheet
    const { rows: mainRows } = await getSheetRows(SHEET_NAMES.main);
    const poCount = mainRows.filter((r) => r.values.PO_ID).length;

    // Step 3: log sync event
    await appendActivityLog({
      Log_ID:    crypto.randomUUID(),
      Time:      new Date().toISOString(),
      Action:    'Sync',
      PO_Number: '',
      User:      'System',
      Status:    'Synced',
      Details:   `Sheet verified. ${poCount} PO record(s) in PO_Main. All tabs OK.`,
    });

    return NextResponse.json({
      data: {
        spreadsheetId: tabResult.spreadsheetId,
        requiredTabs:  tabResult.requiredTabs,
        missingTabs:   [],
        poCount,
        synced:        poCount,
        message:       `Sync complete. ${poCount} PO record(s) confirmed in sheet.`,
      },
    });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
