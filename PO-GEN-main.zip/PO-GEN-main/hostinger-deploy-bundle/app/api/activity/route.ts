import { NextResponse } from 'next/server';
import { getActivityLogs } from '@/lib/google/sheets';

export async function GET() {
  try {
    const logs = await getActivityLogs();
    return NextResponse.json({ data: logs });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
