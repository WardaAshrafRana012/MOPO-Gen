import { NextRequest, NextResponse } from 'next/server';
import { getSettings, updateSettings } from '@/lib/google/sheets';

export async function GET() {
  try {
    const settings = await getSettings();
    return NextResponse.json({ data: settings });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const updates = await req.json();
    await updateSettings(updates);
    return NextResponse.json({ data: { success: true } });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
