'use client';

import { useEffect, useState } from 'react';
import GlassCard from '@/components/ui/GlassCard';
import POPreview from '@/components/po/POPreview';

const SAMPLE_ITEMS = [
  { description: 'Furniture Delivery', category: 'Furniture', quantity: 1, quantityType: 'Job', unitPrice: 84000, amount: 84000 },
];

export default function TemplatesPage() {
  const [settings, setSettings] = useState<Record<string, string>>({});

  useEffect(() => {
    fetch('/api/settings').then((r) => r.json()).then((d) => {
      setSettings(d?.data || {});
    });
  }, []);

  const today = new Date().toISOString().slice(0, 10);

  return (
    <div className="space-y-8 py-8">
      <GlassCard className="p-8">
        <p className="section-heading">Templates</p>
        <h1 className="page-heading mt-2">PO Template Preview</h1>
        <p className="mt-4 max-w-2xl text-slate-400">
          This is the fixed Purchase Order template used for every generated PDF. Only the PO data changes.
        </p>
      </GlassCard>

      <div className="grid gap-6 xl:grid-cols-[1.5fr_0.7fr]">
        <GlassCard className="p-6">
          <p className="section-heading mb-4">Template Preview (Sample Data)</p>
          <div className="overflow-hidden rounded-2xl border border-white/10 bg-white">
            <POPreview
              vendorName="ANWAR TRUCK"
              poNumber="PO-0324-ANW"
              poDate={today}
              deliveryDate={today}
              projectReference="HUBCO Thal Nova"
              items={SAMPLE_ITEMS}
              totalAmount={84000}
              deliveryAddress="Molecule 47-B, Main Kh-e-Shamsheer, DHA-5, Karachi"
              preparedBy="Arsalan"
              telephone="021-3567890"
              deliveryInstructions="Deliver during business hours."
              companyName={settings.COMPANY_NAME || 'Molecule Work Place Solution'}
              companyAddress={settings.COMPANY_ADDRESS || '47-B, Main Kh-e-Shamsheer, DHA-5, Karachi'}
              companyNTN={settings.COMPANY_NTN || '8660135-2'}
              companySTRN={settings.COMPANY_STRN || '32-77-8762-10932'}
            />
          </div>
        </GlassCard>

        <div className="space-y-5">
          <GlassCard className="p-6">
            <p className="section-heading mb-4">Fixed Template Elements</p>
            <ul className="space-y-3 text-sm text-slate-300">
              {[
                ['Logo', 'Official MOPO SVG logo - top-left'],
                ['Heading', 'PURCHASE ORDER - bold, 24pt'],
                ['Company Name', settings.COMPANY_NAME || 'Molecule Work Place Solution'],
                ['Address', settings.COMPANY_ADDRESS || '47-B, Main Kh-e-Shamsheer, DHA-5, Karachi'],
                ['NTN', `NTN# ${settings.COMPANY_NTN || '8660135-2'}`],
                ['STRN', `STRN# ${settings.COMPANY_STRN || '32-77-8762-10932'}`],
              ].map(([label, value]) => (
                <li key={String(label)} className="flex flex-col gap-0.5 rounded-3xl border border-white/10 bg-slate-900/70 px-4 py-3">
                  <span className="text-xs uppercase tracking-wider text-slate-500">{label}</span>
                  <span className="text-slate-100">{value}</span>
                </li>
              ))}
            </ul>
          </GlassCard>

          <GlassCard className="p-6">
            <p className="section-heading mb-4">Dynamic Fields</p>
            <ul className="space-y-2 text-sm text-slate-400">
              {[
                'Vendor Name',
                'PO Number (auto-generated)',
                'PO Date',
                'Delivery Date (optional)',
                'Project Reference',
                'Item Category (required on every item row)',
                'Item rows (unlimited)',
                'Delivery Address',
                'Prepared By',
                'Telephone (optional)',
                'Delivery Instructions (optional)',
              ].map((field) => (
                <li key={field} className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-champagne/70" />
                  {field}
                </li>
              ))}
            </ul>
          </GlassCard>
        </div>
      </div>
    </div>
  );
}
