import POWizard from '@/components/po/POWizard';

export default function CreatePOPage() {
  return (
    <div className="space-y-6 py-6">
      <div className="rounded-[1.75rem] border border-white/10 bg-slate-950/70 px-8 py-7 shadow-glass">
        <p className="section-heading">Create PO</p>
        <h1 className="page-heading mt-1">New Purchase Order</h1>
        <p className="mt-3 max-w-2xl text-sm text-slate-400">
          Fill the 4-step wizard. PO number is auto-generated, PDF is created and uploaded to Google Drive automatically.
        </p>
      </div>
      <POWizard />
    </div>
  );
}
